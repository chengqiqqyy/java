﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool.BarcodeTransform
{
    class Code128Code
    {
        private const int cSHIFT = 98;
        private const int cCODEA = 101;
        private const int cCODEB = 100;
        private const int cSTARTA = 103;
        private const int cSTARTB = 104;
        private const int cSTOP = 106;

        public int[] CodesForChar(int charAscii, int nextCharAscii, CodeSet currentCodeSet)
        {
            int[] result;
            var shifter = -1;

            // パラメータのASCII文字が現在のコードセットに対応しているかチェック
            if (!CharCompatibleWithCodeset(charAscii, currentCodeSet))
            {
                // 続く文字が存在し、その文字が現在のコードセットに対応しているかチェック
                if (nextCharAscii != -1 && !CharCompatibleWithCodeset(nextCharAscii, currentCodeSet))
                {
                    // 次の文字もコードセットを切り替える必要がある場合
                    if (currentCodeSet == CodeSet.CodeA)
                    {
                        shifter = cCODEB;
                        currentCodeSet = CodeSet.CodeB;
                    }
                    else if (currentCodeSet == CodeSet.CodeB)
                    {
                        shifter = cCODEA;
                        currentCodeSet = CodeSet.CodeA;
                    }
                }
                else
                {
                    // 次の文字がない、あるいは次の文字ではコードセットを切り替える必要がない場合はシフトコードを付与
                    shifter = cSHIFT;
                }
            }

            if (shifter != -1)
            {
                // コードセットの切り替え、もしくはシフトコードを付与する場合
                result = new int[2];
                result[0] = shifter;
                result[1] = CodeValueForChar(charAscii);
            }
            else
            {
                result = new int[1];
                result[0] = CodeValueForChar(charAscii);
            }

            return result;
        }

        public bool CharCompatibleWithCodeset(int charAscii, CodeSet currentCodeSet)
        {
            var csa = CodesetAllowedForChar(charAscii);

            return csa == CodeSetAllowed.CodeAorB || (csa == CodeSetAllowed.CodeA && currentCodeSet == CodeSet.CodeA) || (csa == CodeSetAllowed.CodeB && currentCodeSet == CodeSet.CodeB);
        }

        public CodeSetAllowed CodesetAllowedForChar(int charAscii)
        {
            if (charAscii >= 32 && charAscii <= 95)
            {
                // CODE-A、CODE-B共通対応ACSII文字
                return CodeSetAllowed.CodeAorB;
            }
            else if (charAscii < 32)
            {
                // 制御文字（DEL以外）の場合はCODE-A
                return CodeSetAllowed.CodeA;
            }
            else
            {
                // 小文字英字、記号( `, {, |, }, ~ )、制御文字(DELのみ)はCODE-B
                return CodeSetAllowed.CodeB;
            }
        }

        public int CodeValueForChar(int charAscii)
        {
            // ASCIIコードから読み替えたコードデータ番号を返す
            if (charAscii >= 32)
            {
                return charAscii - 32;
            }
            else
            {
                return charAscii + 64;
            }
        }

        public int StartCodeForCodeSet(CodeSet cs)
        {
            if (cs == CodeSet.CodeA)
            {
                return cSTARTA;
            }
            else
            {
                return cSTARTB;
            }
        }

        public int StopCode()
        {
            return cSTOP;
        }
    }
}
