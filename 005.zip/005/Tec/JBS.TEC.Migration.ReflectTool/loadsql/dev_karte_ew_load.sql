﻿SELECT 
 *
FROM 
[dbo].[mid_dev_karte_ew]