﻿using BatchCommon.Helper;
using BatchCommon.Log;
using JBS_BT_T00.EntityService;
using JBS_BT_T00.Parallel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.EntityService
{
    public class EntityDataService
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        protected CrmServiceClient _service;
        protected IList<EntityData> _targetEntityDatas;

        public CrmServiceClient CrmService { get => _service; set => _service = value; }

        public EntityDataService()
        {

        }

        public virtual void DeleteEntityAllData(string entityName)
        {
            _logger.Info($"一括削除処理開始:{entityName}");
            var queryExpression = new QueryExpression(entityName);
            var queryResults = CDSHelper.GetAllData(CrmService, queryExpression);

            _logger.Info($"削除対象件数：{queryResults.Entities.Count}");
            if (queryResults.Entities.Count == 0)
                return;

            _targetEntityDatas = new List<EntityData>();

            foreach (var entity in queryResults.Entities)
            {
                _targetEntityDatas.Add(new EntityData() { TargetEntity = entity, ActionType = EntityActionType.Delete });
            }

            var result = RefectEntityData();

            _logger.Info("一括削除処理完了");
        }
        public virtual void DeactiveEntityAllData(string entityName)
        {
            _logger.Info($"非アクティブ処理開始:{entityName}");
            var queryExpression = new QueryExpression(entityName);
            queryExpression.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            var queryResults = CDSHelper.GetAllData(CrmService, queryExpression);

            _logger.Info($"非アクティブ対象件数：{queryResults.Entities.Count}");
            if (queryResults.Entities.Count == 0)
                return;

            foreach (var entity in queryResults.Entities)
            {
                // 非アクティブ対象リストに追加
                var inactiveEnt = new Entity(entity.LogicalName, entity.Id);
                inactiveEnt["statecode"] = new OptionSetValue(1);
                inactiveEnt["statuscode"] = new OptionSetValue(2);

                _targetEntityDatas.Add(new EntityData() { TargetEntity = inactiveEnt, ActionType = EntityActionType.Update });
            }

            var result = RefectEntityData();

            _logger.Info("一括削除処理完了");
        }

        protected virtual ParallelContext RefectEntityData()
        {
            var parallelContext = new ParallelContext() { ThreadCount = 1, BlockCount = 10 };

            if (parallelContext.ThreadCount > 1)
            {
                //並列処理を行う
                ParallelController.Run(
                    CreateCsvExecutor,
                    GetNextBlockRows,
                    ProcessBlockRowsFinish,
                    parallelContext
                    );
            }
            else
            {
                var executor = new EntityDataExecutor(parallelContext);
                executor.CrmService = CrmService.Clone();
                while (true)
                {
                    var batchData = GetNextBlockRows(parallelContext.BlockCount, parallelContext);
                    if (batchData?.Count == 0)
                        break;

                    var results = executor.Execute(batchData);

                    ProcessBlockRowsFinish(results, parallelContext);
                }
            }
            return parallelContext;
        }

        protected virtual EntityDataExecutor CreateCsvExecutor(ParallelContext pContext)
        {
            var csvImportExecutor = new EntityDataExecutor(pContext);
            csvImportExecutor.CrmService = CrmService.Clone();

            return csvImportExecutor;
        }

        protected virtual IList<EntityData> GetNextBlockRows(int blockCount, ParallelContext pContext)
        {
            if (pContext.AutoPartitionCount < _targetEntityDatas.Count())
            {
                var partitionData = _targetEntityDatas.Skip(pContext.AutoPartitionCount).Take(pContext.BlockCount).ToList();
                pContext.AutoPartitionCount += pContext.BlockCount;
                return partitionData;
            }
            else
            {
                return null;
            }
        }

        protected virtual void ProcessBlockRowsFinish(IList<TaskResult<EntityData>> taskResults, ParallelContext pContext)
        {
            foreach (var taskResult in taskResults)
            {
                if (taskResult.ResultType == TaskResultType.SUCCESS)
                {
                    if (pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.SuccessCount++;
                    }
                }
                else if (taskResult.ResultType == TaskResultType.WARNING)
                {
                    if (pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.WarningCount++;
                    }
                }
                else
                {
                    if (pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.ErrorCount++;
                    }
                }
            }
        }
    }
}
