﻿INSERT INTO mid_dev_store
(
overriddencreatedon,
dev_contact,
dev_participants,
dev_relationship,
dev_contract,
dev_contract_valid,
dev_auto_create_flag,
dev_relationship_number,
owneridtype,
ownerid,
statuscode
)

SELECT
a.overriddencreatedon as overriddencreatedon,--作成日
a.dev_participants as dev_contact,--お客様
a.dev_contact as dev_participants,--関係者
CASE 
WHEN a.dev_relationship = 277670005 THEN 277670006
WHEN a.dev_relationship = 277670007 THEN 277670008
ELSE NULL
END as dev_relationship,--関係性
a.dev_contract as dev_contract,--契約情報
a.dev_contract_valid as dev_contract_valid,--契約有効
CONVERT(BIT, 'TRUE') as dev_auto_create_flag,--オート作成フラグ
'Random' as dev_relationship_number,--関係性番号
a.owneridtype as owneridtype,--OwnerIdType
a.ownerid as ownerid,--所有者
a.statuscode as statuscode--ステータス

FROM mid_dev_participants a