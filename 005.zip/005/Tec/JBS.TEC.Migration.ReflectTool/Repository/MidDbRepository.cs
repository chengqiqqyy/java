﻿using JBS.TEC.Migration.ReflectTool.Dto;
using NLog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool.Repository
{
    public class MidDbRepository
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        private ToolContext _context;
        private SqlConnection _sqlConnection;

        public MidDbRepository(ToolContext context)
        {
            _context = context;
            _sqlConnection = new SqlConnection(_context.SqlServerConnectionString);
            _sqlConnection.Open();
        }

        /// <summary>
        /// テーブル情報を取得
        /// </summary>
        /// <param name="tableName"></param>
        /// <returns></returns>
        public DataTable GetSchemaTable(string tableName)
        {
            string sql = $"select * from {tableName} WHERE 1 = 0";
            _logger.Debug("GetSchemaTable:" + sql);

            SqlCommand sqlCommand = new SqlCommand(sql, _sqlConnection);
            sqlCommand.CommandTimeout = _context.CommandTimeOut;
            using (SqlDataAdapter adatapter = new SqlDataAdapter(sqlCommand))
            {
                DataTable schema = new DataTable();
                adatapter.Fill(schema);
                return schema;
            }
        }

        /// <summary>
        /// sql実行
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public int ExecuteSql(string sql)
        {
            _logger.Debug("ExecuteSql:" + sql);

            SqlCommand sqlCommand = new SqlCommand(sql, _sqlConnection);
            sqlCommand.CommandTimeout = _context.CommandTimeOut;
            int count = sqlCommand.ExecuteNonQuery();

            _logger.Debug($"ExecuteSql Count:{count}");
            return count;
        }

        /// <summary>
        /// SqlBulkCopyを作成
        /// </summary>
        /// <returns></returns>
        public SqlBulkCopy GetSqlBulkCopy()
        {
            var bulkCopy = new SqlBulkCopy(_sqlConnection);
            bulkCopy.BulkCopyTimeout = _context.CommandTimeOut;
            return bulkCopy;
        }

        /// <summary>
        /// ミドルテーブルステータス更新
        /// </summary>
        /// <param name="midTableName"></param>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public int UpdateTargetData(string midTableName, GuidMapping mapping)
        {
            string guidSql = $@"
              update a
              set a.mid_status=9999
              from [{midTableName}] a
              inner join [{mapping.MidTable}] b
                 on a.{mapping.Attribute}=b.mid_oldkey
              where b.mid_status = 9999
            ";

            _logger.Trace("UpdateTargetData:" + guidSql);

            SqlCommand command = new SqlCommand(guidSql, _sqlConnection)
            {
                CommandTimeout = _context.CommandTimeOut
            };

            int count = command.ExecuteNonQuery();

            _logger.Trace($"UpdateTargetData,反映件数:{count}");

            return count;
        }

        /// <summary>
        /// ミドルテーブルGuid更新
        /// </summary>
        /// <param name="midTableName"></param>
        /// <param name="mapping"></param>
        /// <returns></returns>
        public int UpdateGuidMappingField(string midTableName, GuidMapping mapping)
        {
            string guidSql = $@"
              update a
              set a.{mapping.Attribute}=b.mid_newkey
              from [{midTableName}] a
              inner join [{mapping.MidTable}] b
                 on a.{mapping.Attribute}=b.mid_oldkey and b.mid_newkey is not null
              where a.{mapping.Attribute} is not null
            ";

            _logger.Trace("UpdateGuidMappingField:" + guidSql);

            SqlCommand command = new SqlCommand(guidSql, _sqlConnection)
            {
                CommandTimeout = _context.CommandTimeOut
            };

            int count = command.ExecuteNonQuery();

            _logger.Trace($"UpdateGuidMappingField,反映件数:{count}");

            return count;
        }

        /// <summary>
        /// 反映データ取得
        /// </summary>
        /// <param name="midTableName"></param>
        /// <param name="sql"></param>
        /// <returns></returns>
        public DataTable LoadReflectData(string midTableName, string sql)
        {
            string loadSql = null;

            if (_context.Mode == ToolConsts.MODE_CREATE || _context.Mode == ToolConsts.MODE_ASSOCIATE || _context.Mode == ToolConsts.MODE_DISASSOCIATE)
            {
                loadSql = $"select top {_context.LoadCount} * from {_context.MidTable} where mid_status is null";
            }
            else if (_context.Mode == ToolConsts.MODE_UPDATE)
            {
                loadSql = $"select top {_context.LoadCount} * from {_context.MidTable} where mid_status is null and mid_newkey is not null";
            }
            else if (_context.Mode == ToolConsts.MODE_DELETE)
            {
                loadSql = $"select top {_context.LoadCount} mid_id,mid_status,mid_oldkey,mid_newkey from {_context.MidTable} where  mid_status is null and mid_newkey is not null";
            }
            else
            {
                throw new InvalidOperationException("Invalid Mode");
            }

            if (!string.IsNullOrWhiteSpace(sql))
            {
                loadSql = sql;
            }

            _logger.Info($"LoadReflectData:{loadSql}");

            using (SqlDataAdapter adapter = new SqlDataAdapter(loadSql, _sqlConnection))
            {
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        /// <summary>
        /// ミドルテーブルステータスとGuid更新
        /// </summary>
        /// <param name="midTablename"></param>
        /// <param name="midId"></param>
        /// <param name="newGuid"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public int UpdateMidTableStatus(string midTablename, int midId, Guid newGuid, int status)
        {
            string sql = $"update {midTablename} set mid_status={status},mid_newkey='{newGuid}' where mid_id={midId}";

            SqlCommand sqlCommand = new SqlCommand(sql, _sqlConnection)
            {
                CommandTimeout = _context.CommandTimeOut
            };

            int count = sqlCommand.ExecuteNonQuery();
            return count;
        }

        /// <summary>
        /// ミドルテーブルステータス更新
        /// </summary>
        /// <param name="midTablename"></param>
        /// <param name="midId"></param>
        /// <param name="status"></param>
        /// <param name="errorMsg"></param>
        /// <returns></returns>
        public int UpdateMidTableStatus(string midTablename, int midId, int status, string errorMsg = null)
        {
            string sql = $"update {midTablename} set mid_status=@status,mid_errormessage=@errorMsg where mid_id=@midid";

            SqlCommand sqlCommand = new SqlCommand(sql, _sqlConnection)
            {
                CommandTimeout = _context.CommandTimeOut
            };
            sqlCommand.Parameters.Add("@status", SqlDbType.Int).Value = status;
            sqlCommand.Parameters.Add("@errorMsg", SqlDbType.NVarChar).Value = errorMsg ?? (object)DBNull.Value;
            sqlCommand.Parameters.Add("@midid", SqlDbType.Int).Value = midId;

            int count = sqlCommand.ExecuteNonQuery();
            return count;
        }
    }
}
