﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool.BarcodeTransform
{
    public enum CodeSet
    {
        CodeA,
        CodeB
    }

    public enum CodeSetAllowed
    {
        CodeA,
        CodeB,
        CodeAorB
    }

}
