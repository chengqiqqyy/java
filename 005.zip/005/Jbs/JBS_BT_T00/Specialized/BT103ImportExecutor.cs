﻿using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Specialized
{
    public class BT103ImportExecutor : CSVImportExecutor
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public BT103ImportExecutor(CSVImportContext context) : base(context)
        {

        }

        // [所有者] 特殊処理
        protected override void SetOwner(CSVFieldData csvFieldData)
        {
            // 所有者設定要否の判断
            if (!_context.JBS_BT_T00_Config.SetOwner || csvFieldData.ColumnMapping.CrmColumn != "overriddencreatedon")
            {
                return;
            }

            var opObj = csvFieldData.CSVRow.EntityData;
            var ownerid = csvFieldData.CSVRow.RowData["m_ownerid"];

            // ユーザー&組織階層キーファイル取得
            var userKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
            var organizationKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_organization_structure");

            if(ownerid.Length == 3)
            {
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                // 組織階層区分
                keyValues.Add("tsb_ops_type_organization", "100000004");
                // 組織コード
                keyValues.Add("tsb_slt_name_or_code", ownerid);
                // 検索
                var rows = organizationKeyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_028, csvFieldData.CSVRow.RowNum, ownerid));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_028, csvFieldData.CSVRow.RowNum, ownerid));
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", ownerid));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", ownerid));
                }

                // ラインID
                var lineid = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line"].ToString();

                if (!string.IsNullOrEmpty(lineid))
                {
                    // ラインの組織階層検索
                    keyValues.Clear();
                    keyValues.Add("guid", lineid);
                    rows = organizationKeyFile.Query(keyValues);

                    // ライン(所有者チーム)ID
                    var team = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line_team"].ToString();

                    if (!string.IsNullOrEmpty(team))
                    {
                        // 所有者設定
                        opObj["ownerid"] = new EntityReference("team", new Guid(team));
                    }
                    else
                    {
                        if (_context.JBS_BT_T00_Config.OwnerSkip)
                        {
                            // 特定システムユーザーセット
                            opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                            _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, ownerid));
                            return;
                        }
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, ownerid));
                    }
                }
                else
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, ownerid));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, ownerid));
                }
            }
            else
            {
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                // 行員番号
                keyValues.Add("tsb_slt_bank_clerk_id", ownerid);
                // 検索
                var rows = userKeyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    return;
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "systemuser", "ownerid", ownerid));
                }
                // 所有者設定
                opObj["ownerid"] = new EntityReference("systemuser", new Guid(rows[0]["guid"].ToString()));
            }
        }

    }
}
