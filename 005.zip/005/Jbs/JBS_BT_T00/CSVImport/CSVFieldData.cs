﻿using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVFieldData
    {
        public string FieldValue { get; set; }

        public Mapping ColumnMapping { get; set; }
        public AttributeMetadata Metadata { get; set; }

        public CSVRowData CSVRow { get; set; }
    }
}
