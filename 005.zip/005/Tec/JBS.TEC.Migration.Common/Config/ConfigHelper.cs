﻿using System;
using System.Globalization;
using System.Reflection;

namespace JBS.TEC.Migration.Common.Config
{
    public class ConfigHelper
    {
        public static void MappingToObject(object target)
        {
            foreach (var prop in target.GetType().GetProperties())
            {
                if (!prop.CanWrite)
                    continue;
                var attributes = prop.GetCustomAttributes<ConfigMappingAttribute>(true);
                foreach(var attribute in attributes)
                {
                    SetPropValue(target, prop, attribute);
                }
            }
        }
        private static void SetPropValue(object target, PropertyInfo property, ConfigMappingAttribute attribute)
        {
            var configName = attribute.Name;
            if (string.IsNullOrEmpty(attribute.Name))
                configName = property.Name;
            var configValue = ConfigManager.AppSettings[configName];
            if (string.IsNullOrWhiteSpace(configValue))
            {
                if (attribute.IsRequired)
                    throw new ConfigException($"構成ファイルに{attribute.Name}という項目の値が存在しません");
                else
                    return;
            }
            object targetVal = null;
            switch (property.PropertyType)
            {
                case Type boolType when (boolType == typeof(bool) || boolType == typeof(bool?)):
                    if (configValue=="1"|| configValue == "0")
                    {
                        targetVal = configValue == "1" ? true : false;
                    }
                    else if (configValue=="true"|| configValue=="false")
                    {
                        targetVal = configValue == "true" ? true : false;
                    }
                    else
                    {
                        throw new ConfigException($"構成ファイルに{attribute.Name}項目がBool型ではありません");
                    }
                    break;
                case Type dateTimeType when (dateTimeType == typeof(DateTime) || dateTimeType == typeof(DateTime?)):
                    DateTime dateTime;
                    //if (DateTime.TryParseExact(configValue,attribute.Formatter, null, DateTimeStyles.None, out dateTime))
                    if (DateTime.TryParse(configValue, out dateTime))
                    {
                        targetVal = dateTime;
                    }
                    else
                    {
                        throw new ConfigException($"構成ファイルに{attribute.Name}項目が日付型ではありません");
                    }
                    break;
                default:
                    try
                    {
                        targetVal = Convert.ChangeType(configValue, property.PropertyType, null);
                    }
                    catch (Exception ex)
                    {
                        throw new ConfigException($"構成ファイルに{attribute.Name}項目の値が解析できません", ex);
                    }
                    break;
            }
            property.SetValue(target, targetVal);
        }
    }
}
