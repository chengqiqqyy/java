﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace JBS.Common.CDS
{
    public static class CDSExtensions
    {
        public static IEnumerable<T> FetchQuery<T>(this IOrganizationService service, string fetchXml) where T : new()
        {
            FetchExpression fetchQuery = new FetchExpression(fetchXml);
            var result = service.RetrieveMultiple(fetchQuery);
            foreach (var entity in result.Entities)
            {
                yield return entity.MapTo<T>();
            }
        }
        public static IEnumerable<T> FetchQueryAll<T>(this IOrganizationService service, string fetchXml) where T : new()
        {
            var results = service.FetchQueryAll(fetchXml);
            foreach (var entity in results)
            {
                yield return entity.MapTo<T>();
            }
        }
        public static List<Entity> FetchQueryAll(this IOrganizationService service, string fetchXml)
        {
            int fetchCount = 5000;
            int pageNumber = 1;
            string pagingCookie = null;

            List<Entity> lstResult = new List<Entity>();
            while (true)
            {
                string pagingFetchXml = CreateXml(fetchXml, pagingCookie, pageNumber, fetchCount);

                var fetchRequest = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(pagingFetchXml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest)).EntityCollection;
                lstResult.AddRange(returnCollection.Entities);

                if (returnCollection.MoreRecords)
                {
                    pageNumber++;
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    break;
                }
            }
            return lstResult;
        }
        public static EntityCollection FetchQueryPaging(this IOrganizationService service, string fetchXml, int pageNumber, int pageSize)
        {
            string pagingFetchXml = CreateXml(fetchXml, null, pageNumber, pageSize);
            var fetchRequest = new RetrieveMultipleRequest
            {
                Query = new FetchExpression(pagingFetchXml)
            };

            EntityCollection returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest)).EntityCollection;
            return returnCollection;
        }
        public static CDSPageData<T> FetchQueryPaging<T>(this IOrganizationService service, string fetchXml, int pageNumber, int pageSize) where T : new()
        {
            var pageResult = service.FetchQueryPaging(fetchXml, pageNumber, pageSize);

            CDSPageData<T> typePageResult = new CDSPageData<T>();

            typePageResult.Items = pageResult.Entities.MapTo<T>().ToList();
            typePageResult.CurrentPage = pageNumber;
            typePageResult.ItemsPerPage = pageSize;
            typePageResult.TotalItems = pageResult.TotalRecordCount;
            typePageResult.TotalPages = pageResult.TotalRecordCount / pageSize;
            if (pageResult.TotalRecordCount % pageSize != 0)
                typePageResult.TotalPages += 1;

            return typePageResult;
        }
        public static List<T> QueryByGuids<T>(this IOrganizationService service, string entityName, List<Guid> guids) where T : Entity
        {
            QueryExpression query = new QueryExpression(entityName);
            query.ColumnSet.AllColumns = true;
            query.Criteria = new FilterExpression(LogicalOperator.Or);
            guids.ForEach(r => query.Criteria.AddCondition(entityName + "id", ConditionOperator.Equal, r));
            var result = service.RetrieveMultiple(query);
            return result.Entities.Select(r => r.ToEntity<T>()).ToList();
        }
        public static EntityCollection QueryAll(this IOrganizationService service, QueryExpression query)
        {
            query.PageInfo = new PagingInfo()
            {
                Count = 5000,
                PageNumber = 1,
                PagingCookie = null
            };
            EntityCollection returnCollection = new EntityCollection();
            while (true)
            {
                EntityCollection results = service.RetrieveMultiple(query);
                if (results.Entities != null)
                {
                    returnCollection.Entities.AddRange(results.Entities);
                }
                if (results.MoreRecords)
                {
                    query.PageInfo.PageNumber++;
                    query.PageInfo.PagingCookie = results.PagingCookie;
                }
                else
                {
                    break;
                }
            }
            return returnCollection;
        }
        public static string GetDisplayName(this IOrganizationService service, string entityName, string attributeName)
        {
            RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entityName,
                LogicalName = attributeName
            };
            var attributeResponse = (RetrieveAttributeResponse)service.Execute(attributeRequest);
            return attributeResponse.AttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
        public static IEnumerable<T> MapTo<T>(this IEnumerable<Entity> entities) where T : new()
        {
            foreach (var entity in entities)
            {
                yield return entity.MapTo<T>();
            }
        }
        private static string CreateXml(string fetchXml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(fetchXml);
            var reader = new XmlTextReader(stringReader);

            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }

        private static string CreateXml(XmlDocument fetchXmlDoc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = fetchXmlDoc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = fetchXmlDoc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = fetchXmlDoc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = fetchXmlDoc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            fetchXmlDoc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        public static T MapTo<T>(this Entity entity) where T : new()
        {
            T obj = new T();
            foreach (var prop in obj.GetType().GetProperties())
            {
                if (!prop.CanWrite)
                    continue;

                bool isPrimitiveType = prop.PropertyType.IsPrimitive
                    || prop.PropertyType.IsValueType
                    || prop.PropertyType == typeof(Decimal)
                    || (prop.PropertyType == typeof(string));
                if (!isPrimitiveType)
                    continue;

                var propName = prop.Name;
                var attribute = prop.GetCustomAttribute<EntityResultAttribute>();
                if (attribute != null)
                    propName = attribute.Key;

                if (entity.Contains(propName) && entity[propName] != null)
                {
                    var entityVal = entity[propName];
                    if (entityVal is AliasedValue)
                        entityVal = ((AliasedValue)entityVal).Value;
                    var displayValue = entity.FormattedValues.Contains(propName) ? entity.FormattedValues[propName] : null;
                    SetPropValue(obj, prop, entityVal, displayValue, attribute);
                }
            }
            return obj;
        }

        private static void SetPropValue(object obj, PropertyInfo propertyInfo, object entityVal, object displayValue, EntityResultAttribute attribute)
        {
            if (entityVal is EntityReference)
            {
                if (attribute != null && attribute.IsDisplayName)
                {
                    entityVal = displayValue;
                }
                else
                {
                    entityVal = ((EntityReference)entityVal).Id;
                }
            }
            else if (entityVal is OptionSetValue)
            {
                if (attribute != null && attribute.IsDisplayName)
                {
                    entityVal = displayValue;
                }
                else
                {
                    entityVal = ((OptionSetValue)entityVal).Value;
                }
            }
            else if (entityVal is Boolean)//二つのオプションセット
            {
                if (attribute != null && attribute.IsDisplayName)
                {
                    entityVal = displayValue;
                }
            }
            else if (entityVal is DateTime)
            {
                entityVal = ((DateTime)entityVal).AddHours(9);//日本時間に変換
            }

            if (propertyInfo.PropertyType == typeof(string))
                propertyInfo.SetValue(obj, entityVal?.ToString(), null);
            else
            {
                var isNullableType = propertyInfo.PropertyType.IsGenericType && propertyInfo.PropertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
                var targetType = isNullableType ? Nullable.GetUnderlyingType(propertyInfo.PropertyType) : propertyInfo.PropertyType;
                if (targetType.IsEnum)
                {
                    propertyInfo.SetValue(obj, Enum.Parse(targetType, entityVal.ToString()));
                }
                else
                {
                    propertyInfo.SetValue(obj, Convert.ChangeType(entityVal, targetType, null));
                }
            }
        }
        public static T GetAliasedAttributeValue<T>(this Entity entity, string attributeName)
        {
            if (entity == null)
                return default(T);

            AliasedValue fieldAliasValue = entity.GetAttributeValue<AliasedValue>(attributeName);

            if (fieldAliasValue == null)
                return default(T);

            if (fieldAliasValue.Value != null && fieldAliasValue.Value.GetType() == typeof(T))
            {
                return (T)fieldAliasValue.Value;
            }

            return default(T);
        }
        public static T ToAliasedEntity<T>(this Entity entity, string entityAlias, string entityName = null) where T : Entity
        {
            string prefix = entityAlias + ".";
            var targetAttributes = entity.Attributes.Where(r => r.Key.StartsWith(prefix))
                .Select(r => new KeyValuePair<string, object>(r.Key.Substring(prefix.Length), (r.Value is AliasedValue) ? ((AliasedValue)r.Value).Value : r.Value)).ToList();
            var targetFormattedValues = entity.FormattedValues.Where(r => r.Key.StartsWith(prefix))
                .Select(r => new KeyValuePair<string, string>(r.Key.Substring(prefix.Length), r.Value)).ToList();
            if (targetAttributes.Count == 0)
                return null;

            T newEntity = (T)Activator.CreateInstance(typeof(T));
            if (entityName != null)
                newEntity.LogicalName = entityName;
            newEntity.Attributes.AddRange(targetAttributes);
            newEntity.FormattedValues.AddRange(targetFormattedValues);
            if (newEntity.LogicalName != null && newEntity.Contains(newEntity.LogicalName + "id"))
            {
                newEntity.Id = newEntity.GetAttributeValue<Guid>(newEntity.LogicalName + "id");
            }
            return newEntity;
        }
    }
}
