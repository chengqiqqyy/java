﻿using BatchCommon;
using BatchCommon.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchCommon.Log
{
    public class Logger : ILogger
    {
        private NLog.Logger _logger;
        public Logger(NLog.Logger logger)
        {
            _logger = logger;
        }
        public void Trace(string message)
        {
            _logger.Trace(message);
        }
        public void Debug(string message)
        {
            _logger.Debug(message);
        }
        public void Info(string message)
        {
            _logger.Info(message);
        }
        public void Warn(string message)
        {
            _logger.Warn(message);
        }
        public void Error(string message)
        {
            _logger.Error(message);
        }
        public void Error(Exception ex)
        {
            _logger.Error(ex);
        }
    }
}
