﻿using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;

namespace JBS.TEC.Migration.ReflectTool.BarcodeTransform
{
    public class MakeBarcode
    {
        // 出力するバーコードのセッティング用定数
        private const int cBarWeight = 1;
        private const int cQuietWidth = 30;
        private const bool cAddQuietZone = true;
        private int[,] cPatterns = new int[,]
        {
            {2, 1, 2, 2, 2, 2, 0, 0}, {2, 2, 2, 1, 2, 2, 0, 0}, {2, 2, 2, 2, 2, 1, 0, 0},
            {1, 2, 1, 2, 2, 3, 0, 0}, {1, 2, 1, 3, 2, 2, 0, 0}, {1, 3, 1, 2, 2, 2, 0, 0},
            {1, 2, 2, 2, 1, 3, 0, 0}, {1, 2, 2, 3, 1, 2, 0, 0}, {1, 3, 2, 2, 1, 2, 0, 0},
            {2, 2, 1, 2, 1, 3, 0, 0}, {2, 2, 1, 3, 1, 2, 0, 0}, {2, 3, 1, 2, 1, 2, 0, 0},
            {1, 1, 2, 2, 3, 2, 0, 0}, {1, 2, 2, 1, 3, 2, 0, 0}, {1, 2, 2, 2, 3, 1, 0, 0},
            {1, 1, 3, 2, 2, 2, 0, 0}, {1, 2, 3, 1, 2, 2, 0, 0}, {1, 2, 3, 2, 2, 1, 0, 0},
            {2, 2, 3, 2, 1, 1, 0, 0}, {2, 2, 1, 1, 3, 2, 0, 0}, {2, 2, 1, 2, 3, 1, 0, 0},
            {2, 1, 3, 2, 1, 2, 0, 0}, {2, 2, 3, 1, 1, 2, 0, 0}, {3, 1, 2, 1, 3, 1, 0, 0},
            {3, 1, 1, 2, 2, 2, 0, 0}, {3, 2, 1, 1, 2, 2, 0, 0}, {3, 2, 1, 2, 2, 1, 0, 0},
            {3, 1, 2, 2, 1, 2, 0, 0}, {3, 2, 2, 1, 1, 2, 0, 0}, {3, 2, 2, 2, 1, 1, 0, 0},
            {2, 1, 2, 1, 2, 3, 0, 0}, {2, 1, 2, 3, 2, 1, 0, 0}, {2, 3, 2, 1, 2, 1, 0, 0},
            {1, 1, 1, 3, 2, 3, 0, 0}, {1, 3, 1, 1, 2, 3, 0, 0}, {1, 3, 1, 3, 2, 1, 0, 0},
            {1, 1, 2, 3, 1, 3, 0, 0}, {1, 3, 2, 1, 1, 3, 0, 0}, {1, 3, 2, 3, 1, 1, 0, 0},
            {2, 1, 1, 3, 1, 3, 0, 0}, {2, 3, 1, 1, 1, 3, 0, 0}, {2, 3, 1, 3, 1, 1, 0, 0},
            {1, 1, 2, 1, 3, 3, 0, 0}, {1, 1, 2, 3, 3, 1, 0, 0}, {1, 3, 2, 1, 3, 1, 0, 0},
            {1, 1, 3, 1, 2, 3, 0, 0}, {1, 1, 3, 3, 2, 1, 0, 0}, {1, 3, 3, 1, 2, 1, 0, 0},
            {3, 1, 3, 1, 2, 1, 0, 0}, {2, 1, 1, 3, 3, 1, 0, 0}, {2, 3, 1, 1, 3, 1, 0, 0},
            {2, 1, 3, 1, 1, 3, 0, 0}, {2, 1, 3, 3, 1, 1, 0, 0}, {2, 1, 3, 1, 3, 1, 0, 0},
            {3, 1, 1, 1, 2, 3, 0, 0}, {3, 1, 1, 3, 2, 1, 0, 0}, {3, 3, 1, 1, 2, 1, 0, 0},
            {3, 1, 2, 1, 1, 3, 0, 0}, {3, 1, 2, 3, 1, 1, 0, 0}, {3, 3, 2, 1, 1, 1, 0, 0},
            {3, 1, 4, 1, 1, 1, 0, 0}, {2, 2, 1, 4, 1, 1, 0, 0}, {4, 3, 1, 1, 1, 1, 0, 0},
            {1, 1, 1, 2, 2, 4, 0, 0}, {1, 1, 1, 4, 2, 2, 0, 0}, {1, 2, 1, 1, 2, 4, 0, 0},
            {1, 2, 1, 4, 2, 1, 0, 0}, {1, 4, 1, 1, 2, 2, 0, 0}, {1, 4, 1, 2, 2, 1, 0, 0},
            {1, 1, 2, 2, 1, 4, 0, 0}, {1, 1, 2, 4, 1, 2, 0, 0}, {1, 2, 2, 1, 1, 4, 0, 0},
            {1, 2, 2, 4, 1, 1, 0, 0}, {1, 4, 2, 1, 1, 2, 0, 0}, {1, 4, 2, 2, 1, 1, 0, 0},
            {2, 4, 1, 2, 1, 1, 0, 0}, {2, 2, 1, 1, 1, 4, 0, 0}, {4, 1, 3, 1, 1, 1, 0, 0},
            {2, 4, 1, 1, 1, 2, 0, 0}, {1, 3, 4, 1, 1, 1, 0, 0}, {1, 1, 1, 2, 4, 2, 0, 0},
            {1, 2, 1, 1, 4, 2, 0, 0}, {1, 2, 1, 2, 4, 1, 0, 0}, {1, 1, 4, 2, 1, 2, 0, 0},
            {1, 2, 4, 1, 1, 2, 0, 0}, {1, 2, 4, 2, 1, 1, 0, 0}, {4, 1, 1, 2, 1, 2, 0, 0},
            {4, 2, 1, 1, 1, 2, 0, 0}, {4, 2, 1, 2, 1, 1, 0, 0}, {2, 1, 2, 1, 4, 1, 0, 0},
            {2, 1, 4, 1, 2, 1, 0, 0}, {4, 1, 2, 1, 2, 1, 0, 0}, {1, 1, 1, 1, 4, 3, 0, 0},
            {1, 1, 1, 3, 4, 1, 0, 0}, {1, 3, 1, 1, 4, 1, 0, 0}, {1, 1, 4, 1, 1, 3, 0, 0},
            {1, 1, 4, 3, 1, 1, 0, 0}, {4, 1, 1, 1, 1, 3, 0, 0}, {4, 1, 1, 3, 1, 1, 0, 0},
            {1, 1, 3, 1, 4, 1, 0, 0}, {1, 1, 4, 1, 3, 1, 0, 0}, {3, 1, 1, 1, 4, 1, 0, 0},
            {4, 1, 1, 1, 3, 1, 0, 0}, {2, 1, 1, 4, 1, 2, 0, 0}, {2, 1, 1, 2, 1, 4, 0, 0},
            {2, 1, 1, 2, 3, 2, 0, 0}, {2, 3, 3, 1, 1, 1, 2, 0}
        };

        public byte[] PaintImageBarcode128(string value)
        {
            // Bitmapイメージを生成
            var bmpImage = MakeBarcodeImage(value);

            // BitmapイメージをByte配列に変換
            var stream = new MemoryStream();
            bmpImage.Save(stream, ImageFormat.Png);

            var bitmapBytes = stream.ToArray();

            // 終了処理
            stream.Close();
            bmpImage.Dispose();

            // BitmapイメージのByte配列を返す
            return bitmapBytes;
        }

        private Bitmap MakeBarcodeImage(string inputData)
        {
            // パラメータの文字列をCODE128のコードデータ番号に読み替えて配列化
            var codes = new Code128Content(inputData).Codes;

            // Bitmapのサイズを算出
            int width; int height;

            // スタートコード
            width = 11 * cBarWeight;

            // データコード
            // (codes.Length - 3) ⇒ 42行目Code128Content(inputData)にて文字数に3を加算(スタートコード、チェックデジット、ストップコード)しているため
            width += ((codes.Count - 3) * 11) * cBarWeight;

            // チェックデジット
            width += 11 * cBarWeight;

            // ストップコード
            width += 13 * cBarWeight;

            if (cAddQuietZone)
            {
                // Bitmapのサイズに両端のクワイエットゾーン分を補正
                width += 2 * cQuietWidth * cBarWeight;
            }

            height = Convert.ToInt32(Math.Ceiling(Convert.ToSingle(width) * 0.15F));

            // BitmapをNew
            var bmpImage = new Bitmap(width, height);

            using (var drawSurface = Graphics.FromImage(bmpImage))
            {
                // 描画サーフェース全体を白で塗りつぶし
                drawSurface.FillRectangle(Brushes.White, 0, 0, width, height);

                // バーコード化する文字列が空の場合はreturn
                if (string.IsNullOrEmpty(inputData))
                {
                    return bmpImage;
                }

                // バーの描画位置のカーソル
                var cursor = 0;

                // クワイエットゾーンを考慮
                if (cAddQuietZone)
                {
                    cursor = cQuietWidth * cBarWeight;
                }

                // コードデータ番号配列でループし、バーを1本ずつ描画
                for (int codeidx = 0; codeidx < codes.Count; codeidx++)
                {
                    var code = codes[codeidx];

                    // 黒1,白1,黒2,白2,黒3,白3,黒4,白4（黒4、白4は106番目のSTOPコード用）のバーを描画処理
                    for (int bar = 0; bar <= 7; bar += 2)
                    {
                        var barwidth = cPatterns[code, bar] * cBarWeight;
                        var spcwidth = cPatterns[code, bar + 1] * cBarWeight;

                        // 白ですでに初期化済みなので、黒のバーのみ描画
                        if (barwidth > 0)
                        {
                            drawSurface.FillRectangle(Brushes.Black, cursor, 0, barwidth, height);
                        }

                        // カーソル位置を次の描画位置にする
                        cursor += (barwidth + spcwidth);
                    }
                }
            }

            return bmpImage;
        }
    }
}
