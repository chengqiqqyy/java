﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00
{
    /// <summary>
    /// 汎用データ連携
    /// バッチ処理開始クラス
    /// </summary>
    class Program
    {
        /// <summary>
        /// メイン処理
        /// </summary>
        /// <param name="args">起動パラメータ</param>
        /// <returns>処理結果コード</returns>
        static int Main(string[] args)
        {
            // 処理クラスインスタンス作成
            JBS_BT_T00_Logic logic = new JBS_BT_T00_Logic();

            // メイン処理を呼び出す
            return logic.Excute(args);
        }
    }
}
