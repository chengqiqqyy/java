﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.Common.CDS
{
    public class CDSServiceFactory
    {
        public static string CrmConnectionString { get; set; }
        public static IOrganizationService GetCrmService(Guid? userGuid = null)
        {
            var crmServiceClient = new CrmServiceClient(CrmConnectionString);
            if (userGuid != null)
                crmServiceClient.CallerId = userGuid.Value;

            var crmService = new BaseCDSService(crmServiceClient);
            return crmService;
        }
        public static OrganizationServiceContext CreateServiceContext(IOrganizationService crmService = null)
        {
            if (crmService == null)
                crmService = GetCrmService();
            return new OrganizationServiceContext(crmService) { MergeOption = MergeOption.NoTracking };
        }
    }
}
