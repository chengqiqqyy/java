﻿using System;
using System.Collections.Generic;

namespace BatchCommon
{
    /// <summary>
    /// 共通設定情報
    /// </summary>
    public class CommonConfig
    {
        // D365 インスタンスURL
        public string D365Url { get; set; }

        // アプリケーションID
        public string AppId { get; set; }

        // シークレット
        public string Secret { get; set; }

        // ログファイル出力パス
        public string LogOutPath { get; set; }

        // ログファイル保存期間（日）
        public string LogSaveDays { get; set; }

        // バックアップファイル保存期間（日）
        public string BackUpSaveDays { get; set; }

        // エラー継続フラグ
        public bool ErrorContinueFlag { get; set; }

        // リトライMAX総回数
        public int MaxRetryAllCount { get; set; }

        // リトライカウント
        public int MaxRetryCount { get; set; }

        // リトライ待ち時間
        public int RetryPauseTime { get; set; }

        // システム日付
        public DateTime? SystemDate { get; set; }

        // タイムアウト分
        public int? MaxConnectionTimeout { get; set; }

        // 認証情報
        public Dictionary<string, (string appid, string secret)> Authentications { get; set; }
    }
}
