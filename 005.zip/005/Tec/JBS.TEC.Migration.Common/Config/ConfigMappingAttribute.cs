﻿using System;

namespace JBS.TEC.Migration.Common.Config
{
    [AttributeUsage(AttributeTargets.Property, Inherited = true, AllowMultiple = true)]
    public class ConfigMappingAttribute : Attribute
    {
        public string Name { get; set; }
        public bool IsRequired { get; set; }
        public string Formatter { get; set; }
        public ConfigMappingAttribute(string name = null, bool isRequied = false, string fomatter = null)
        {
            Name = name;
            IsRequired = isRequied;
            Formatter = fomatter;
        }
    }
}
