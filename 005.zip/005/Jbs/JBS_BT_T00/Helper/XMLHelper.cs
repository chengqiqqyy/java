﻿using JBS_BT_T00.CSVImport;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace JBS_BT_T00.Helper
{
    public class XMLHelper
    {
        /// <summary>
        /// Elementの存在チェック
        /// </summary>
        /// <param name="pXml">Element</param>
        /// <param name="pTabName">Element名</param>
        public static XElement ElementCheck(XElement pXml, string pTabName)
        {
            var pXmlTab = pXml.Element(pTabName);
            if (pXmlTab == null)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_ERROR_003, pTabName));
            }

            return pXmlTab;
        }
        /// <summary>
        /// ElementのValueチェック
        /// </summary>
        /// <param name="pXml">Element</param>
        /// <param name="pElementName">Element名</param>
        public static string ElementValueCheck(XElement pXml, string pElementName, bool isRequired = true)
        {
            var pElement = pXml.Element(pElementName);
            if (pElement == null || String.IsNullOrWhiteSpace(pElement.Value))
            {
                if (isRequired)
                {
                    // 取得できない場合
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_ERROR_004, pElementName));
                }
                else
                {
                    return null;
                }
            }

            return pElement.Value;
        }
    }
}
