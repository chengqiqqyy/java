﻿using JBS_BT_T00.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace JBS_BT_T00.CSVImport
{
    public class CSVOptionSetService
    {
        protected CSVImportContext _context;
        protected Dictionary<string, Dictionary<string, string>> _optionsetMapping;

        public CSVOptionSetService(CSVImportContext context)
        {
            _context = context;

            InitOptionConfigInfo();
        }
        /// <summary>
        /// 配置ファイル情報取得
        /// </summary>
        protected virtual void InitOptionConfigInfo()
        {
            // オプション情報
            _optionsetMapping = new Dictionary<string, Dictionary<string, string>>();

            // 配置ファイル名
            var configFileName = "JBS-BT-201_Config.xml";
            if (!string.IsNullOrWhiteSpace(_context.JBS_BT_T00_Config.MappingFile))
            {
                configFileName = _context.JBS_BT_T00_Config.MappingFile;
            }

            // 配置ファイルパス
            var configPath = Path.Combine(FileHelper.GetExecutingFolder(), CSVImportConsts.FOLDER_CONFIG, configFileName);

            // 配置ファイル存在チェック
            if (!File.Exists(configPath))
            {
                return;
            }

            // XML情報読み込み
            var wConfig = XElement.Load(configPath);

            // オプション情報リスト
            var optionMaps = wConfig.Elements("OptionMap");

            // オプション情報取得
            foreach (var optionInfo in optionMaps)
            {
                // 対象オプション名
                var optionName = XMLHelper.ElementValueCheck(optionInfo, "OptionName");

                // オプションリスト
                var options = optionInfo.Elements("Option");

                var optionDic = new Dictionary<string, string>();

                // オプション取得
                foreach (var option in options)
                {
                    // 入力値
                    var fromValue = XMLHelper.ElementValueCheck(option, "FromValue");

                    // 変換値
                    var toValue = XMLHelper.ElementValueCheck(option, "ToValue");

                    if (!optionDic.ContainsKey(fromValue))
                    {
                        optionDic.Add(fromValue, toValue);
                    }
                }

                _optionsetMapping.Add(optionName, optionDic);
            }
        }

        public virtual Dictionary<string, string> GetOptionSetMapping(string optionSetName)
        {
            if (_optionsetMapping.ContainsKey(optionSetName))
                return _optionsetMapping[optionSetName];
            else
                return null;
        }
    }
}
