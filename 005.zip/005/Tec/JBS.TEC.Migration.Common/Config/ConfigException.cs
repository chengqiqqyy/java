﻿using System;

namespace JBS.TEC.Migration.Common.Config
{
    public class ConfigException : Exception
    {
        public ConfigException()
        {

        }
        public ConfigException(string message) : base(message)
        {

        }
        public ConfigException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
