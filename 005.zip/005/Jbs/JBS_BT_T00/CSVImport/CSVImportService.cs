﻿using BatchCommon.Helper;
using BatchCommon.Log;
using JBS_BT_T00.Helper;
using JBS_BT_T00.Parallel;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Deployment;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace JBS_BT_T00.CSVImport
{
    public class CSVImportService
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        protected CSVImportContext _context;
        protected CSVImportFactory _factory;
        protected CSVKeyFileService _currentEntityKeyFileService;

        protected string _csvFileName;
        protected TextFieldParser _csvReader;

        protected Lazy<StreamWriter> _errorFileWriter;
        protected Lazy<StreamWriter> _errorFileWithHeaderWriter;

        protected CrmServiceClient _crmService;
        public CrmServiceClient CrmService { get { return _crmService; } set { _crmService = value; } }

        public CSVImportService(CSVImportContext context)
        {
            _context = context;
            _factory = CSVImportFactory.GetInstance();
            _currentEntityKeyFileService = _factory.GetCSVKeyFile(_context.JBS_BT_T00_Config.LogicName);
            _context.ErrorDataList = new List<string>();
            _context.ErrorDataList2 = new List<string>();
            _context.ErrorDataList2.Add(string.Join(_context.Delimiter, _context.JBS_BT_T00_Config.Headers.Select(r => r.DisplayName)));
            var header1 = "行番号" + _context.Delimiter + "エラーメッセージ" + _context.Delimiter;
            header1 += string.Join(_context.Delimiter, _context.JBS_BT_T00_Config.Headers.Select(r => r.DisplayName));
            var header2 = "LineNumber" + _context.Delimiter + "ErrorMessage" + _context.Delimiter;
            header2 += string.Join(_context.Delimiter, _context.JBS_BT_T00_Config.Headers.Select(r => r.LogicName));
            _context.ErrorDataList.Add(header1);
            _context.ErrorDataList.Add(header2);
        }

        public virtual void Execute()
        {
            InitConfig();

            // stubユーザーID取得
            GetStubUserId();
            // ダミーDA番号ID取得
            GetDamiDaNumId();

            // 入力ファイルデータ取得
            var fileNames = new string[] { };

            DirectoryInfo info = new DirectoryInfo(_context.JBS_BT_T00_Config.InputFilePath);
            //古い順でソートする
            FileInfo[] fileInfos = info.GetFiles().OrderBy(p => p.CreationTime).ToArray();
           
            _logger.Info(string.Format("処理対象ファイル件数：{0}", fileInfos.Length));

            // データ一括削除
            DeleteExistedEntityData();

            // ファイルごとに繰り返す
            foreach (FileInfo fileInfo in fileInfos)
            {
                _logger.Info(string.Format("入力ファイル：{0} 処理開始", fileInfo.Name));

                if (PreProcessCSV(fileInfo.FullName))
                {
                    ProcessCSV();
                    PostProcessCSV();
                }
            }

            var nowTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            var path = Path.Combine(_context.JBS_BT_T00_Config.ErrorPath, Path.GetFileNameWithoutExtension(_csvFileName)
                    + "_error_header_" + nowTime + Path.GetExtension(_csvFileName));
            File.AppendAllLines(path, _context.ErrorDataList, _context.JBS_BT_T00_Config.FileEncode);

            var path2 = Path.Combine(_context.JBS_BT_T00_Config.ErrorPath, Path.GetFileNameWithoutExtension(_csvFileName)
                    + "_error_reImport_" + nowTime + Path.GetExtension(_csvFileName));
            File.AppendAllLines(path2, _context.ErrorDataList2, _context.JBS_BT_T00_Config.FileEncode);
        }

        #region CRM列名存在チェック
        /// <summary>
        /// CRM列名存在チェック
        /// </summary>
        /// <param name="attributes"></param>
        protected virtual void CheckCRMFields(List<AttributeMetadata> attributes)
        {
            // CRM列名存在チェック
            foreach (var map in _context.JBS_BT_T00_Config.AllFields)
            {
                foreach (var meta in attributes)
                {
                    if (map.CrmColumn == meta.LogicalName)
                    {
                        map.CrmColumnMetadata = meta;
                        break;
                    }
                }

                // 存在しない場合
                if (map.CrmColumnMetadata == null)
                {
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_001, map.CrmColumn));
                }
            }
        }
        #endregion

        protected virtual void InitConfig()
        {
            _logger.Info("対象エンティティのメータデータ取得");

            // 対象エンティティのメータデータを取得
            var attributes = _crmService.GetAllAttributesForEntity(_context.JBS_BT_T00_Config.LogicName);

            _context.JBS_BT_T00_Config.AttributeMetadatas = attributes;

            // CRM列名チェック処理
            CheckCRMFields(attributes);
        }

        protected virtual void InitCSVReader(string csvFilePath)
        {
            _csvFileName = csvFilePath;
            _csvReader = new TextFieldParser(csvFilePath, _context.JBS_BT_T00_Config.FileEncode);
            _csvReader.TextFieldType = FieldType.Delimited;
            _csvReader.SetDelimiters(new string[] { _context.Delimiter });
            _csvReader.HasFieldsEnclosedInQuotes = false;
            _csvReader.TrimWhiteSpace = true;

            if (_context.JBS_BT_T00_Config.HaveTitle 
                && (_context.JBS_BT_T00_Config.Headers == null || _context.JBS_BT_T00_Config.Headers.Count == 0))
            {
                _context.JBS_BT_T00_Config.Headers = new List<CsvHeader>();

                var headers = _csvReader.ReadFields();
                foreach (var head in headers)
                {
                    var csvHeader = new CsvHeader
                    {
                        LogicName = head,
                        DisplayName = ""
                    };
                    _context.JBS_BT_T00_Config.Headers.Add(csvHeader);
                }
            }

            // タイトルをスキップ
            if (_context.JBS_BT_T00_Config.HaveTitle)
            {
                _csvReader.ReadFields();
            }

            // レコードをスキップ
            string skipLine = null;
            if (_context.environmentArgs.TryGetValue("line", out skipLine))
            {
                var skip = 0;
                if (!int.TryParse(skipLine, out skip))
                {
                    throw new Exception($"スキップ値は整数ではない。line:{skipLine}");
                }
                else if(skip > 1)
                {
                    _logger.Info("レコードスキップ開始..........");

                    for (var i = 1; i < skip; i++)
                    {
                        _csvReader.ReadFields();
                        if(i % 1000 == 0)
                        {
                            _logger.Info($"スキップ処理：{i}/{skip - 1}");
                        }
                        else if(i == skip - 1)
                        {
                            _logger.Info($"スキップ処理：{skip - 1}/{skip - 1}");
                        }
                    }
                    _logger.Info($"スキップ完了、{skipLine}行目から処理開始..........");
                }
            }

            _errorFileWriter = new Lazy<StreamWriter>(() => {
                var outFileName = Path.Combine(_context.JBS_BT_T00_Config.ErrorPath, Path.GetFileNameWithoutExtension(_csvFileName)
                    + "_error_" + DateTime.Now.ToString("yyyyMMddHHmmss") + Path.GetExtension(_csvFileName));
                return new StreamWriter(outFileName, false, _context.JBS_BT_T00_Config.FileEncode);
            });

            _errorFileWithHeaderWriter = new Lazy<StreamWriter>(() => {
                var outFileName = Path.Combine(_context.JBS_BT_T00_Config.ErrorPath, Path.GetFileNameWithoutExtension(_csvFileName)
                    + "_error_header_" + DateTime.Now.ToString("yyyyMMddHHmmss") + Path.GetExtension(_csvFileName));
                var stream = new StreamWriter(outFileName, false, _context.JBS_BT_T00_Config.FileEncode);

                if (_context.JBS_BT_T00_Config.Headers?.Count > 0)
                {
                    if (!string.IsNullOrEmpty(_context.JBS_BT_T00_Config.Headers.First().DisplayName))
                    {
                        var header1 = "行番号" + _context.Delimiter + "エラーメッセージ" + _context.Delimiter;
                        header1 += string.Join(_context.Delimiter, _context.JBS_BT_T00_Config.Headers.Select(r => r.DisplayName));
                        stream.WriteLine(header1);
                    }

                    var header2 = "LineNumber" + _context.Delimiter + "ErrorMessage" + _context.Delimiter;
                    header2 += string.Join(_context.Delimiter, _context.JBS_BT_T00_Config.Headers.Select(r => r.LogicName));
                    stream.WriteLine(header2);
                }
                return stream;
            });
        }

        protected virtual CSVRowData BuildCSVRowData(TextFieldParser csvReader)
        {
            var csvRowData = new CSVRowData();
            csvRowData.Context = _context;
            //行番号
            csvRowData.RowNum = (int)_csvReader.LineNumber;

            string[] rowData = null;
            try
            {
                rowData = csvReader.ReadFields();
            }
            catch (MalformedLineException ex)
            {
                _logger.Error($"CSV解析エラー発生しました、行番号：{csvReader.LineNumber},行内容:{csvReader.ErrorLine}");
                throw ex;
            }

            //元の行データ(加工変換なし）
            csvRowData.RawRowData = string.Join(_context.Delimiter, rowData);

            //長さとヘッダー一致しているかをチェックする。
            if (csvRowData.RowNum == 1 && _context.JBS_BT_T00_Config.Headers?.Count > 0)
            {
                if (_context.JBS_BT_T00_Config.Headers.Count != rowData.Length)
                {
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_020, csvRowData.RowNum, _context.JBS_BT_T00_Config.Headers.Count, rowData.Length));
                }
            }

            csvRowData.DataName = new Dictionary<string, string>();
            csvRowData.RowData = new Dictionary<string, string>();
            csvRowData.OriginRowData = new Dictionary<string, string>();
            int columnIndex = 1;
            foreach (var fieldData in rowData)
            {
                var fieldValue = fieldData;
                //改行コード変換
                if (fieldValue != null)
                {
                    fieldValue = fieldValue.Replace(CSVImportConsts.OVERROW_CHANGE_CODE, CSVImportConsts.OVERROW_CODE);
                    fieldValue = fieldValue.Replace(CSVImportConsts.OVERROW_CHANGE_CODE_B, CSVImportConsts.OVERROW_CODE);
                }
                //ヘッダー定義が存在する場合、ヘッダー定義を利用する
                if (_context.JBS_BT_T00_Config.Headers?.Count > 0)
                {
                    var header = _context.JBS_BT_T00_Config.Headers[(columnIndex++) - 1];
                    var displayName = header.DisplayName;
                    var headerName = header.LogicName;
                    csvRowData.DataName.Add(headerName, displayName);
                    csvRowData.RowData.Add(headerName, fieldValue);
                    csvRowData.OriginRowData.Add(headerName, fieldValue);
                }
                else
                {
                    csvRowData.RowData.Add("Column" + columnIndex, fieldValue);
                    csvRowData.OriginRowData.Add("Column" + (columnIndex++), fieldValue);
                }
            }

            return csvRowData;
        }

        protected virtual bool PreProcessCSV(string fileName)
        {
            InitCSVReader(fileName);
            return true;
        }

        protected virtual void ProcessCSV()
        {
            if (_context.ThreadCount > 1)
            {
                //並列処理を行う
                ParallelController.Run(
                    CreateCsvExecutor,
                    GetNextBlockRows,
                    ProcessBlockRowsFinish,
                    _context
                    );
            }
            else
            {
                var csvImportExecutor = CreateCsvExecutor(_context);
                while (true)
                {
                    var batchData = GetNextBlockRows(_context.BlockCount, _context);
                    if (batchData?.Count == 0)
                        break;

                    var results = csvImportExecutor.Execute(batchData);

                    ProcessBlockRowsFinish(results, _context);

                    if (_context.TotalCount % 1000 == 0 || _csvReader.EndOfData) _logger.Info($"{_context.TotalCount}件を処理しました。");
                }
            }
        }

        protected virtual void PostProcessCSV()
        {
            if (_csvReader != null)
            {
                _csvReader.Dispose();
                _csvReader = null;
            }
            if (_errorFileWriter != null && _errorFileWriter.IsValueCreated)
            {
                _errorFileWriter.Value.Dispose();
                _errorFileWriter = null;
            }
            if (_errorFileWithHeaderWriter != null && _errorFileWithHeaderWriter.IsValueCreated)
            {
                _errorFileWithHeaderWriter.Value.Dispose();
                _errorFileWithHeaderWriter = null;
            }
            if (_currentEntityKeyFileService != null)
            {
                _currentEntityKeyFileService.UpdateKeyFile();
            }
        }
        protected virtual CSVImportExecutor CreateCsvExecutor(CSVImportContext pContext)
        {
            var csvImportExecutor = _factory.GetCSVImportExecutor();
            csvImportExecutor.CrmService = CrmService.Clone();

            return csvImportExecutor;
        }
        protected virtual IList<CSVRowData> GetNextBlockRows(int blockCount, CSVImportContext pContext)
        {
            int recordCount = 0;
            List<CSVRowData> blockRows = new List<CSVRowData>();
            while (recordCount < blockCount && !_csvReader.EndOfData)
            {
                var csvRowData = BuildCSVRowData(_csvReader);

                recordCount++;

                blockRows.Add(csvRowData);
            }
            return blockRows;
        }
        protected virtual void ProcessBlockRowsFinish(IList<TaskResult<CSVRowData>> taskResults, CSVImportContext pContext)
        {
            foreach (var taskResult in taskResults)
            {
                if (taskResult.ResultType == TaskResultType.SUCCESS)
                {
                    if(pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.SuccessCount++;
                    }

                    if (_currentEntityKeyFileService == null) continue;

                    if (!_context.JBS_BT_T00_Config.DoService) continue;

                    if (_context.JBS_BT_T00_Config.SelfLookup) continue;

                    switch (taskResult.TaskData.ActionType)
                    {
                        case EntityActionType.Create:
                            _currentEntityKeyFileService.AddKeyInfo(taskResult.TaskData.EntityData);
                            break;
                        case EntityActionType.Update:
                            _currentEntityKeyFileService.UpdateKeyInfo(taskResult.TaskData.EntityData);
                            break;
                    }
                }
                else if (taskResult.ResultType == TaskResultType.WARNING)
                {
                    if (pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.WarningCount++;
                    }
                }
                else
                {
                    if (pContext.ThreadCount <= 1)
                    {
                        pContext.TotalCount++;
                        pContext.ErrorCount++;
                    }

                    if(taskResult.TaskData.ErrorMessage != null)
                    {
                        _logger.Error($"エラー発生しました、行番号：{taskResult.TaskData.RowNum}、エラーメッセージ:{taskResult.TaskData.ErrorMessage}");
                        OutputErrorFile(taskResult.TaskData);
                    }
                }
            }
        }
        protected virtual void OutputErrorFile(CSVRowData csvRowData)
        {
            lock (_context.SyncObject)
            {
                var errorMessage = csvRowData.ErrorMessage;
                string ouput = csvRowData.RowNum + _context.Delimiter + errorMessage + _context.Delimiter+ csvRowData.RawRowData;
                _context.ErrorDataList.Add(ouput);
                _context.ErrorDataList2.Add(csvRowData.RawRowData);
            }
        }
        protected virtual void DeleteExistedEntityData()
        {
            // 一括削除要否
            if (_context.JBS_BT_T00_Config.NeedDelete == "true")
            {
                var entityService = _factory.GetEntityDataService();
                entityService.CrmService = _crmService;
                entityService.DeleteEntityAllData(_context.JBS_BT_T00_Config.LogicName);
            }
        }
        protected virtual void UnactiveAll()
        {
            if (_context.JBS_BT_T00_Config.NeedInactive)
            {
                // キーなしの場合、すべて非アクティブ
                if (_context.JBS_BT_T00_Config.Keys.Count == 0)
                {
                    var entityService = _factory.GetEntityDataService();
                    entityService.CrmService = _crmService;
                    entityService.DeactiveEntityAllData(_context.JBS_BT_T00_Config.LogicName);
                }
            }
        }
        protected void GetStubUserId()
        {
            if (!string.IsNullOrEmpty(_context.JBS_BT_T00_Config.SpecificUser))
            {
                var userKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                var keyValues = new Dictionary<string, string>();
                keyValues.Add("tsb_slt_bank_clerk_id", _context.JBS_BT_T00_Config.SpecificUser);
                var rows = userKeyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    throw new Exception("stubユーザーが見つかりません。");
                }
                _context.JBS_BT_T00_Config.StubUserId = rows[0]["guid"].ToString();
            }
        }
        protected void GetDamiDaNumId()
        {
            if (!string.IsNullOrEmpty(_context.JBS_BT_T00_Config.SpecificDaNum))
            {
                var userKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_info_da");
                var keyValues = new Dictionary<string, string>();
                keyValues.Add("tsb_slt_num_da", _context.JBS_BT_T00_Config.SpecificDaNum);
                var rows = userKeyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    throw new Exception("ダミーDA番号が見つかりません。");
                }
                _context.JBS_BT_T00_Config.DamiDaNumId = rows[0]["guid"].ToString();
            }
        }
    }
}
