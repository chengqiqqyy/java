﻿namespace JBS.TEC.Migration.ReflectTool
{
    public class ToolConsts
    {
        public const string OUTFOLDER = "out";
        public const string MASKINGFOLDER = "masking";
        public const string TOOLFOLDER = "tool";
        public const string SCHEMAFOLDER = "schema";
        public const string GUIDMAPPING = "guidmapping";
        public const string LOADSQL = "loadsql";
        public const string CONVERTSQL = "convertsql";

        public const string MID_TABLE_ID = "mid_id";
        public const string MID_TABLE_OLDKEY = "mid_oldkey";
        public const string MID_TABLE_NEWKEY = "mid_newkey";
        public const string MID_TABLE_STATUS = "mid_status";

        public const string MID_TABLE_TARGETENTITY = "mid_target_entity";
        public const string MID_TABLE_TARGETENTITY_ID = "mid_target_id";
        public const string MID_TABLE_TARGETENTITY_RELATIONSHIP = "mid_relationship";
        public const string MID_TABLE_TARGETENTITY_RELATED_ENTITY = "mid_related_entity";
        public const string MID_TABLE_TARGETENTITY_RELATED_ENTITY_ID = "mid_related_entity_id";

        public const int MODE_CREATE = 0;
        public const int MODE_UPDATE = 1;
        public const int MODE_DELETE = 2;
        public const int MODE_ASSOCIATE = 3;
        public const int MODE_DISASSOCIATE = 4;

        public const string FIELD_NAME_STATECODE = "statecode";
        public const string FIELD_NAME_STATUSCODE = "statuscode";
        public const string FIELD_NAME_OWNERID = "ownerid";
        public const string FIELD_NAME_OWNERIDTYPE = "owneridtype";

        public const string ENTITY_NAME_SYSTEMUSER = "systemuser";
        public const string ENTITY_NAME_TEAM = "team";

        public const int MID_TABLE_STATUS_SUCCESS = 1;
        public const int MID_TABLE_STATUS_DEACTIVE_SUCCESS = 2;
        public const int MID_TABLE_STATUS_ERROR = -1;
        public const int MID_TABLE_STATUS_DEACTIVE_ERROR = -2;
    }
}
