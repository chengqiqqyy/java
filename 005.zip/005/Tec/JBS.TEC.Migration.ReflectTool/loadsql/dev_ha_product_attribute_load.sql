SELECT 
 *
FROM 
[dbo].[mid_dev_ha_product_attribute]