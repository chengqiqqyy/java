﻿SELECT 
 *
FROM 
[dbo].[mid_dev_service_history]