﻿using CsvHelper;
using CsvHelper.Configuration;
using JBS.TEC.Migration.Common.Config;
using JBS.TEC.Migration.ReflectTool.Repository;
using NLog;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool.Service
{
    public class LoadCSVToMidDBService
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        private ToolContext _context;
        private MidDbRepository _midDbRepository;

        public LoadCSVToMidDBService(ToolContext context)
        {
            _context = context;
            _midDbRepository = new MidDbRepository(_context);
        }

        public void Execute()
        {
            if (!string.IsNullOrWhiteSpace(_context.SchemaFile))
            {
                string scriptFile = Path.Combine(_context.ExtractBaseFolder, ToolConsts.SCHEMAFOLDER, _context.SchemaFile);
                string script = File.ReadAllText(scriptFile, Encoding.GetEncoding("utf-8"));

                _midDbRepository.ExecuteSql(script);
            }

            if (!string.IsNullOrWhiteSpace(_context.CsvFile))
            {
                string midtablename = _context.MidTable;
                string csvFile = Path.Combine(_context.ExtractBaseFolder, ToolConsts.OUTFOLDER, _context.CsvFile);
                var reader = new StreamReader(csvFile, Encoding.GetEncoding("utf-8"));

                SqlBulkCopy sqlBulk = _midDbRepository.GetSqlBulkCopy();
                var schemaTable = _midDbRepository.GetSchemaTable(_context.MidTable);
                var totalCount = 0;

                foreach (DataColumn col in schemaTable.Columns)
                {
                    sqlBulk.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                }

                using (var csv = new CsvReader(reader, CultureInfo.CurrentCulture))
                {
                    var config = new CsvConfiguration(new CultureInfo("ja-JP", false))
                    {
                        HasHeaderRecord = _context.IncludeHeaderRow,
                        Delimiter = _context.Delimiter,
                        BadDataFound = x => { _logger.Info($"Bad data: <{x.RawRecord}>"); }
                    };

                    csv.Read();
                    csv.ReadHeader();
                    var csvHeaderColumns = csv.HeaderRecord.ToList();

                    while (csv.Read())
                    {
                        DataRow dataRow = schemaTable.NewRow();

                        foreach (DataColumn column in schemaTable.Columns)
                        {
                            if (csvHeaderColumns.Contains(column.ColumnName))
                            {
                                if (!string.IsNullOrEmpty(csv.GetField(column.ColumnName)))
                                {
                                    try
                                    {
                                        dataRow[column.ColumnName] = csv.GetField(column.DataType, column.ColumnName);
                                    }
                                    catch (Exception ex)
                                    {
                                        _logger.Error($"Convert Column Value Failed,Column:{ column.ColumnName},Type:{column.DataType},Value:{csv.GetField(column.ColumnName)}");
                                        throw ex;
                                    }
                                }
                            }
                        }

                        schemaTable.Rows.Add(dataRow);

                        if (schemaTable.Rows.Count == 100000)
                        {
                            totalCount += schemaTable.Rows.Count;
                            sqlBulk.DestinationTableName = midtablename;
                            sqlBulk.WriteToServer(schemaTable);
                            schemaTable.Clear();
                        }
                    }
                };

                if (schemaTable.Rows.Count > 0)
                {
                    totalCount += schemaTable.Rows.Count;
                    sqlBulk.DestinationTableName = midtablename;
                    sqlBulk.WriteToServer(schemaTable);
                }
                _logger.Info($"MidTableに登録完了、TableName:{midtablename},件数:{totalCount}");
            }

            if (!string.IsNullOrWhiteSpace(_context.CovertSql))
            {
                string scriptFile = Path.Combine(_context.ExtractBaseFolder, ToolConsts.CONVERTSQL, _context.CovertSql);
                string script = File.ReadAllText(scriptFile, Encoding.GetEncoding("utf-8"));

                _midDbRepository.ExecuteSql(script);
            }
        }
    }
}
