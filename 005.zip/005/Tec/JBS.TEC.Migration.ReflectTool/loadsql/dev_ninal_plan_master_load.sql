SELECT 
 *
FROM 
[dbo].[mid_dev_ninal_plan_master]