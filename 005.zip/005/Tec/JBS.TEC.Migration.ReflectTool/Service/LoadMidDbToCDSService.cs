﻿using BarcodeLib;
using JBS.Common.CDS;
using JBS.TEC.Migration.Common.Config;
using JBS.TEC.Migration.ReflectTool.BarcodeTransform;
using JBS.TEC.Migration.ReflectTool.Dto;
using JBS.TEC.Migration.ReflectTool.Repository;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using NLog;
using NLog.Targets;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using C = JBS.TEC.Migration.ReflectTool.ToolConsts;

namespace JBS.TEC.Migration.ReflectTool.Service
{
    class LoadMidDbToCDSService
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        private ToolContext _context;
        private MidDbRepository _midDbRepository;
        private readonly Dictionary<string, string> BARCODE_FIELDS = new Dictionary<string, string>() 
        { 
            { "dev_barcode_of_customer_id", "dev_customer_id" },
            { "dev_barcode_of_item_no", "dev_part_no" },
            { "dev_barcode_of_repair_no", "dev_repair_no" },
        };

        public LoadMidDbToCDSService(ToolContext context)
        {
            _context = context;
            _midDbRepository = new MidDbRepository(_context);
        }

        public void Execute(string[] args)
        {
            SqlConnection sqlConnection = new SqlConnection(_context.SqlServerConnectionString);
            sqlConnection.Open();

            if (!string.IsNullOrWhiteSpace(_context.GuidMappingFile))
            {
                var lstMapping = GetGuidMappings();

                foreach (var mapping in lstMapping)
                {
                    if (string.IsNullOrWhiteSpace(mapping.Sql))
                    {
                        if (_context.IsTargetData)
                        {
                            _midDbRepository.UpdateTargetData(_context.MidTable, mapping);
                        }
                        _midDbRepository.UpdateGuidMappingField(_context.MidTable, mapping);
                    }
                    else
                    {
                        string sqlFile = Path.Combine(ToolHelper.GetExecutingFolder(), C.CONVERTSQL, mapping.Sql);
                        var sql = File.ReadAllText(sqlFile, Encoding.GetEncoding("utf-8"));
                        _midDbRepository.ExecuteSql(sql);
                    }
                }
            }

            string loadSql = null;
            if (!string.IsNullOrWhiteSpace(_context.LoadSql))
            {
                string loadSqlFile = Path.Combine(ToolHelper.GetExecutingFolder(), C.LOADSQL, _context.LoadSql);
                loadSql = File.ReadAllText(loadSqlFile, Encoding.GetEncoding("utf-8"));
            }

            List<string> lstIncludeFields = null;
            if (!string.IsNullOrWhiteSpace(_context.IncludeFields))
            {
                lstIncludeFields = _context.IncludeFields.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(r => r.Trim()).ToList();
                _logger.Info("Include Fields:" + string.Join(",", lstIncludeFields));
            }

            List<string> lstExcludeFields = null;
            if (!string.IsNullOrWhiteSpace(_context.ExcludeFields))
            {
                lstExcludeFields = _context.ExcludeFields.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(r => r.Trim()).ToList();
                _logger.Info("Exclude Fields:" + string.Join(",", lstExcludeFields));
            }

            var service = CDSServiceFactory.GetCrmService();
            List<AttributeMetadata> attributes = null;
            if (!string.IsNullOrWhiteSpace(_context.EntityName))
            {
                attributes = getEntityAttributes(_context.EntityName, service);

                if (lstIncludeFields != null)
                {
                    attributes = attributes.Where(r => lstIncludeFields.Contains(r.LogicalName)).ToList();
                }
                if (lstExcludeFields != null)
                {
                    attributes = attributes.Where(r => !lstExcludeFields.Contains(r.LogicalName)).ToList();
                }
            }

            while (true)
            {
                var targetDataTable = _midDbRepository.LoadReflectData(_context.MidTable, loadSql);

                _logger.Info("処理対象件数:" + targetDataTable.Rows.Count);
                
                if (targetDataTable.Rows.Count == 0) break;

                if (_context.TotalCount==0 && attributes?.Count > 0)
                {
                    foreach (DataColumn col in targetDataTable.Columns)
                    {
                        if (!col.ColumnName.StartsWith("mid_") && !attributes.Any(r => r.LogicalName == col.ColumnName))
                        {
                            _logger.Info("反映されない列:" + col.ColumnName);
                        }
                    }
                }

                _logger.Info("処理済み総件数:" + _context.TotalCount);
                _context.TotalCount += targetDataTable.Rows.Count;

                var lstBatchEntity = new List<(DataRow, Entity)>();

                foreach (DataRow dataRow in targetDataTable.Rows)
                {
                    Entity entity = null;
                    if (_context.Mode != C.MODE_ASSOCIATE && _context.Mode != C.MODE_DISASSOCIATE)
                    {
                        entity = new Entity(_context.EntityName);
                        if (_context.Mode == C.MODE_DELETE || _context.Mode == C.MODE_UPDATE)
                        {
                            entity.Id = new Guid(dataRow.Field<string>(C.MID_TABLE_NEWKEY));
                        }

                        if (_context.Mode == C.MODE_CREATE || _context.Mode == C.MODE_UPDATE)
                        {
                            BuildEntity(dataRow, entity, attributes);
                        }
                    }
                    lstBatchEntity.Add((dataRow, entity));

                    try
                    {
                        ReflectEntity(service, lstBatchEntity);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex);
                    }
                }

                if (lstBatchEntity.Count > 0)
                {
                    try
                    {
                        ReflectEntity(service, lstBatchEntity, true);
                    }
                    catch (Exception ex)
                    {
                        _logger.Error(ex);
                    }
                }
            }
        }

        /// <summary>
        /// エンティティデータをCRMに反映
        /// </summary>
        /// <param name="service"></param>
        /// <param name="entities"></param>
        /// <param name="isForceReflect"></param>
        public void ReflectEntity(IOrganizationService service, List<(DataRow, Entity)> entities, bool isForceReflect = false)
        {
            List<(DataRow, Entity)> targetEntities = null;

            if (isForceReflect)
            {
                targetEntities= entities.GetRange(0, entities.Count);
                entities.RemoveRange(0, entities.Count);
            }
            else
            {
                if (entities.Count < _context.BatchSize)
                    return;
                targetEntities = entities.GetRange(0, _context.BatchSize);
                entities.RemoveRange(0, _context.BatchSize);
            }

            if (_context.Mode == C.MODE_CREATE)
            {
                CreateEntity(service, targetEntities);
            }
            else if (_context.Mode== C.MODE_UPDATE)
            {
                UpdateEntity(service, targetEntities);
            }
            else if (_context.Mode== C.MODE_DELETE)
            {
                DeleteEntity(service, targetEntities);
            }
            else if (_context.Mode== C.MODE_ASSOCIATE)
            {
                AssociateEntity(service, targetEntities);
            }
            else if(_context.Mode==C.MODE_DISASSOCIATE)
            {
                DisassociateEntity(service, targetEntities);
            }
            else
            {
                throw new InvalidOperationException("Invalid Mode");
            }
        }

        /// <summary>
        /// エンティティ新規作成
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void CreateEntity(IOrganizationService service, List<(DataRow dateRow, Entity entity)> batchEntities)
        {
            //非アクティブデータを格納する
            var lstDisactive = new List<(DataRow, Entity, OptionSetValue, OptionSetValue)>();

            foreach(var listItem in batchEntities)
            {
                //Todo statuscode statecode
                if (listItem.entity.GetAttributeValue<OptionSetValue>(C.FIELD_NAME_STATECODE)?.Value > 0)
                {
                    if (_context.StatusCodeAdjust)
                    {
                        //StatusCode項目に変なデータが入る場合補正する
                        lstDisactive.Add((listItem.dateRow, listItem.entity, new OptionSetValue(1), new OptionSetValue(2)));
                    }
                    else
                    {
                        lstDisactive.Add((listItem.dateRow, listItem.entity,
                            listItem.entity.GetAttributeValue<OptionSetValue>(C.FIELD_NAME_STATECODE),
                            listItem.entity.GetAttributeValue<OptionSetValue>(C.FIELD_NAME_STATUSCODE)));
                    }

                    listItem.entity.Attributes.Remove(C.FIELD_NAME_STATECODE);
                    listItem.entity.Attributes.Remove(C.FIELD_NAME_STATUSCODE);
                }
            }

            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var listItem in batchEntities)
            {
                CreateRequest createRequest = new CreateRequest
                {
                    Target = listItem.entity
                };
                requestWithResults.Requests.Add(createRequest);
            }

            // 作成リクエスト実行
            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].dateRow.Field<int>(C.MID_TABLE_ID);

                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ登録に失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    var newGuid = (Guid)responseItem.Response.Results["id"];
                    //生成したGUIDを格納する
                    batchEntities[responseItem.RequestIndex].entity.Id=newGuid;

                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, newGuid, C.MID_TABLE_STATUS_SUCCESS);
                    _context.SuccessCount++;
                }
            }

            if (lstDisactive.Count > 0)
            {
                DisactiveEntity(service, lstDisactive);
            }
        }

        /// <summary>
        /// エンティティデータアップデート
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void UpdateEntity(IOrganizationService service, List<(DataRow, Entity)> batchEntities)
        {
            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in batchEntities)
            {
                UpdateRequest updateRequest = new UpdateRequest
                {
                    Target = entity.Item2
                };
                requestWithResults.Requests.Add(updateRequest);
            }

            // アップデートリクエスト実行
            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].Item1.Field<int>(C.MID_TABLE_ID);
                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ更新に失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_SUCCESS);
                    _context.SuccessCount++;
                }
            }
        }

        /// <summary>
        /// エンティティデータ削除
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void DeleteEntity(IOrganizationService service, List<(DataRow, Entity)> batchEntities)
        {
            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in batchEntities)
            {
                DeleteRequest deleteRequest = new DeleteRequest
                {
                    Target = entity.Item2.ToEntityReference()
                };
                requestWithResults.Requests.Add(deleteRequest);
            }

            // 削除リクエスト実行
            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].Item1.Field<int>(C.MID_TABLE_ID);
                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ削除に失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_SUCCESS);
                    _context.SuccessCount++;
                }
            }
        }

        /// <summary>
        /// エンティティデータ非アクティブ化
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void DisactiveEntity(IOrganizationService service, List<(DataRow, Entity, OptionSetValue, OptionSetValue)> batchEntities)
        {
            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            //登録失敗のデータを除く
            batchEntities = batchEntities.Where(r => r.Item2.Id != Guid.Empty).ToList();

            foreach (var entity in batchEntities)
            {
                var disActiveEntity = new Entity(entity.Item2.LogicalName, entity.Item2.Id);
                disActiveEntity[C.FIELD_NAME_STATECODE] = entity.Item3;
                disActiveEntity[C.FIELD_NAME_STATUSCODE] = entity.Item4;

                UpdateRequest updateRequest = new UpdateRequest
                {
                    Target = disActiveEntity
                };
                requestWithResults.Requests.Add(updateRequest);
            }

            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].Item1.Field<int>(C.MID_TABLE_ID);
                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ非アクティブに失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_DEACTIVE_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_DEACTIVE_SUCCESS);
                    _context.OtherCount++;
                }
            }
        }

        /// <summary>
        /// エンティティデータ紐付
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void AssociateEntity(IOrganizationService service, List<(DataRow dataRow, Entity entity)> batchEntities)
        {
            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in batchEntities)
            {
                var dataRow = entity.dataRow;

                if (dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATIONSHIP) == "addmembersteam")
                {
                    AddMembersTeamRequest addmembersTeamRequest = new AddMembersTeamRequest
                    {
                        TeamId=new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_ID)),
                        MemberIds = new Guid[] { new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATED_ENTITY_ID))}
                    };

                    requestWithResults.Requests.Add(addmembersTeamRequest);
                }
                else
                {
                    AssociateRequest associateRequest = new AssociateRequest
                    {
                        Target = new EntityReference(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY), new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_ID))),
                        Relationship = new Relationship(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATIONSHIP))
                    };

                    var relatedEntities = new EntityReferenceCollection();

                    relatedEntities.Add(new EntityReference(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATED_ENTITY),
                        new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATED_ENTITY_ID))));

                    associateRequest.RelatedEntities = relatedEntities;

                    requestWithResults.Requests.Add(associateRequest);
                }
            }

            // 紐付リクエスト実行
            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].Item1.Field<int>(C.MID_TABLE_ID);
                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ紐付に失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_SUCCESS);
                    _context.SuccessCount++;
                }
            }
        }

        /// <summary>
        /// エンティティデータ紐付解除
        /// </summary>
        /// <param name="service"></param>
        /// <param name="batchEntities"></param>
        public void DisassociateEntity(IOrganizationService service, List<(DataRow dataRow, Entity entity)> batchEntities)
        {
            var requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in batchEntities)
            {
                var dataRow = entity.dataRow;

                var disassociateRequest = new DisassociateRequest
                {
                    Target = new EntityReference(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY), new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_ID))),
                    Relationship = new Relationship(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATIONSHIP))
                };

                var relatedEntities = new EntityReferenceCollection();

                relatedEntities.Add(new EntityReference(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATED_ENTITY),
                    new Guid(dataRow.Field<string>(C.MID_TABLE_TARGETENTITY_RELATED_ENTITY_ID))));

                disassociateRequest.RelatedEntities = relatedEntities;

                requestWithResults.Requests.Add(disassociateRequest);
            }

            // 紐付解除リクエスト実行
            var responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {
                var midId = batchEntities[responseItem.RequestIndex].Item1.Field<int>(C.MID_TABLE_ID);
                if (responseItem.Fault != null)
                {
                    _logger.Error($"データ紐付解除に失敗しました、中間DbId:{midId},エラーメッセージ:{responseItem.Fault.ToString()}");
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_ERROR, responseItem.Fault.ToString());
                    _context.ErrorCount++;
                }
                else
                {
                    _midDbRepository.UpdateMidTableStatus(_context.MidTable, midId, C.MID_TABLE_STATUS_SUCCESS);
                    _context.SuccessCount++;
                }
            }
        }

        /// <summary>
        /// 反映エンティティ作成
        /// </summary>
        /// <param name="dataRow"></param>
        /// <param name="entity"></param>
        /// <param name="attributes"></param>
        public void BuildEntity(DataRow dataRow, Entity entity, List<AttributeMetadata> attributes)
        {
            bool isDebug = false;

            foreach (var attribute in attributes)
            {
                if (dataRow.Table.Columns.Contains(attribute.LogicalName))
                {
                    try
                    {
                        var val = dataRow[attribute.LogicalName];

                        if (val == null || val is DBNull)
                        {
                            if (_context.Mode == C.MODE_UPDATE)
                            {
                                entity[attribute.LogicalName] = null;//更新時NULL対応
                            }
                            continue;
                        }

                        switch (attribute.AttributeType)
                        {
                            case AttributeTypeCode.Owner:
                                if (isDebug)
                                {
                                    val = new EntityReference(C.ENTITY_NAME_SYSTEMUSER, new Guid("9509354E-2A7E-4D0C-8461-61912D20ACD8"));
                                }
                                else
                                {
                                    if (dataRow.Table.Columns.Contains(C.FIELD_NAME_OWNERID) && dataRow.Table.Columns.Contains(C.FIELD_NAME_OWNERIDTYPE))
                                    {
                                        var owneridtype = dataRow.Field<int>(C.FIELD_NAME_OWNERIDTYPE);
                                        if (owneridtype == 8)
                                        {
                                            val = new EntityReference(C.ENTITY_NAME_SYSTEMUSER, dataRow.Field<Guid>(C.FIELD_NAME_OWNERID));
                                        }
                                        else if (owneridtype == 9)
                                        {
                                            val = new EntityReference(C.ENTITY_NAME_TEAM, dataRow.Field<Guid>(C.FIELD_NAME_OWNERID));
                                        }
                                        else
                                        {
                                            throw new NotSupportedException("unknown owneridtype:" + owneridtype);
                                        }
                                    }
                                }
                                break;
                            case AttributeTypeCode.Lookup:
                                var lookupAttribute = (LookupAttributeMetadata)attribute;

                                if (isDebug && lookupAttribute.Targets.First() == C.ENTITY_NAME_SYSTEMUSER)
                                {
                                    val = new EntityReference(C.ENTITY_NAME_SYSTEMUSER, new Guid("9509354E-2A7E-4D0C-8461-61912D20ACD8"));
                                }
                                else
                                {
                                    var lookupAttri = (LookupAttributeMetadata)attribute;
                                    if (lookupAttri.LogicalName == "objectid" && lookupAttri.EntityLogicalName == "annotation")
                                    {
                                        val = new EntityReference(dataRow.Field<string>("objecttypename"), (Guid)val);
                                    }
                                    else
                                    {
                                        if (lookupAttri.Targets.Count() > 1)
                                        {
                                            _logger.Info($"複数エンティティ参照項目:{lookupAttri.LogicalName}");
                                        }
                                        val = new EntityReference(((LookupAttributeMetadata)attribute).Targets.First(), (Guid)val);
                                    }
                                }
                                break;
                            case AttributeTypeCode.Picklist:
                            case AttributeTypeCode.State:
                            case AttributeTypeCode.Status:
                                val = new OptionSetValue(Convert.ToInt32(val));
                                break;
                            case AttributeTypeCode.String:
                                if (val?.GetType() != typeof(string))
                                {
                                    val = val.ToString();
                                }

                                if (BARCODE_FIELDS.Keys.Contains(attribute.LogicalName))
                                {
                                    val = CovertToBarcode(dataRow[BARCODE_FIELDS[attribute.LogicalName]]);
                                }
                                else if (val.Equals("Random"))
                                {
                                    val = MakeRelationshipNumber();
                                }

                                break;
                            case AttributeTypeCode.Boolean:
                                if (val?.GetType() != typeof(bool))
                                {
                                    val = Convert.ToBoolean(val);
                                }
                                break;
                            case AttributeTypeCode.Virtual:
                                {
                                    if (attribute is MultiSelectPicklistAttributeMetadata)
                                    {
                                        var collectionOptionSetValues = new OptionSetValueCollection();
                                        var optionSet = new OptionSetValue(Convert.ToInt32(val));

                                        collectionOptionSetValues.Add(optionSet);
                                        val = collectionOptionSetValues;
                                    }
                                    else
                                    {
                                        _logger.Warn("要注意項目：" + attribute.LogicalName);
                                    }
                                }
                                break;
                            default:
                                break;
                        }

                        entity[attribute.LogicalName] = val;
                    }
                    catch(Exception ex)
                    {
                        _logger.Error($"BuildEntity Failed,MidId:{dataRow.Field<int>(ToolConsts.MID_TABLE_ID)},AttributeName:{attribute.LogicalName}");
                        throw ex;
                    }
                }
            }
        }

        /// <summary>
        /// エンティティメタデータ取得
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public List<AttributeMetadata> getEntityAttributes(string entityName, IOrganizationService service)
        {
            var atts = new List<AttributeMetadata>();
            var req = new RetrieveEntityRequest()
            {
                EntityFilters = EntityFilters.Attributes,
                LogicalName = entityName
            };

            var res = (RetrieveEntityResponse)service.Execute(req);

            foreach (var attMetadata in res.EntityMetadata.Attributes)
            {
                if ((attMetadata.IsValidForCreate.Value || attMetadata.IsValidForUpdate.Value)
                    && !attMetadata.IsPrimaryId.Value)
                {
                    atts.Add(attMetadata);
                }
            }
            return atts;
        }

        /// <summary>
        /// Guidマッピング取得
        /// </summary>
        /// <returns></returns>
        public List<GuidMapping> GetGuidMappings()
        {
            string guidFile = Path.Combine(ToolHelper.GetExecutingFolder(), C.GUIDMAPPING, _context.GuidMappingFile);
            string mappingContent = File.ReadAllText(guidFile);

            var doc = XDocument.Parse(mappingContent);

            var allDependents = doc.Elements("guidmappings").Elements("guidmapping");

            var lst = new List<GuidMapping>();
            foreach (var b in allDependents)
            {
                var d = new GuidMapping
                {
                    Attribute = b.Attribute("attribute")?.Value,
                    MidTable = b.Attribute("midtable")?.Value,
                    Sql = b.Attribute("sql")?.Value
                };
                lst.Add(d);
            }
            return lst;
        }

        /// <summary>
        /// バーコード変換
        /// </summary>
        /// <returns></returns>
        private string CovertToBarcode(object field)
        {
            var barcode = new MakeBarcode();
            return Convert.ToBase64String(barcode.PaintImageBarcode128(field.ToString()));
        }

        /// <summary>
        /// 関係性番号を作成する
        /// </summary>
        /// <returns></returns>
        private string MakeRelationshipNumber()
        {
            const string randomChars = "abcdefghijklmnopqrstuvwxyz";
            const int randomCharsLength = 8;
           
            var sb = new StringBuilder();
            var r = new Random();

            sb.Append(DateTime.Now.ToString("yyyyMMddHHmmss"));
            sb.Append("_");

            for (int i = randomCharsLength; i > 0; i--)
            {
                //ランダムな位置の文字を取得
                sb.Append(randomChars[r.Next(randomChars.Length)]);
            }

            return sb.ToString();
        }
    }
}
