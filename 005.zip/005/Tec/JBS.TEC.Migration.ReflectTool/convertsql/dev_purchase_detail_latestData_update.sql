﻿update x
set 
x.dev_rank_of_latest_data = y.rowNum
from
mid_dev_purchase_detail x
inner join
(
    select
    a.mid_oldkey,
    b.rowNum
    from
    mid_dev_purchase_detail a
    inner join 
    (
        select
        *
        from
        (
            select
            p.dev_contact_dev_purchase_detail,
            p.dev_relation_karte_id,
            p.its_name,
            p.overriddencreatedon,
            p.mid_oldkey,
            ROW_NUMBER() over(PARTITION BY p.dev_contact_dev_purchase_detail,p.dev_relation_karte_id ORDER BY p.overriddencreatedon DESC) as rowNum
            from
            mid_dev_purchase_detail p
            where
            p.dev_commodity_classification = 277670001 and 
            p.dev_contact_dev_purchase_detail is not null and
            p.dev_relation_karte_id is not null
        ) r
        where
        r.rowNum in (1,2)
    ) b 
    on a.mid_oldkey = b.mid_oldkey
) y
on x.mid_oldkey = y.mid_oldkey