﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BatchCommon.Helper
{
    public class CDSHelper
    {
        #region 変数定義
        // 一括処理件数
        public static int OP_COUNT = 100;
        #endregion

        #region データ全量検索処理
        /// <summary>
        /// データ全量検索処理
        /// </summary>
        /// <param name="expression">検索対象</param>
        /// <returns>検索結果</returns>
        public static EntityCollection GetAllData(IOrganizationService service, QueryExpression expression)
        {
            int queryCount = 5000;

            int pageNumber = 1;

            expression.PageInfo = new PagingInfo();
            expression.PageInfo.Count = queryCount;
            expression.PageInfo.PageNumber = pageNumber;
            expression.PageInfo.PagingCookie = null;

            var allResults = new EntityCollection();

            while (true)
            {
                var results = service.RetrieveMultiple(expression);

                if (results.Entities != null)
                {
                    allResults.Entities.AddRange(results.Entities);
                }

                if (results.MoreRecords)
                {
                    expression.PageInfo.PageNumber++;

                    expression.PageInfo.PagingCookie = results.PagingCookie;
                }
                else
                {
                    break;
                }
            }

            return allResults;
        }
        #endregion

        #region データ全量検索処理(分割)
        /// <summary>
        /// データ全量検索処理
        /// </summary>
        /// <param name="expression">検索対象</param>
        /// <returns>検索結果</returns>
        public static (QueryExpression expression, EntityCollection data) GetBlockData(IOrganizationService service, QueryExpression expression, bool next)
        {
            if (!next)
            {
                expression.PageInfo = new PagingInfo();
                expression.PageInfo.Count = 5000;
                expression.PageInfo.PageNumber = 1;
                expression.PageInfo.PagingCookie = null;
            }

            var results = service.RetrieveMultiple(expression);

            if (results.MoreRecords)
            {
                expression.PageInfo.PageNumber++;
                expression.PageInfo.PagingCookie = results.PagingCookie;
                return (expression, results);
            }
            else
            {
                return (null, results);
            }
        }
        #endregion

        #region 一括処理（新規登録）
        /// <summary>
        /// 一括処理（新規登録）
        /// <summary>
        /// </summary>
        /// <param name="insertEntitys">新規登録リスト</param>
        /// <param name="fileData">入力ファイルデータ</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <returns>失敗リスト</returns>
        public static List<string> MultipleInsertWithKey(Dictionary<string, Entity> insertEntitys, CrmServiceClient d365Client)
        {
            // 失敗リスト
            var failsList = new List<string>();

            // NULLチェック
            if (insertEntitys == null || insertEntitys.Count == 0)
            {
                return failsList;
            }

            // リクエスト定義
            var wRequestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },

                Requests = new OrganizationRequestCollection()
            };

            LogOutput.WriteLog(string.Format("新規登録対象件数:{0}", insertEntitys.Count));

            int insertCount = 0;

            int index = 0;

            var guids = new List<string>();

            int nowKensu = 0;

            // 登録処理を行う
            foreach (var entityRowNum in insertEntitys.Keys)
            {
                // 一括処理件数判定
                if (insertCount == OP_COUNT)
                {
                    LogOutput.WriteDebugLog(string.Format("新規登録処理:{0}/{1}", nowKensu, insertEntitys.Count));

                    insertCount = 0;

                    var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                    var keyList = insertEntitys.Keys.ToList();

                    foreach (var wResponseItem in wReponse.Responses)
                    {
                        if (wResponseItem.Fault != null)
                        {
                            var errorRowNum = keyList[index * OP_COUNT + wResponseItem.RequestIndex];

                            LogOutput.WriteErrorLog($"{errorRowNum}行目：{wResponseItem.Fault.Message}");

                            failsList.Add(errorRowNum);

                            guids.Add("");
                        }
                        else
                        {
                            guids.Add(wResponseItem.Response.Results["id"].ToString());
                        }
                    }

                    wRequestWithResults = new ExecuteMultipleRequest()
                    {
                        Settings = new ExecuteMultipleSettings()
                        {
                            ContinueOnError = true,
                            ReturnResponses = true
                        },

                        Requests = new OrganizationRequestCollection()
                    };

                    index++;
                }

                wRequestWithResults.Requests.Add(new CreateRequest { Target = insertEntitys[entityRowNum] });

                insertCount++;
                nowKensu++;
            }

            if (insertCount != 0)
            {
                LogOutput.WriteDebugLog(string.Format("新規登録処理:{0}/{1}", nowKensu, insertEntitys.Count));

                var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                var keyList = insertEntitys.Keys.ToList();

                foreach (var wResponseItem in wReponse.Responses)
                {
                    if (wResponseItem.Fault != null)
                    {
                        var errorRowNum = keyList.ToList()[index * OP_COUNT + wResponseItem.RequestIndex];

                        LogOutput.WriteErrorLog($"{errorRowNum}行目：{wResponseItem.Fault.Message}");

                        failsList.Add(errorRowNum);

                        guids.Add("");
                    }
                    else
                    {
                        guids.Add(wResponseItem.Response.Results["id"].ToString());
                    }
                }
            }

            // GUID設定処理
            var i = 0;
            foreach (var entRowNum in insertEntitys.Keys)
            {
                if (!string.IsNullOrEmpty(guids[i]))
                {
                    insertEntitys[entRowNum].Id = new Guid(guids[i]);
                }

                i++;
            }

            return failsList;
        }
        #endregion

        #region 一括処理（更新）
        /// <summary>
        /// 一括処理（更新）(CSVインポート用)
        /// </summary>
        /// <param name="updateEntitys">更新リスト</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <returns>失敗件数</returns>
        public static List<string> MultipleUpdateWithKey(Dictionary<string, Entity> updateEntitys, CrmServiceClient d365Client)
        {
            // 失敗リスト
            var failsList = new List<string>();

            // NULLチェック
            if (updateEntitys == null || updateEntitys.Count == 0)
            {
                return failsList;
            }

            // リクエスト定義
            var wRequestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },

                Requests = new OrganizationRequestCollection()
            };

            LogOutput.WriteLog(string.Format("更新対象件数:{0}", updateEntitys.Count));

            int updateCount = 0;

            int index = 0;

            int nowKensu = 0;

            foreach (var entityRowNum in updateEntitys.Keys)
            {
                if (updateCount == OP_COUNT)
                {
                    LogOutput.WriteDebugLog(string.Format("更新処理:{0}/{1}", nowKensu, updateEntitys.Count));

                    updateCount = 0;

                    var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                    var keyList = updateEntitys.Keys.ToList();

                    foreach (var wResponseItem in wReponse.Responses)
                    {
                        if (wResponseItem.Fault != null)
                        {
                            var errorRowNum = keyList[index * OP_COUNT + wResponseItem.RequestIndex];

                            LogOutput.WriteErrorLog($"{errorRowNum}行目：{wResponseItem.Fault.Message}");

                            failsList.Add(errorRowNum);
                        }
                    }

                    wRequestWithResults = new ExecuteMultipleRequest()
                    {
                        Settings = new ExecuteMultipleSettings()
                        {
                            ContinueOnError = true,
                            ReturnResponses = true
                        },

                        Requests = new OrganizationRequestCollection()
                    };

                    index++;
                }

                wRequestWithResults.Requests.Add(new UpdateRequest { Target = updateEntitys[entityRowNum] });

                updateCount++;
                nowKensu++;
            }

            if (updateCount != 0)
            {
                LogOutput.WriteDebugLog(string.Format("更新処理:{0}/{1}", nowKensu, updateEntitys.Count));

                var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                var keyList = updateEntitys.Keys.ToList();

                foreach (var wResponseItem in wReponse.Responses)
                {
                    if (wResponseItem.Fault != null)
                    {
                        var errorRowNum = keyList[index * OP_COUNT + wResponseItem.RequestIndex];

                        LogOutput.WriteErrorLog($"{errorRowNum}行目：{wResponseItem.Fault.Message}");

                        failsList.Add(errorRowNum);
                    }
                }
            }

            return failsList;
        }
        #endregion

        #region 一括処理（削除）
        /// <summary>
        /// 一括処理（削除）
        /// <summary>
        /// </summary>
        /// <param name="deleteEntitys">削除リスト</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <returns>失敗件数</returns>
        public static int MultipleDelete(EntityCollection deleteEntitys, CrmServiceClient d365Client)
        {
            // NULLチェック
            if (deleteEntitys == null || deleteEntitys.Entities.Count == 0)
            {
                return 0;
            }

            // 失敗リスト
            var failsList = new List<int>();

            // リクエスト定義
            var wRequestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },

                Requests = new OrganizationRequestCollection()
            };

            LogOutput.WriteLog(string.Format("削除対象件数:{0}", deleteEntitys.Entities.Count));

            int deleteCount = 0;

            int index = 0;

            int nowKensu = 0;

            // 登録処理を行う
            foreach (var entity in deleteEntitys.Entities)
            {
                // 一括処理件数判定
                if (deleteCount == OP_COUNT)
                {
                    LogOutput.WriteDebugLog(string.Format("削除処理:{0}/{1}", nowKensu, deleteEntitys.Entities.Count));

                    deleteCount = 0;

                    var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                    foreach (var wResponseItem in wReponse.Responses)
                    {
                        if (wResponseItem.Fault != null)
                        {
                            LogOutput.WriteErrorLog(wResponseItem.Fault.Message);

                            failsList.Add(index * OP_COUNT + wResponseItem.RequestIndex);
                        }
                    }

                    wRequestWithResults = new ExecuteMultipleRequest()
                    {
                        Settings = new ExecuteMultipleSettings()
                        {
                            ContinueOnError = true,
                            ReturnResponses = true
                        },

                        Requests = new OrganizationRequestCollection()
                    };

                    index++;
                }

                wRequestWithResults.Requests.Add(new DeleteRequest { Target = entity.ToEntityReference() });

                deleteCount++;
                nowKensu++;
            }

            if (deleteCount != 0)
            {
                LogOutput.WriteDebugLog(string.Format("削除処理:{0}/{1}", nowKensu, deleteEntitys.Entities.Count));

                var wReponse = (ExecuteMultipleResponse)d365Client.Execute(wRequestWithResults);

                foreach (var wResponseItem in wReponse.Responses)
                {
                    if (wResponseItem.Fault != null)
                    {
                        LogOutput.WriteErrorLog(wResponseItem.Fault.Message);

                        failsList.Add(index * OP_COUNT + wResponseItem.RequestIndex);
                    }
                }
            }

            return failsList.Count;
        }
        #endregion

        #region 一括処理（新規登録）（並行処理）
        /// <summary>
        /// 一括処理（新規登録）(CSVインポート用)（並行処理）
        /// <summary>
        /// </summary>
        /// <param name="insertEntitys">新規登録リスト</param>
        /// <param name="fileData">入力ファイルデータ</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <param name="maxDegreeOfParallelism">並行処理数</param>
        /// <returns>失敗リスト</returns>
        public static ConcurrentBag<(string key, string guid)> ParallelMultipleInsertWithKey(Dictionary<string, Entity> insertEntitys,
            CrmServiceClient d365Client, int maxDegreeOfParallelism)
        {
            LogOutput.WriteLog(string.Format("新規登録対象件数:{0}", insertEntitys.Count));

            // 処理結果初期化
            var createdEntityResults = new ConcurrentBag<(string key, string guid)>();
            var exceptions = new ConcurrentQueue<Exception>();

            // 処理リスト作成
            var chunks = new List<Dictionary<string, Entity>>();
            var chunkNow = 0;
            var newChunk = new Dictionary<string, Entity>();
            foreach (var key in insertEntitys.Keys)
            {
                if (chunkNow < OP_COUNT)
                {
                    chunkNow++;
                }
                else
                {
                    chunks.Add(newChunk);
                    newChunk = new Dictionary<string, Entity>();
                    chunkNow = 1;
                }
                newChunk.Add(key, insertEntitys[key]);
            }
            chunks.Add(newChunk);

            // 処理件数
            long cntr = 0;

            // 処理実行
            Parallel.ForEach(chunks,
                new ParallelOptions() { MaxDegreeOfParallelism = maxDegreeOfParallelism },
                () =>
                {
                    // スレッド用クライアント作成
                    return d365Client.Clone();
                },
                (entityList, loopState, index, threadLocalSvc) =>
                {
                    if (exceptions.Count == 0)
                    {
                        try
                        {
                            // リクエスト定義
                            var wRequestWithResults = new ExecuteMultipleRequest()
                            {
                                Settings = new ExecuteMultipleSettings()
                                {
                                    ContinueOnError = true,
                                    ReturnResponses = true
                                },

                                Requests = new OrganizationRequestCollection()
                            };

                            // 対象を追加
                            foreach (var entity in entityList)
                            {
                                wRequestWithResults.Requests.Add(new CreateRequest { Target = entity.Value });
                            }

                            // 処理を実行
                            var wReponse = (ExecuteMultipleResponse)threadLocalSvc.Execute(wRequestWithResults);

                            var keyList = entityList.Keys.ToList();

                            foreach (var wResponseItem in wReponse.Responses)
                            {
                                var rowNum = keyList[wResponseItem.RequestIndex];

                                if (wResponseItem.Fault != null)
                                {
                                    LogOutput.WriteErrorLog($"{rowNum}行目：{wResponseItem.Fault.Message}");

                                    createdEntityResults.Add((rowNum, ""));
                                }
                                else
                                {
                                    createdEntityResults.Add((rowNum, wResponseItem.Response.Results["id"].ToString()));
                                }

                                var nowCount = Interlocked.Increment(ref cntr);
                                if (nowCount % 100 == 0)
                                {
                                    LogOutput.WriteDebugLog($"新規登録件数:{nowCount}/{insertEntitys.Count}");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            exceptions.Enqueue(e);
                        }
                    }

                    return threadLocalSvc;
                },
                (threadLocalSvc) =>
                {
                    if (threadLocalSvc != null)
                    {
                        threadLocalSvc.Dispose();
                    }
                });

            if (exceptions.Count > 0) throw exceptions.FirstOrDefault();

            return createdEntityResults;
        }
        #endregion

        #region 一括処理（更新）（並行処理）
        /// <summary>
        /// 一括処理（更新）(CSVインポート用)（並行処理）
        /// </summary>
        /// <param name="updateEntitys">更新リスト</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <param name="maxDegreeOfParallelism">並行処理数</param>
        /// <returns>失敗リスト</returns>
        public static ConcurrentBag<string> ParallelMultipleUpdateWithKey(Dictionary<string, Entity> updateEntitys,
            CrmServiceClient d365Client, int maxDegreeOfParallelism)
        {
            LogOutput.WriteLog(string.Format("更新対象件数:{0}", updateEntitys.Count));

            // 処理結果初期化
            var updatedErrorResults = new ConcurrentBag<string>();
            var exceptions = new ConcurrentQueue<Exception>();

            // 処理リスト作成
            var chunks = new List<Dictionary<string, Entity>>();
            var chunkNow = 0;
            var newChunk = new Dictionary<string, Entity>();
            foreach (var key in updateEntitys.Keys)
            {
                if (chunkNow < OP_COUNT)
                {
                    chunkNow++;
                }
                else
                {
                    chunks.Add(newChunk);
                    newChunk = new Dictionary<string, Entity>();
                    chunkNow = 1;
                }
                newChunk.Add(key, updateEntitys[key]);
            }
            chunks.Add(newChunk);

            // 処理件数
            long cntr = 0;

            // 処理実行
            Parallel.ForEach(chunks,
                new ParallelOptions() { MaxDegreeOfParallelism = maxDegreeOfParallelism },
                () =>
                {
                    // スレッド用クライアント作成
                    return d365Client.Clone();
                },
                (entityList, loopState, index, threadLocalSvc) =>
                {
                    if (exceptions.Count == 0)
                    {
                        try
                        {
                            // リクエスト定義
                            var wRequestWithResults = new ExecuteMultipleRequest()
                            {
                                Settings = new ExecuteMultipleSettings()
                                {
                                    ContinueOnError = true,
                                    ReturnResponses = true
                                },

                                Requests = new OrganizationRequestCollection()
                            };

                            // 対象を追加
                            foreach (var entity in entityList)
                            {
                                wRequestWithResults.Requests.Add(new UpdateRequest { Target = entity.Value });
                            }

                            // 処理を実行
                            var wReponse = (ExecuteMultipleResponse)threadLocalSvc.Execute(wRequestWithResults);

                            var keyList = entityList.Keys.ToList();

                            foreach (var wResponseItem in wReponse.Responses)
                            {
                                var rowNum = keyList[wResponseItem.RequestIndex];

                                if (wResponseItem.Fault != null)
                                {
                                    LogOutput.WriteErrorLog($"{rowNum}行目：{wResponseItem.Fault.Message}");
                                    updatedErrorResults.Add(rowNum);
                                }

                                var nowCount = Interlocked.Increment(ref cntr);
                                if (nowCount % 100 == 0)
                                {
                                    LogOutput.WriteDebugLog($"処理件数:{nowCount}/{updateEntitys.Count}");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            exceptions.Enqueue(e);
                        }
                    }

                    return threadLocalSvc;
                },
                (threadLocalSvc) =>
                {
                    if (threadLocalSvc != null)
                    {
                        threadLocalSvc.Dispose();
                    }
                });

            if (exceptions.Count > 0) throw exceptions.FirstOrDefault();

            return updatedErrorResults;
        }
        #endregion

        #region 一括処理（削除）（並行処理）
        /// <summary>
        /// 一括処理（削除）（並行処理）
        /// <summary>
        /// </summary>
        /// <param name="deleteEntitys">削除リスト</param>
        /// <param name="d365Client">D365クライアント</param>
        /// <param name="maxDegreeOfParallelism">並行処理数</param>
        /// <returns>失敗件数</returns>
        public static int ParallelMultipleDelete(EntityCollection deleteEntitys, CrmServiceClient d365Client, int maxDegreeOfParallelism)
        {
            // NULLチェック
            if (deleteEntitys == null || deleteEntitys.Entities.Count == 0)
            {
                return 0;
            }

            // 処理結果初期化
            var errorResults = new ConcurrentBag<Entity>();
            var exceptions = new ConcurrentQueue<Exception>();

            // 処理リスト作成
            var chunks = new List<List<Entity>>();
            var chunkNow = 0;
            var newChunk = new List<Entity>();
            foreach (var ent in deleteEntitys.Entities)
            {
                if (chunkNow < OP_COUNT)
                {
                    chunkNow++;
                }
                else
                {
                    chunks.Add(newChunk);
                    newChunk = new List<Entity>();
                    chunkNow = 1;
                }
                newChunk.Add(ent);
            }
            chunks.Add(newChunk);

            // 処理件数
            long cntr = 0;

            // 処理結果初期化
            Parallel.ForEach(chunks,
                new ParallelOptions() { MaxDegreeOfParallelism = maxDegreeOfParallelism },
                () =>
                {
                    // スレッド用クライアント作成
                    return d365Client.Clone();
                },
                (entityList, loopState, index, threadLocalSvc) =>
                {
                    if (exceptions.Count == 0)
                    {
                        try
                        {
                            // リクエスト定義
                            var wRequestWithResults = new ExecuteMultipleRequest()
                            {
                                Settings = new ExecuteMultipleSettings()
                                {
                                    ContinueOnError = true,
                                    ReturnResponses = true
                                },

                                Requests = new OrganizationRequestCollection()
                            };

                            // 対象を追加
                            foreach (var entity in entityList)
                            {
                                wRequestWithResults.Requests.Add(new DeleteRequest { Target = entity.ToEntityReference() });
                            }

                            // 処理を実行
                            var wReponse = (ExecuteMultipleResponse)threadLocalSvc.Execute(wRequestWithResults);

                            foreach (var wResponseItem in wReponse.Responses)
                            {
                                if (wResponseItem.Fault != null)
                                {
                                    LogOutput.WriteErrorLog(wResponseItem.Fault.Message);

                                    errorResults.Add(entityList[wResponseItem.RequestIndex]);
                                }

                                var nowCount = Interlocked.Increment(ref cntr);
                                if (nowCount % 100 == 0)
                                {
                                    LogOutput.WriteDebugLog($"削除件数:{nowCount}/{deleteEntitys.Entities.Count}");
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            exceptions.Enqueue(e);
                        }
                    }

                    return threadLocalSvc;
                },
                (threadLocalSvc) =>
                {
                    if (threadLocalSvc != null)
                    {
                        threadLocalSvc.Dispose();
                    }
                });

            if (exceptions.Count > 0) throw exceptions.FirstOrDefault();

            // 件数設定
            return errorResults.Count;
        }
        #endregion
    }
}
