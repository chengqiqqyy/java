﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace BatchCommon.Helper
{
    public static class EntityExtensions
    {
        public static string PrintEntity(this Entity entity)
        {
            if (entity == null)
                throw new ArgumentNullException(nameof(entity));

            var attrs =
                entity.Attributes
                      .Where(x => IsPrintableAttribute(x.Key, x.Value))
                      .Select(x => $"⠀⠀{x.Key}: {PrintAttribute(x.Value)}")
                      .ToList();

            attrs.Insert(0, $"エンティティ名: {entity.LogicalName}");
            attrs.Insert(1, $"エンティティID: {entity.Id}");

            var attrsText =
                string.Join(Environment.NewLine, attrs);

            return attrsText;
        }

        public static string PrintEntityReference(this EntityReference entityReference)
        {
            if (entityReference == null) return "[null]";
            var result = string.Empty;
            result += "[";
            result += $"エンティティ名: {entityReference.LogicalName} ";
            result += $"(エンティティID: {entityReference.Id})";
            result += "]";
            return result;
        }

        public static bool IsPrintableAttribute(string attributeName, object value)
        {
            switch (attributeName)
            {
                case "owningbusinessunit":
                case "timezoneruleversionnumber":
                case "createdonbehalfby":
                case string x when x.Contains("yomi"):
                    return false;
                default:
                    return true;
            }
        }

        public static string PrintAttribute(object value)
        {
            switch (value)
            {
                case EntityReference x: return $"{{ ID: {x.Id}, エンティティ名: {x.LogicalName}, 表示名: '{x.Name}'}}";
                case OptionSetValue x: return x.Value.ToString();
                case AliasedValue x: return PrintAttribute(x.Value);
                case null: return "NULL";
                case string x when x.Length > 1000: return $"Blob {x.Length} bytes";
                case string x when x.Length > 200: return x.Substring(0, 200) + "...";
                default: return value.ToString();
            }
        }
    }
}
