﻿create function dbo.InlineMax(@val1 int, @val2 int, @val3 int, @val4 int, @val5 int, @val6 int)
returns int as 
begin 
  declare @val int set @val = 0 
  declare @TableVal table(value int)
  insert into @TableVal select @val1
  insert into @TableVal select @val2
  insert into @TableVal select @val3
  insert into @TableVal select @val4
  insert into @TableVal select @val5
  insert into @TableVal select @val6
  select @val = max(value) from @TableVal return @val
end