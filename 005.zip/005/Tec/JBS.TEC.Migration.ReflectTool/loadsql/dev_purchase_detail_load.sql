﻿SELECT 
 *
FROM 
[dbo].[mid_dev_purchase_detail]