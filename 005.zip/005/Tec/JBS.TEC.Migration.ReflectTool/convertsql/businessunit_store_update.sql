﻿UPDATE 
b
SET
b.dev_store_order = s.dev_store_no

FROM
mid_businessunit b
inner join 
mid_dev_store s
on b.dev_store_id = s.dev_store_id