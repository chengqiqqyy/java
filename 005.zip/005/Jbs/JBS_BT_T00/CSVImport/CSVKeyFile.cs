﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVKeyFile
    {
        public string EntityName { get; set; }

        public CSVKeyFile(string entityName)
        {

        }

        public virtual string GetAttributeValue(string guid, string attribute)
        {
            return null;
        }
        public virtual string Query(string attribute1, string value1, string attribute2, string value2)
        {
            return null;
        }
    }
}
