﻿using NLog;

namespace BatchCommon
{
    /// <summary>
    /// ログ出力用
    /// </summary>
    public class LogOutput
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="logOutPath"></param>
        /// <param name="batchId"></param>
        public static void Init(string logOutPath, string batchId)
        {
            LogManager.Configuration.Variables["batchlogfolder"] = logOutPath;
            LogManager.Configuration.Variables["batchid"] = batchId;

            _logger.Info(batchId + " 処理開始");
        }

        /// <summary>
        /// ログ作成処理
        /// </summary>
        /// <param name="message"></param>
        public static void WriteLog(string message)
        {
            _logger.Info(message);
        }

        /// <summary>
        /// ログ作成処理Debug
        /// </summary>
        /// <param name="message"></param>
        public static void WriteDebugLog(string message)
        {
            _logger.Debug(message);
        }

        /// <summary>
        /// ログ作成処理Trace
        /// </summary>
        /// <param name="message"></param>
        public static void WriteTraceLog(string message)
        {
            _logger.Trace(message);
        }

        /// <summary>
        /// ログ作成処理Warn
        /// </summary>
        /// <param name="message"></param>
        public static void WriteWarnLog(string message)
        {
            _logger.Warn(message);
        }

        /// <summary>
        /// ログ作成処理Error
        /// </summary>
        /// <param name="message"></param>
        public static void WriteErrorLog(string message)
        {
            _logger.Error(message);
        }
    }

}
