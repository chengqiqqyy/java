﻿using JBS.Common.CDS;
using JBS.TEC.Migration.Common.Config;
using JBS.TEC.Migration.ReflectTool.Service;
using NLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool
{
    public class ReflectTool
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        private ToolContext _context;

        public ReflectTool()
        {
            _context = new ToolContext();
        }

        public void Execute(string[] args)
        {
            Init(args);

            var loadService = new LoadCSVToMidDBService(_context);
            loadService.Execute();

            if (!string.IsNullOrEmpty(_context.EntityName) || _context.Mode > 2)
            {
                var reflectService = new LoadMidDbToCDSService(_context);
                reflectService.Execute(args);

                _logger.Info($"合計件数:{_context.TotalCount},正常件数：{_context.SuccessCount},異常件数：{_context.ErrorCount},警告件数:{_context.WarningCount},その他件数:{_context.OtherCount}");
            }
        }

        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="args"></param>
        public void Init(string[] args)
        {
            ConfigManager.Load(args);
            _context.SqlServerConnectionString = ConfigManager.ConnectionStrings[ConfigConsts.KEY_TECMIDDB];
            _context.CDSConnectionString = ConfigManager.ConnectionStrings["TecCDS"];
            CDSServiceFactory.CrmConnectionString = _context.CDSConnectionString;
            ConfigHelper.MappingToObject(_context);

            //抽出フォルダパス補正
            if (!ToolHelper.IsPathFullyQualified(_context.ExtractBaseFolder))
            {
                var path = Path.Combine(ToolHelper.GetExecutingFolder(), _context.ExtractBaseFolder);
                _context.ExtractBaseFolder = Path.GetFullPath(path);
            }
            _logger.Info($"ExtractTool Folder:{_context.ExtractBaseFolder}");
        }
    }
}
