﻿update x
set
x.dev_repair_move_date_2 = Dateadd(DAY,y.maxNum,Cast(Getutcdate() as date)) 
from
mid_dev_repair x
inner join
(
    select
    c.mid_oldkey as mid_oldkey,
    dbo.InlineMax(c.num1,c.num2,c.num3,c.num4,c.num5,c.num6) as maxNum
    from
    (
        select 
        a.mid_oldkey,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code and b.statuscode = 1) as num1,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code2 and b.statuscode = 1) as num2,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code3 and b.statuscode = 1) as num3,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code4 and b.statuscode = 1) as num4,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code5 and b.statuscode = 1) as num5,
        (select top(1) b.dev_kijun_nouki_nissu from mid_dev_repair_master b where b.mid_oldkey = a.dev_repair_code6 and b.statuscode = 1) as num6

        from mid_dev_repair a
    ) c
) y
on x.mid_oldkey = y.mid_oldkey
where y.maxNum is not null