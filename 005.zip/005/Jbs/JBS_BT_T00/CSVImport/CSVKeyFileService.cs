﻿using BatchCommon.Helper;
using BatchCommon.Log;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVKeyFileService
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        protected readonly CSVImportContext _context;
        protected DataTable _keyDataTable;

        protected List<Entity> _lstInsertedEntity = new List<Entity>();
        protected List<Entity> _lstUpdateEntity = new List<Entity>();

        public string KeyFileName { get; set; }

        private bool sortFlag = false;
        private static object lockflag = new object();

        public CSVKeyFileService(CSVImportContext context, string keyFileName)
        {
            _context = context;
            KeyFileName = keyFileName;

            LoadKeyFile();
        }
        protected virtual void LoadKeyFile()
        {
            // キーファイルパス
           var keyFilePath = Path.Combine(_context.JBS_BT_T00_Config.KeyFilePath, KeyFileName + ".csv");
            _logger.Trace($"キーファイルを読み込みます、{keyFilePath}");

            // 存在チェック
            if (!File.Exists(keyFilePath))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, KeyFileName));
            }


            using (TextFieldParser csvReader = new TextFieldParser(keyFilePath, _context.JBS_BT_T00_Config.FileEncode))
            {
                csvReader.TextFieldType = FieldType.Delimited;
                csvReader.SetDelimiters(new string[] { _context.Delimiter });
                csvReader.HasFieldsEnclosedInQuotes = true;
                csvReader.TrimWhiteSpace = true;
                string[] colFields = csvReader.ReadFields();

                _keyDataTable = new DataTable();
                foreach (string column in colFields)
                {
                    DataColumn datecolumn = new DataColumn(column);
                    datecolumn.AllowDBNull = true;
                    _keyDataTable.Columns.Add(datecolumn);
                }

                while (!csvReader.EndOfData)
                {
                    string[] fieldData = csvReader.ReadFields();
                    _keyDataTable.Rows.Add(fieldData);
                }

                _logger.Trace($"キーファイルを読み込みました、ファイル名:{keyFilePath},件数:{_keyDataTable.Rows.Count}");
            }
        }

        public virtual DataRow[] Query(Dictionary<string, string> keyValues)
        {
            var i = 0;
            var sortBy = "";
            var select = "";

            foreach (var key in keyValues.Keys)
            {
                if (i == 0)
                {
                    sortBy = key;
                    select = key + " = '" + keyValues[key] + "'";
                }
                else
                {
                    sortBy = sortBy + "," + key;
                    select = select + " AND " + key + " = '" + keyValues[key] + "'";
                }

                i++;
            }

            if (!sortFlag)
            {
                _keyDataTable.DefaultView.Sort = sortBy;
                sortFlag = true;
            }
            lock(lockflag)
            {
                return _keyDataTable.Select(select);
            }
        }

        public virtual void AddKeyInfo(Entity entity)
        {
            if (entity.Id == Guid.Empty)
                throw new Exception("新規登録エンティティデータではありません");

            _lstInsertedEntity.Add(entity);

            
        }
        public virtual void UpdateKeyInfo(Entity entity)
        {
           
        }

        public virtual void UpdateKeyFile()
        {
            if (_lstInsertedEntity.Count == 0 && _lstUpdateEntity.Count == 0)
            {
                return;
            }
            _logger.Info($"キーファイルを更新します、{KeyFileName}");

            
            MergeKeyFile();

            //TODO 一旦別名前で出力してから置き換えるのは安全かと
            // キー情報ファイル出力
            var keyFileName = Path.Combine(_context.JBS_BT_T00_Config.KeyFilePath, _context.JBS_BT_T00_Config.LogicName + ".csv");

            if (File.Exists(keyFileName))
            {
                File.Delete(keyFileName);
            }

            StringBuilder sb = new StringBuilder();
            IEnumerable<string> columnNames = _keyDataTable.Columns.Cast<DataColumn>().
                                  Select(column => column.ColumnName);
            sb.AppendLine(string.Join(_context.Delimiter, columnNames));

            foreach (DataRow row in _keyDataTable.Rows)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(_context.Delimiter, fields));
            }
            // 行出力
            File.WriteAllText(keyFileName, sb.ToString(), _context.JBS_BT_T00_Config.FileEncode);
        }

        protected virtual void MergeKeyFile()
        {
            foreach (var entity in _lstInsertedEntity)
            {
                // 必要情報設定
                DataRow dataRow = _keyDataTable.NewRow();
                dataRow[CSVImportConsts.GUID] = entity.Id.ToString();

                foreach (DataColumn column in _keyDataTable.Columns)
                {
                    if (column.ColumnName == CSVImportConsts.GUID)
                    {
                        continue;
                    }
                    dataRow[column] = EntityHelper.GetFieldValue(entity, column.ColumnName);

                    // 状態なし場合
                    if (column.ColumnName == "statecode" && string.IsNullOrEmpty(dataRow[column].ToString()))
                    {
                        dataRow[column] = "0";
                    }
                }
                _keyDataTable.Rows.Add(dataRow);
            }
            foreach (var entity in _lstUpdateEntity)
            {
                // 検索条件
                var keyValues = new Dictionary<string, string>();

                // 検索条件設定
                for (var j = 0; j < _context.JBS_BT_T00_Config.Keys.Count; j++)
                {
                    var checkKey = _context.JBS_BT_T00_Config.Keys[j].CrmColumn;
                    var checkVal = EntityHelper.GetFieldValue(entity, _context.JBS_BT_T00_Config.Keys[j].CrmColumn);

                    keyValues.Add(checkKey, checkVal);
                }

                // 検索
                var searchResults = Query(keyValues);
                var row = searchResults.FirstOrDefault();

                // 情報更新
                foreach (DataColumn column in _keyDataTable.Columns)
                {
                    if (column.ColumnName == CSVImportConsts.GUID)
                    {
                        continue;
                    }

                    row[column] = EntityHelper.GetFieldValue(entity, column.ColumnName);

                    // 状態なし場合
                    if (column.ColumnName == "statecode" && string.IsNullOrEmpty(row[column].ToString()))
                    {
                        row[column] = "0";
                    }
                }
            }
        }
    }
}
