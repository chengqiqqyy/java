﻿using BatchCommon.Helper;
using BatchCommon.Log;
using JBS_BT_T00.Parallel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.EntityService
{
    public class EntityDataExecutor : ITaskExecutor<EntityData>
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        protected IOrganizationService _crmService;
        public IOrganizationService CrmService { get { return _crmService; } set { _crmService = value; } }

        protected ParallelContext _context;

        public EntityDataExecutor(ParallelContext context)
        {
            _context = context;
        }

        public IList<TaskResult<EntityData>> Execute(IList<EntityData> datas)
        {
            var taskResults = new List<TaskResult<EntityData>>();
            foreach (var entity in datas)
            {
                var taskResult = new TaskResult<EntityData>() { TaskData = entity, ResultType = TaskResultType.SUCCESS };
                taskResults.Add(taskResult);
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entityData in datas)
            {
                if (entityData.ActionType == EntityActionType.Create)
                {
                    CreateRequest createRequest = new CreateRequest
                    {
                        Target = entityData.TargetEntity
                    };
                    multipleRequest.Requests.Add(createRequest);
                }
                else if (entityData.ActionType == EntityActionType.Update)
                {
                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = entityData.TargetEntity
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
                else if (entityData.ActionType == EntityActionType.Delete)
                {
                    DeleteRequest deleteRequest = new DeleteRequest
                    {
                        Target = entityData.TargetEntity.ToEntityReference()
                    };
                    multipleRequest.Requests.Add(deleteRequest);
                }
            }
            var responseWithResults = (ExecuteMultipleResponse)CrmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var taskResult = taskResults[responseItem.RequestIndex];
                if (responseItem.Fault != null)
                {
                    taskResult.ResultType = TaskResultType.ERROR;
                    if (taskResult.TaskData.ActionType == EntityActionType.Create)
                    {
                        _logger.Error($"データ登録に失敗しました、エラーメッセージ:{responseItem.Fault.ToString()}");
                        _logger.Error(taskResult.TaskData.TargetEntity.PrintEntity());

                    }
                    else if (taskResult.TaskData.ActionType == EntityActionType.Update)
                    {
                        _logger.Error($"データ更新に失敗しました、エンティティ名:{taskResult.TaskData.TargetEntity.LogicalName}, エンティティId:{taskResult.TaskData.TargetEntity.Id}, エラーメッセージ:{responseItem.Fault.ToString()}");
                        _logger.Error(taskResult.TaskData.TargetEntity.PrintEntity());
                    }
                    else if (taskResult.TaskData.ActionType == EntityActionType.Delete)
                    {
                        _logger.Error($"データ削除に失敗しました、エンティティ名:{taskResult.TaskData.TargetEntity.LogicalName}, エンティティId:{taskResult.TaskData.TargetEntity.Id},エラーメッセージ:{responseItem.Fault.ToString()}");
                    }
                }
                else
                {
                    if (taskResult.TaskData.ActionType == EntityActionType.Create)
                    {
                        //生成したGUIDを格納する
                        var newGuid = (Guid)responseItem.Response.Results["id"];
                        taskResult.TaskData.TargetEntity.Id = newGuid;
                    }
                }
            }
            return taskResults;
        }
    }
}
