﻿SELECT 
 *
FROM 
[dbo].[mid_dev_contract]