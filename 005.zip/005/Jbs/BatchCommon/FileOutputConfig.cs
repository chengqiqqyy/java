﻿using System;

namespace BatchCommon
{
    /// <summary>
    /// ファイル出力設定情報
    /// </summary>
    public class FileOutputConfig
    {
        // 出力フォルダ_夜間
        public string FileOutPath { get; set; }

        // 出力ファイル名_夜間
        public string FileOutName { get; set; }

        // 出力フォルダ_日中
        public string FileOutPathDay { get; set; }

        // 出力ファイル名_日中
        public string FileOutNameDay { get; set; }

        // 前回成功日時
        public DateTime? SuccessedTime { get; set; }
    }
}
