﻿using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Specialized
{
    public class BT105ImportExecutor : CSVImportExecutor
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public BT105ImportExecutor(CSVImportContext context) : base(context)
        {

        }

        // [所有者] 特殊処理
        protected override void SetOwner(CSVFieldData csvFieldData)
        {
            // 所有者設定要否の判断
            if (!_context.JBS_BT_T00_Config.SetOwner || csvFieldData.ColumnMapping.CrmColumn != "tsb_top_insider")
            {
                return;
            }

            // 処理エンティティ
            var opObj = csvFieldData.CSVRow.EntityData;
            // インサイダー等極秘情報
            var insiderFlag = false;

            if (opObj.GetAttributeValue<object>("tsb_top_insider") == null)
            {
                if (_context.JBS_BT_T00_Config.OwnerSkip)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    _logger.Debug($"所有者設定不可、インサイダー等極秘情報は設定していません。{csvFieldData.CSVRow.RowNum}行目");
                    return;
                }
                throw new Exception($"所有者設定不可、インサイダー等極秘情報は設定していません。{csvFieldData.CSVRow.RowNum}行目");
            }
            else
            {
                insiderFlag = opObj.GetAttributeValue<bool>("tsb_top_insider");
            }

            // インサイダーの場合
            if (insiderFlag)
            {
                // ユーザーキーファイル取得
                var keyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                var checkValue = csvFieldData.CSVRow.RowData["m_ownerid"];
                keyValues.Add("tsb_slt_bank_clerk_id", checkValue);
                // 検索
                var rows = keyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    return;
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "systemuser", "ownerid", checkValue));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "systemuser", "ownerid", checkValue));
                }
                // 所有者設定
                opObj["ownerid"] = new EntityReference("systemuser", new Guid(rows[0]["guid"].ToString()));
            }
            // インサイダーでない場合
            else
            {
                // ユーザーキーファイル取得
                var keyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                // 該当組織階層検索
                var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_organization_structure");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                // 組織階層区分
                keyValues.Add("tsb_ops_type_organization", "100000004");
                // 組織コード
                keyValues.Add("tsb_slt_name_or_code", csvFieldData.CSVRow.RowData["m_ownerid"]);
                // 検索
                var rows = keyFileService.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
                // ライン
                var lineid = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line"].ToString();

                if (!string.IsNullOrEmpty(lineid))
                {
                    // ラインの組織階層検索条件
                    keyValues.Clear();
                    keyValues.Add("guid", lineid);
                    // 検索
                    rows = keyFileService.Query(keyValues);
                    // ライン(所有者チーム)
                    var teamid = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line_team"].ToString();

                    if (!string.IsNullOrEmpty(teamid))
                    {
                        // 所有者設定
                        opObj["ownerid"] = new EntityReference("team", new Guid(teamid));
                    }
                    else
                    {
                        if (_context.JBS_BT_T00_Config.OwnerSkip)
                        {
                            // 特定システムユーザーセット
                            opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                            _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                            return;
                        }
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                    }
                }
                else
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
            }
        }

        // 自己参照
        protected override void UpsertEntity(List<(CSVRowData CSVData, Entity EntityData)> batchEntities)
        {
            if (!_context.JBS_BT_T00_Config.SelfLookup)
            {
                base.UpsertEntity(batchEntities);
                return;
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            var updList = new List<(CSVRowData CSVData, Entity EntityData)>();

            foreach (var itemData in batchEntities)
            {
                if (itemData.EntityData.Id != Guid.Empty)
                {
                    // 「Copy元応対記録番号」はブランクの場合
                    if (string.IsNullOrEmpty(itemData.CSVData.RowData["m_tsb_lup_num_copy_response_record"]))
                    {
                        itemData.CSVData.IsSuccess = true;
                        continue;
                    }

                    updList.Add((itemData.CSVData, itemData.EntityData));

                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
                else
                {
                    itemData.CSVData.IsSuccess = true;
                }
            }
            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = updList[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                }
            }
        }

    }
}
