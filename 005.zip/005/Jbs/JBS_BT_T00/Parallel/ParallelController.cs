﻿using BatchCommon.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace JBS_BT_T00.Parallel
{
    public class ParallelController
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public static void Run<TData, TExecutor, TContext>(Func<TContext, TExecutor> createExecutorAction,
            Func<int, TContext, IList<TData>> productDataAction,
            Action<IList<TaskResult<TData>>, TContext> callbackAction,
            TContext context)
            where TData : class
            where TExecutor : ITaskExecutor<TData>
            where TContext : ParallelContext
        {
            _logger.Info($"並列処理を開始します、スレッド数：{context.ThreadCount},ブロック数:{context.BlockCount}");

            var taskContainer = new List<Task>();
            int logCounter = 0;

            for (var i = 0; i < context.ThreadCount; i++)
            {
                var executor = createExecutorAction(context);
                var task = Task.Factory.StartNew((taskData) => 
                {
                    #region タスク処理
                    var taskExecutor = taskData as ITaskExecutor<TData>;

                    int processedCount = 0;
                    while(true)
                    {
                        if(context.HasAbortRequest)
                        {
                            _logger.Info("タスクの中止が要求されました");
                            break;
                        }
                        else if (context.IsAllDataFetched)
                        {
                            break;
                        }
                        IList<TData> sourceData = null;
                        try
                        {
                            lock(context.SyncObject)
                            {
                                sourceData = productDataAction(context.BlockCount, context);
                                if( sourceData != null)
                                {
                                    context.TotalCount += sourceData.Count();
                                }
                            }
                        }
                        catch(Exception ex)
                        {
                            _logger.Error($"データ取得処理で例外が発生しました。例外詳細：{ex.ToString()}");
                            _logger.Error($"並列処理を中止します");
                            context.HasAbortRequest = true;
                            continue;
                        }

                        if(sourceData?.Count() == 0)
                        {
                            //全てのデータを取得完了
                            context.IsAllDataFetched = true;
                            continue;
                        }

                        try
                        {
                            var taskResults = taskExecutor.Execute(sourceData);

                            lock (context.SyncObject)
                            {
                                context.SuccessCount += taskResults.Count(r => r.ResultType == TaskResultType.SUCCESS);
                                context.WarningCount += taskResults.Count(r => r.ResultType == TaskResultType.WARNING);
                                context.ErrorCount += taskResults.Count(r => r.ResultType == TaskResultType.ERROR);

                                processedCount = context.SuccessCount + context.WarningCount + context.ErrorCount;
                            }

                            //コールバック処理
                            if (callbackAction != null)
                            {
                                try
                                {
                                    lock (context.SyncObject)
                                    {
                                        callbackAction(taskResults, context);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _logger.Error($"コールバック処理で例外が発生しました、{ex.ToString()}");
                                    //処理を続行する
                                }
                            }
                        }
                        catch(Exception ex)
                        {
                            _logger.Error($"スレッド処理で例外が発生しました、{ex.ToString()}");
                            throw ex;
                        }

                        lock (context.SyncObject)
                        {
                            logCounter++;
                            //進捗出力
                            if (processedCount % 1000 == 0)
                            {
                                _logger.Info($"合計{processedCount}件データが処理しました...............");
                            }
                        }
                    }
                    #endregion
                }, executor);

                taskContainer.Add(task);
            }

            //タスク実行終了チェック
            while (true)
            {
                foreach (var task in taskContainer.ToArray())
                {
                    if (task.IsFaulted || task.IsCanceled || task.IsCompleted)
                    {
                        taskContainer.Remove(task);
                    }
                }
                //全てのタスクが修正した場合
                if (taskContainer.Count == 0)
                {
                    break;
                }
                Thread.Sleep(100);
            }
            _logger.Info($"並列処理を終了しました、合計件数:{context.TotalCount},正常件数:{context.SuccessCount},警告件数:{context.WarningCount},エラー件数:{context.ErrorCount}");
        }

        public static void Run<TData, TExecutor, TContext>(Func<TContext, TExecutor> createExecutorAction,
            IList<TData> sourceData,
            Action<IList<TaskResult<TData>>, TContext> callbackAction,
            TContext context)
            where TData : class
            where TExecutor : ITaskExecutor<TData>
            where TContext : ParallelContext
        {
            Run(createExecutorAction,
                (blockCount, pc) =>
            {
                return AutoPartitionData(sourceData, pc);
            }, callbackAction, context);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TData"></typeparam>
        /// <param name="sourceData"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private static IList<TData> AutoPartitionData<TData, TContext>(IList<TData> sourceData, TContext context)
            where TData : class
            where TContext : ParallelContext
        {
            if (context.AutoPartitionCount < sourceData.Count())
            {
                var partitionData = sourceData.Skip(context.AutoPartitionCount).Take(context.BlockCount).ToList();
                context.AutoPartitionCount += context.BlockCount;
                return partitionData;
            }
            else
            {
                return null;
            }
        }
    }
}
