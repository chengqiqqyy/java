﻿using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Specialized
{
    public class BT107ImportExecutor : CSVImportExecutor
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public BT107ImportExecutor(CSVImportContext context) : base(context)
        {

        }

        // [所有者] 特殊処理
        protected override void SetOwner(CSVFieldData csvFieldData)
        {
            // 所有者設定要否の判断
            if (!_context.JBS_BT_T00_Config.SetOwner || csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_name_customer")
            {
                return;
            }

            var opObj = csvFieldData.CSVRow.EntityData;

            // 顧客情報
            var customerData = opObj.GetAttributeValue<EntityReference>("tsb_lup_name_customer");

            // 顧客がNULLではない場合
            if (customerData != null)
            {
                // 顧客キーファイル
                var customerKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("account");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                keyValues.Add("guid", customerData.Id.ToString());

                // 検索
                var rows = customerKeyFile.Query(keyValues);

                // 所有者
                var ownerid = rows.FirstOrDefault() == null ? "" : rows.FirstOrDefault()["ownerid"].ToString();

                if (!string.IsNullOrEmpty(ownerid))
                {
                    // 所有者タイプ
                    var systemuserKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                    keyValues.Clear();
                    keyValues.Add("guid", ownerid);
                    rows = systemuserKeyFile.Query(keyValues);

                    // チームの場合
                    if (rows.Length < 1)
                    {
                        opObj["ownerid"] = new EntityReference("team", new Guid(ownerid));
                    }
                    // ユーザーの場合
                    else
                    {
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(ownerid));
                    }
                }
                else
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_024, "所有者", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_024, "所有者", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                }
            }
            else
            {
                if (_context.JBS_BT_T00_Config.OwnerSkip)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_023, csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                    return;
                }
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_023, csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
            }
        }

        // 2回[LINK] [フロント確認者1] [フロント確認者2] [審査確認者1] [審査担当者] goto 211
        protected override void AdjustFieldValue(CSVFieldData csvFieldData)
        {
            if (csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_front_checker1" && 
                csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_front_checker2" && 
                csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_judge_checker1" && 
                csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_judge_responsible")
            {
                base.AdjustFieldValue(csvFieldData);
                return;
            }

            // フィールド値
            string fieldValue = null;

            // 検索項目取得
            var linkInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile(linkInfo[1]);
            if (keyFileService == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, linkInfo[1]));
            }

            // キーリスト
            var keys = linkInfo[3].Split(',');

            // フィールドリスト
            var fields = linkInfo[4].Split(',');

            var outFields = "";
            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();

            // 検索条件設定
            for (int i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    // stubユーザーIDセット
                    csvFieldData.FieldValue = _context.JBS_BT_T00_Config.StubUserId;
                    return;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    var temp = fields[i].StartsWith(CSVImportConsts.FIXEDVALUE) ? keys[i] : csvFieldData.CSVRow.DataName[fields[i]];
                    outFields = outFields + $"{temp}（{fields[i]}）";
                    outValue = outValue + checkValue;
                }
                else
                {
                    outFields = outFields + $",{csvFieldData.CSVRow.DataName[fields[i]]}（{fields[i]}）";
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyFileService.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013,
                    csvFieldData.CSVRow.RowNum, linkInfo[1], outFields, outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                // 項目リンク判定
                string[] fieldInfo = null;

                fieldInfo = linkInfo[2].Split('@');

                fieldValue = rows[0][fieldInfo[1]].ToString();

                // 入力値がない場合
                if (string.IsNullOrEmpty(fieldValue))
                {
                    // stubユーザーIDセット
                    csvFieldData.FieldValue = _context.JBS_BT_T00_Config.StubUserId;
                    return;
                }

                var keyFileService2 = CSVImportFactory.GetInstance().GetCSVKeyFile(fieldInfo[2]);
                if (keyFileService2 == null)
                {
                    // キーファイルは必須とする
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, fieldInfo[2]));
                }

                // 検索条件
                keyValues = new Dictionary<string, string>();
                // 検索フィールドをコンフィグに追加
                keyValues.Add(fieldInfo[4], fieldValue);

                // 検索
                rows = keyFileService2.Query(keyValues);

                if (rows.Length == 0)
                {
                    // stubユーザーIDセット
                    csvFieldData.FieldValue = _context.JBS_BT_T00_Config.StubUserId;
                    return;
                }

                fieldValue = rows[0][fieldInfo[3]].ToString();

                if (string.IsNullOrEmpty(fieldValue))
                {
                    // stubユーザーIDセット
                    csvFieldData.FieldValue = _context.JBS_BT_T00_Config.StubUserId;
                    return;
                }

                csvFieldData.FieldValue = fieldValue;
            }
            else
            {
                // stubユーザーIDセット
                csvFieldData.FieldValue = _context.JBS_BT_T00_Config.StubUserId;
            }
        }

        // [DA番号] 特殊処理
        protected override EntityReference ParseLookupAttribute(CSVFieldData csvFieldData)
        {
            if(csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_num_da")
            {
                return base.ParseLookupAttribute(csvFieldData);
            }

            var lMetadata = (LookupAttributeMetadata)csvFieldData.Metadata;

            CSVKeyFileService keyfile = null;
            var factory = CSVImportFactory.GetInstance();
            string lookupEntity = null;
            foreach (var entity in lMetadata.Targets)
            {
                keyfile = factory.GetCSVKeyFile(entity);
                if (keyfile != null)
                {
                    lookupEntity = entity;
                    if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
                    {
                        if (string.IsNullOrEmpty(csvFieldData.FieldValue))
                        {
                            return null;
                        }
                        else
                        {
                            return new EntityReference(lMetadata.Targets[0], new Guid(csvFieldData.FieldValue));
                        }
                    }
                    break;
                }
            }
            if (keyfile == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, string.Join(",", lMetadata.Targets)));
            }

            // CSVフィールド形式チェック
            var fieldInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            // キーリスト
            var keys = fieldInfo[0].Split(',');

            // フィールドリスト
            var fields = fieldInfo[1].Split(',');

            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            // 検索条件設定
            for (var i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    return null;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    outValue = outValue + checkValue;
                }
                else
                {
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyfile.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013,
                    csvFieldData.CSVRow.RowNum, lookupEntity, fieldInfo[1], outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                return new EntityReference(lookupEntity, new Guid(rows[0][CSVImportConsts.GUID].ToString()));
            }
            else
            {
                // 特定DA番号設定
                return new EntityReference(lMetadata.Targets[0], new Guid(_context.JBS_BT_T00_Config.DamiDaNumId));
            }
        }

        // [審査担当部] [審査担当ライン] 特殊処理 [審査担当者]より設定
        protected override void PostParseCSVFieldData(CSVFieldData csvFieldData)
        {
            SetOwner(csvFieldData);
            JudgeResponsible(csvFieldData);
        }

        private void JudgeResponsible(CSVFieldData csvFieldData)
        {
            if(csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_judge_responsible")
            {
                return;
            }

            var judgeResponsible = csvFieldData.CSVRow.EntityData.GetAttributeValue<EntityReference>("tsb_lup_judge_responsible");

            if(judgeResponsible.Id.ToString() == _context.JBS_BT_T00_Config.StubUserId)
            {
                return;
            }

            // ユーザー＆組織階層キーファイル
            var userKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
            var organizationKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_organization_structure");

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            keyValues.Add("guid", judgeResponsible.Id.ToString());

            // 検索
            var rows = userKeyFile.Query(keyValues);

            // ユーザーが見つからない場合
            if (rows.Length < 1)
            {
                throw new Exception($"審査担当者のユーザーが見つかりません。{csvFieldData.CSVRow.RowNum}行目、項目名「審査担当者(tsb_lup_judge_responsible)」、検索値「{judgeResponsible.Id}」");
            }
            // ユーザーが複数件の場合
            if (rows.Length > 1)
            {
                throw new Exception($"審査担当者のユーザーが見つかりません。{csvFieldData.CSVRow.RowNum}行目、項目名「審査担当者(tsb_lup_judge_responsible)」、検索値「{judgeResponsible.Id}」");
            }
            // 所属組織設定されていない場合
            if (string.IsNullOrEmpty(rows[0]["tsb_lup_affiliation_organization"].ToString())) return;

            // 所属組織ID
            var affiliationOrganizationId = rows[0]["tsb_lup_affiliation_organization"].ToString();
            // 検索条件
            keyValues.Clear();
            keyValues.Add("guid", affiliationOrganizationId);

            // 検索
            rows = organizationKeyFile.Query(keyValues);

            // 所属組織が見つからない場合＆複数件の場合
            if (rows.Length < 1)
            {
                throw new Exception($"審査担当者の所属組織が見つかりません。{csvFieldData.CSVRow.RowNum}行目、項目名「審査担当者(tsb_lup_judge_responsible)」、検索値「{affiliationOrganizationId}」");
            }
            // 所属組織が複数件の場合
            if (rows.Length > 1)
            {
                throw new Exception($"審査担当者の所属組織が複数です。{csvFieldData.CSVRow.RowNum}行目、項目名「審査担当者(tsb_lup_judge_responsible)」、検索値「{affiliationOrganizationId}」");
            }

            var organizationType = rows[0]["tsb_ops_type_organization"].ToString();

            // 所属組織は部とライン以外の場合
            if (organizationType != "100000002" && organizationType != "100000003") return;
            // 所属組織は部の場合
            if (organizationType == "100000002")
            {
                csvFieldData.CSVRow.EntityData["tsb_lup_judge_responsible_department"] = new EntityReference("tsb_organization_structure", new Guid(affiliationOrganizationId));
                return;
            }
            // 所属組織はラインの場合
            if (organizationType == "100000003")
            {
                csvFieldData.CSVRow.EntityData["tsb_lup_judge_responsible_line_workflow"] = new EntityReference("tsb_organization_structure", new Guid(affiliationOrganizationId));
                csvFieldData.CSVRow.EntityData["tsb_lup_judge_responsible_department"] = new EntityReference("tsb_organization_structure", new Guid(rows[0]["tsb_lup_department"].ToString()));
                return;
            }
        }

        // 自己参照
        protected override void UpsertEntity(List<(CSVRowData CSVData, Entity EntityData)> batchEntities)
        {
            if (!_context.JBS_BT_T00_Config.SelfLookup)
            {
                base.UpsertEntity(batchEntities);
                return;
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            var updList = new List<(CSVRowData CSVData, Entity EntityData)>();

            foreach (var itemData in batchEntities)
            {
                if (itemData.EntityData.Id != Guid.Empty)
                {
                    if (string.IsNullOrEmpty(itemData.CSVData.RowData["m_tsb_lup_num_loan"]))
                    {
                        itemData.CSVData.IsSuccess = true;
                        continue;
                    }

                    updList.Add((itemData.CSVData, itemData.EntityData));

                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
                else
                {
                    itemData.CSVData.IsSuccess = true;
                }
            }
            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = updList[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                }
            }
        }

    }
}
