﻿SELECT
*
FROM 
[dbo].[mid_annotation_service_history]