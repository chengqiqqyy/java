SELECT 
 *
FROM 
[dbo].[mid_dev_device_types]