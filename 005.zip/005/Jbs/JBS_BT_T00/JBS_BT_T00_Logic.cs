﻿using BatchCommon;
using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using JBS_BT_T00.Helper;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Xml.Linq;

namespace JBS_BT_T00
{
    /// <summary>
    /// 処理クラス
    /// </summary>
    class JBS_BT_T00_Logic : BatchBase
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        #region メイン処理
        /// <summary>
        /// メイン処理
        /// </summary>
        protected override void Main()
        {
            var context = new CSVImportContext();
            context.BatchId = this.batchId;
            context.environmentArgs = environmentArgs;

            GetConfigInfo(context);

            var factory = CSVImportFactory.GetInstance();
            factory.Context = context;
            factory.Initilize();

            var csvService = factory.GetCSVImportService();
            csvService.CrmService = this.d365Client;

            csvService.Execute();

            allCount = context.TotalCount;
            successCount = context.SuccessCount;
            failCount = context.ErrorCount;

            if (failCount > 0)
            {
                endCode = ERROR;
            }
            else if (context.WarningCount > 0)
            {
                endCode = WARNING;
            }
            else
            {
                endCode = SUCCESS;
            }
        }
        #endregion

        #region コンフィグファイル解析
        /// <summary>
        /// 配置ファイル情報取得
        /// </summary>
        private void GetConfigInfo(CSVImportContext context)
        {
            _logger.Info("配置ファイル情報取得");

            // 配置ファイル名
            var configFileName = context.BatchId + "_Config.xml";

            // 配置ファイルパス
            var configPath = Path.Combine(FileHelper.GetExecutingFolder(), CSVImportConsts.FOLDER_CONFIG, configFileName);

            // 配置ファイル存在チェック
            if (!File.Exists(configPath))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_ERROR_005, configFileName));
            }

            // 設定情報初期化
            var csvImportConfig = new JBS_BT_T00_Config();

            // XML情報読み込み
            var wConfig = XElement.Load(configPath);

            // 入力ファイルのパス
            csvImportConfig.InputFilePath = XMLHelper.ElementValueCheck(wConfig, "InputFilePath");

            // 入力ファイルのパス
            csvImportConfig.MappingFile = XMLHelper.ElementValueCheck(wConfig, "MappingFile", false);

            // バックアップフォルダ
            csvImportConfig.BackupPath = XMLHelper.ElementValueCheck(wConfig, "BackupPath");
            if (!Directory.Exists(csvImportConfig.BackupPath))
            {
                Directory.CreateDirectory(csvImportConfig.BackupPath);
            }
            // エラーファイルフォルダ
            csvImportConfig.ErrorPath = XMLHelper.ElementValueCheck(wConfig, "ErrorPath");
            if (!Directory.Exists(csvImportConfig.ErrorPath))
            {
                Directory.CreateDirectory(csvImportConfig.ErrorPath);
            }
            // ファイルの文字コード
            if ("SJIS" == XMLHelper.ElementValueCheck(wConfig, "FileEncode"))
            {
                csvImportConfig.FileEncode = Encoding.GetEncoding("Shift_JIS");
            }
            else
            {
                csvImportConfig.FileEncode = Encoding.UTF8;
            }

            // タイトルあり
            var haveTitle = XMLHelper.ElementValueCheck(wConfig, "HaveTitle");
            if ("false" == haveTitle.ToLower())
            {
                csvImportConfig.HaveTitle = false;
            }
            else if ("true" == haveTitle.ToLower())
            {
                csvImportConfig.HaveTitle = true;
            }

            // キーファイルのパス
            csvImportConfig.KeyFilePath = XMLHelper.ElementValueCheck(wConfig, "KeyFilePath");

            // キーファイル対象リスト
            csvImportConfig.KeyFiles = new List<string>();
            var wKeyFiles = XMLHelper.ElementCheck(wConfig, "KeyFiles");
            var KeyFiles = wKeyFiles.Elements("KeyFile");
            foreach (var keyFile in KeyFiles)
            {
                // キーファイル対象
                csvImportConfig.KeyFiles.Add(keyFile.Value);
            }

            // ヘッダー
            if (wConfig.Elements("Headers") != null)
            {
                var headerElements = wConfig.Elements("Headers").Elements("Header");
                csvImportConfig.Headers = new List<CsvHeader>();
                foreach (var headerElement in headerElements)
                {
                    var csvHeader = new CsvHeader
                    {
                        LogicName = headerElement.Attribute("LogicName")?.Value,
                        DisplayName = headerElement.Attribute("DisplayName")?.Value
                    };
                    csvImportConfig.Headers.Add(csvHeader);
                }
            }

            // 対象エンティティ名
            csvImportConfig.LogicName = XMLHelper.ElementValueCheck(wConfig, "LogicName");

            // 一括削除要否
            var needDelete = XMLHelper.ElementValueCheck(wConfig, "NeedDelete");
            csvImportConfig.NeedDelete = needDelete.ToLower();

            // 不足データ非アクティブ要否
            var needInactive = XMLHelper.ElementValueCheck(wConfig, "NeedInactive");
            if ("false" == needInactive.ToLower())
            {
                csvImportConfig.NeedInactive = false;
            }
            else if ("true" == needInactive.ToLower())
            {
                csvImportConfig.NeedInactive = true;
            }

            // 所有者設定要否
            var setOwner = XMLHelper.ElementValueCheck(wConfig, "SetOwner");
            if ("false" == setOwner.ToLower())
            {
                csvImportConfig.SetOwner = false;
            }
            else if ("true" == setOwner.ToLower())
            {
                csvImportConfig.SetOwner = true;
            }

            // 特定DA番号
            csvImportConfig.SpecificDaNum = XMLHelper.ElementValueCheck(wConfig, "SpecificDaNum", false);

            // 特定システムユーザ
            csvImportConfig.SpecificUser = XMLHelper.ElementValueCheck(wConfig, "SpecificUser", false);

            // サービス通信フラグ
            var doServiceFlag = environmentArgs.ContainsKey("doService") ? environmentArgs["doService"] : "";
            if (doServiceFlag.ToLower() == "false")
            {
                // サービスフラグ
                doService = false;
            }
            csvImportConfig.DoService = doService;

            // 自己参照
            csvImportConfig.SelfLookup = XMLHelper.ElementValueCheck(wConfig, "SelfLookup", false) == "TRUE" ? true : false;

            // 所有者スキップフラグ
            csvImportConfig.OwnerSkip = XMLHelper.ElementValueCheck(wConfig, "OwnerSkip", false) == "TRUE" ? true : false;

            // エラー継続要否
            if (wConfig.Element("ErrorContinueFlag") != null)
            {
                context.ErrorContinueFlag = "true" == wConfig.Element("ErrorContinueFlag").Value.ToLower() ? true : false;
            }

            csvImportConfig.AllFields = new List<Mapping>();

            // キー情報リスト
            csvImportConfig.Keys = new List<Mapping>();
            var wKeys = XMLHelper.ElementCheck(wConfig, "Keys");
            var Keys = wKeys.Elements("Key");
            foreach (var key in Keys)
            {
                // キー情報
                Mapping mapping = new Mapping();

                // CRMフィールド　チェック用
                mapping.CrmColumnForCheck = XMLHelper.ElementValueCheck(key, "CrmColumn");
                // CRMフィールド
                mapping.CrmColumn = mapping.CrmColumnForCheck.Replace(CSVImportConsts.REQUIRED, "");
                // CSVフィールド
                mapping.CsvColumn = XMLHelper.ElementValueCheck(key, "CsvColumn");
                // オプションセットマッピング
                mapping.CrmOptionSetMapping = XMLHelper.ElementValueCheck(key, "OptionSetMapping", false);

                csvImportConfig.Keys.Add(mapping);
            }
            csvImportConfig.AllFields.AddRange(csvImportConfig.Keys);

            // フィールド情報リスト
            csvImportConfig.Fields = new List<Mapping>();
            var wFields = XMLHelper.ElementCheck(wConfig, "Fields");
            var Fields = wFields.Elements("Field");
            foreach (var filed in Fields)
            {
                // フィールド情報
                Mapping mapping = new Mapping();

                // CRMフィールド　チェック用
                mapping.CrmColumnForCheck = XMLHelper.ElementValueCheck(filed, "CrmColumn");
                // CRMフィールド
                mapping.CrmColumn = mapping.CrmColumnForCheck.Replace(CSVImportConsts.REQUIRED, "");
                // CSVフィールド
                mapping.CsvColumn = XMLHelper.ElementValueCheck(filed, "CsvColumn");
                // オプションセットマッピング
                mapping.CrmOptionSetMapping = XMLHelper.ElementValueCheck(filed, "OptionSetMapping", false);
                // コラムスキップフラグ
                mapping.CrmColumnSkip = filed.Element("CrmColumn").FirstAttribute?.Value;

                csvImportConfig.Fields.Add(mapping);
            }
            csvImportConfig.AllFields.AddRange(csvImportConfig.Fields);

            if (wConfig.Element("ThreadCount") != null)
            {
                context.ThreadCount = int.Parse(wConfig.Element("ThreadCount").Value);
            }
            if (wConfig.Element("BlockCount") != null)
            {
                context.BlockCount = int.Parse(wConfig.Element("BlockCount").Value);
            }
            context.JBS_BT_T00_Config = csvImportConfig;
        }
        #endregion
    }
}
