SELECT 
 *
FROM 
[dbo].[mid_dev_websurvey_answer_master]