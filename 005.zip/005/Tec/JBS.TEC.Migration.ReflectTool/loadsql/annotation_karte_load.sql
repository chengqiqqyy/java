﻿SELECT
*
FROM 
[dbo].[mid_annotation_karte]