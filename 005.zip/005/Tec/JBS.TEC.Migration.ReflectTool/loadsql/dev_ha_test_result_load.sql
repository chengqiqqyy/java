﻿SELECT 
 *
FROM 
[dbo].[mid_dev_ha_test_result]