SELECT 
 *
FROM 
[dbo].[mid_dev_product_master]