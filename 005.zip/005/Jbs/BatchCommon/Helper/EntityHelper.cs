﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchCommon.Helper
{
    public class EntityHelper
    {
        #region エンティティ項目値取得
        /// <summary>
        /// エンティティ項目値取得
        /// </summary>
        /// <param name="entity">対象エンティティ</param>
        /// <param name="fieldName">対象フィールド</param>
        /// <returns>エンティティ項目値</returns>
        public static string GetFieldValue(Entity entity, string fieldName)
        {
            // 戻り値定義
            string result = "";

            // 項目取得
            object field = GetEntityField(entity, fieldName);

            if (field == null)
            {
                return result;
            }

            // 値取得
            switch (field.GetType().Name)
            {
                case "Int32":
                    {
                        result = ((int)field).ToString();
                        break;
                    }
                case "Double":
                    {
                        result = ((double)field).ToString();
                        break;
                    }
                case "Decimal":
                    {
                        result = ((decimal)field).ToString("#.##");
                        break;
                    }
                case "String":
                    {
                        result = field.ToString();
                        break;
                    }
                case "Money":
                    {
                        result = ((Money)field).Value.ToString("#.##");
                        break;
                    }
                case "OptionSetValue":
                    {
                        result = ((OptionSetValue)field).Value.ToString();
                        break;
                    }
                case "Boolean":
                    {
                        result = ((Boolean)field).ToString();
                        break;
                    }
                case "EntityReference":
                    {
                        result = ((EntityReference)field).Id.ToString();
                        break;
                    }
                case "DateTime":
                    {
                        result = ((DateTime)field).ToString("yyyy/MM/dd HH:mm:ss");
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return result;
        }
        #endregion

        #region エンティティ項目取得
        /// <summary>
        /// エンティティ項目取得
        /// </summary>
        /// <typeparam name="T">項目値を変換する型</typeparam>
        /// <param name="entity">対象エンティティ</param>
        /// <param name="fieldName">対象フィールド</param>
        /// <returns>エンティティ項目</returns>
        public static object GetEntityField(Entity entity, string fieldName)
        {
            // 存在チェック
            if (!entity.Contains(fieldName))
            {
                return null;
            }

            // 対象フィールド
            object field = entity[fieldName];

            if (field == null)
            {
                return null;
            }

            // AliasedValue判定
            if (field.GetType() == typeof(AliasedValue))
            {
                field = ((AliasedValue)field).Value;
            }

            // DateTime型、ローカル時刻に変換
            if (field.GetType() == typeof(DateTime))
            {
                if (((DateTime)field).Kind == DateTimeKind.Utc)
                {
                    field = ((DateTime)field).ToLocalTime();
                }
            }

            return field;
        }
        #endregion
    }
}
