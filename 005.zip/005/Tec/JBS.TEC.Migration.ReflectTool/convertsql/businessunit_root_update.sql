﻿-- 移行先部署エンティティのROOT部署Guidを取得し、下記のGuid値を上書きすること
UPDATE 
mid_businessunit
SET
mid_newkey = 'Guid'
WHERE
parentbusinessunitid IS NULL