﻿namespace JBS.TEC.Migration.Common.Config
{
    public class ConfigConsts
    {
        public const string KEY_TECCRMDB = "TecCrmDb";
        public const string KEY_TECBIDB = "TecBiDb";
        public const string KEY_TECMIDDB = "MidDB";
    }
}
