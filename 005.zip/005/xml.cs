using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Batch.BT_005.Dto
{
    [System.Xml.Serialization.XmlRoot("BT005")]
    public class ConfigInfos
    {
        [System.Xml.Serialization.XmlArray("Targets")]
        [System.Xml.Serialization.XmlArrayItem("Data")]
        public List<TargetInfo> TargetInfo { get; set; }

        [System.Xml.Serialization.XmlElement("ConnectDB")]
        public DatabaseInfo DatabaseInfo { get; set; }

        [System.Xml.Serialization.XmlElement("SuccessedTime")]
        public string SuccessedTime { get; set; }
    }

    [Serializable]
    public class TargetInfo
    {
        /// <summary> CSVファイル名先頭2文字 </summary>
        [System.Xml.Serialization.XmlAttribute("Id")]
        public string CsvPrefix { get; set; }

        /// <summary> 抽出条件名 </summary>
        [System.Xml.Serialization.XmlElement("Name")]
        public string Name { get; set; }

        /// <summary> CRMエンティティ名 </summary>
        [System.Xml.Serialization.XmlElement("CRMEntity")]
        public string CRMEntity { get; set; }

        /// <summary> CRM側KEYフィールド名 </summary>
        [System.Xml.Serialization.XmlElement("CRMKeyField")]
        public string CRMKeyField { get; set; }

        /// <summary> AX側KEYフィールド名 </summary>
        [System.Xml.Serialization.XmlElement("AXKeyField")]
        public string AXKeyField { get; set; }

        /// <summary> 抽出条件ファイル名 </summary>
        [System.Xml.Serialization.XmlElement("SelectSQL")]
        public string SqlFilePath { get; set; }

        /// <summary> 出力設定ファイル名 </summary>
        [System.Xml.Serialization.XmlElement("OutputConfig")]
        public string OutputConfigPath { get; set; }

        /// <summary> エンティティ設定ファイル名 </summary>
        [System.Xml.Serialization.XmlElement("InputConfig")]
        public string InputConfigPath { get; set; }

        /// <summary> エンティティ設定ファイル名 </summary>
        [System.Xml.Serialization.XmlElement("MappingInfo")]
        public MappingInfo MappingInfo { get; set; }

        /// <summary> 生成後のSQL </summary>
        public string SelectSql { get; set; }

        /// <summary> 出力したCSVファイルパス </summary>
        public string OutputCsvFilePath { get; set; }
    }

    [Serializable]
    public class DatabaseInfo
    {
        /// <summary> データソース名 </summary>
        [System.Xml.Serialization.XmlElement("DataSource")]
        public string DataSource { get; set; }

        /// <summary> データベース名 </summary>
        [System.Xml.Serialization.XmlElement("Database")]
        public string Database { get; set; }

        /// <summary> ユーザー名 </summary>
        [System.Xml.Serialization.XmlElement("UserName")]
        public string UserName { get; set; }

        /// <summary> パスワード </summary>
        [System.Xml.Serialization.XmlElement("PassWord")]
        public string PassWord { get; set; }
    }

    [Serializable]
    public class MappingInfo
    {
        [System.Xml.Serialization.XmlElement("FileName")]
        public string FilePattern { get; set; }

        [System.Xml.Serialization.XmlElement("CharCode")]
        public string CharCode { get; set; }

        [System.Xml.Serialization.XmlElement("Enclosure")]
        public string Enclosure { get; set; }

        [System.Xml.Serialization.XmlElement("SkipRecord")]
        public string SkipRecord { get; set; }

        [System.Xml.Serialization.XmlElement("Field")]
        public List<Field> Fields { get; set; }
    }

    [Serializable]
    public class Field
    {
        [System.Xml.Serialization.XmlAttribute("Type")]
        public string FieldType { get; set; }

        [System.Xml.Serialization.XmlText()]
        public string FieldName { get; set; }
    }

}


/// <summary>
/// コンフィグファイル設定初期化
/// </summary>
public void Init()
{
	try
	{
		// 動作設定ファイルを読み込み、Root要素を取得
		RootElement = XElement.Load(Path.Combine(_context.ConfigPath, _context.ConfigFile));
		// ConfigInfosにデシリアライズ
		XmlSerializer serializer = new XmlSerializer(typeof(ConfigInfos));

		_context.ConfigInfos = (ConfigInfos)serializer.Deserialize(
			new MemoryStream(
				Encoding.UTF8.GetBytes(RootElement.Element(_context.BatchId).ToString()
			)));
	}
	catch (Exception e)
	{
		_context.Logger.Error($"コンフィグファイル初期化失敗しました。エラーメッセージ：{e.Message}");
		throw e;
	}
}


using JBS.Common.Batch.Config;
using JBS.TEC.Batch.BT_005.Dto;
using JBS.TEC.Batch.Common;

namespace JBS.TEC.Batch.BT_005
{
    public class BT005Context : TECBatchContext
    {
        [ConfigMapping("configpath")]
        public string ConfigPath { get; set; }
        [ConfigMapping("ConfigFile")]
        public string ConfigFile { get; set; }
        [ConfigMapping("ImportFolderPath")]
        public string ImportFolderPath { get; set; }
        [ConfigMapping("SuccessFolderPath")]
        public string SuccessFolderPath { get; set; }
        [ConfigMapping("ErrorFolderPath")]
        public string ErrorFolderPath { get; set; }
        [ConfigMapping("DataSource")]
        public string DataSource { get; set; }

        public ConfigInfos ConfigInfos { get; set; }
    }
}
