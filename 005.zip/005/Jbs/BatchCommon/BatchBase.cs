﻿using BatchCommon.Helper;
using Microsoft.VisualBasic.FileIO;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Xml.Linq;

namespace BatchCommon
{
    /// <summary>
    /// バッチ基本クラス
    /// バッチ共通機能実装
    /// </summary>
    public abstract class BatchBase
    {
        #region 変数定義
        // メッセージ
        protected const string MESSAGE_ERROR_001 = "共通設定ファイルが存在しません。(CommonConfig.xml)";
        protected const string MESSAGE_ERROR_002 = "D365に接続できません。";
        protected const string MESSAGE_ERROR_003 = "{0}タグが存在しません。";
        protected const string MESSAGE_ERROR_004 = "{0}が設定されません。";
        protected const string MESSAGE_ERROR_005 = "設定ファイル{0}が存在しません。";
        protected const string MESSAGE_ERROR_006 = "D365への連携処理にエラーが発生しました。";
        protected const string MESSAGE_ERROR_007 = "入力ファイルのカラム数が設定情報と一致しません。";
        protected const string MESSAGE_ERROR_099 = "予期せぬエラーが発生しました。";

        // タブ
        protected const string DELIMITER = "\t";

        // GUID
        protected const string GUID = "guid";

        // REQ
        protected const string REQUIRED = "[REQ]";

        // 固定値
        protected const string FIXEDVALUE = "[固定値]";

        // 行番号列
        protected const string ROWNUM = "ROWNUM";

        // 改行変換コード
        protected const string OVERROW_CHANGE_CODE = "<<br>>";
        protected const string OVERROW_CHANGE_CODE_S = "<br>";
        protected const string OVERROW_CHANGE_CODE_B = "<<BR>>";
        protected const string OVERROW_CHANGE_CODE_SB = "<BR>";

        // 改行コード
        protected const string OVERROW_CODE = "\n";

        // 正常
        protected const int SUCCESS = 0;

        // 警告
        protected const int WARNING = 1;

        // 異常
        protected const int ERROR = 100;

        // 異常
        protected enum ERROR_CODE
        {
            // 共通チェック
            ERROR_100 = 100,
            ERROR_101 = 101,
            ERROR_102 = 102,
            ERROR_105 = 105,
            ERROR_107 = 107,
            ERROR_108 = 108,

            // 想定外
            ERROR_110 = 110
        };

        // バッチID
        protected string batchId = null;

        // 処理結果コード
        protected int endCode = SUCCESS;

        // メッセージ
        protected string endMessage = null;

        // ジョブ実行状況ID
        protected Guid? jobId = null;

        // 対象件数
        protected int allCount = 0;

        // 成功件数
        protected int successCount = 0;

        // 失敗件数
        protected int failCount = 0;

        // D365クライアント
        protected CrmServiceClient d365Client;

        // 共通設定情報
        protected CommonConfig commonConfig;

        // 一括処理件数
        protected int OP_COUNT = 100;

        // 並行処理最大数
        protected int? maxDegreeOfParallelism = null;

        // ファイル出力設定情報
        protected FileOutputConfig fileOutputConfig = null;

        // 全量出力フラグ
        protected bool fileAllOutFlag = false;

        // 現在日時
        protected DateTime? nowTime = null;
        protected DateTime? realNowTime = null;

        // ユーザー情報
        protected EntityCollection users = null;

        // リカバリモード
        protected bool isRecovery = false;

        // 環境変数
        protected Dictionary<string, string> environmentArgs = null;

        // 入力ファイル分割処理件数
        protected int? fileBlockCount = null;

        // ファイル分割取得
        protected TextFieldParser tfp = null;

        // ファイル分割処理総件数
        protected int? blockAllCount = null;

        // リトライ処理回数
        protected int reTryCount = 0;

        // リトライ処理総回数
        protected int reTryAllCount = 0;

        // サービスフラグ
        protected bool doService = true;

        #endregion

        #region 実行処理
        /// <summary>
        /// 実行処理
        /// </summary>
        /// <param name="args">起動パラメータ</param>
        /// <returns>処理結果コード</returns>
        public int Excute(string[] args)
        {
            try
            {
                // 初期処理を実行する
                Init(args);

                // メイン処理を実行する
                Main();

                // 終了処理を実行する
                End();

                // 処理結果コードを返す
                return endCode;
            }
            catch (Exception e)
            {
                // 処理結果コード
                if (endCode < (int)ERROR_CODE.ERROR_100)
                {
                    endCode = (int)ERROR_CODE.ERROR_110;

                    // メッセージ
                    endMessage = MESSAGE_ERROR_099 + Environment.NewLine + e.ToString();
                }
                else if (endCode == (int)ERROR_CODE.ERROR_107)
                {
                    // メッセージ
                    endMessage = e.ToString();
                }
                else
                {
                    // メッセージ
                    endMessage = e.Message;
                }

                // 終了処理を実行する
                End();

                // 処理結果コードを返す
                return endCode;
            }
        }
        #endregion

        #region 初期処理
        /// <summary>
        /// 初期処理
        /// </summary>
        /// <param name="args">起動パラメータ</param>
        protected virtual void Init(string[] args)
        {
            // 環境変数
            var argDic = args.Select(a => a.Split(new[] { '=' }, 2)).GroupBy(
                a => a[0], a => a.Length == 2 ? a[1] : null).ToDictionary(
                g => g.Key, g => g.FirstOrDefault());
            environmentArgs = new Dictionary<string, string>();
            foreach (var val in argDic)
            {
                environmentArgs[val.Key] = val.Value;
            }

            // 初期化
            if (args.Length > 0)
            {
                batchId = environmentArgs.ContainsKey("batchId") ? environmentArgs["batchId"] : GetPaths()[1];

                var allFlag = environmentArgs.ContainsKey("all") ? environmentArgs["all"] : "";
                if (allFlag.ToLower() == "true")
                {
                    // 全量出力フラグ
                    fileAllOutFlag = true;
                }

                var recoveryFlag = environmentArgs.ContainsKey("recovery") ? environmentArgs["recovery"] : "";
                if (recoveryFlag.ToLower() == "true")
                {
                    // リカバリ判定
                    isRecovery = true;
                }

                var doServiceFlag = environmentArgs.ContainsKey("doService") ? environmentArgs["doService"] : "";
                if (doServiceFlag.ToLower() == "false")
                {
                    // サービスフラグ
                    doService = false;
                }
            }
            else
            {
                // バッチID設定(アセンブリ名)
                batchId = GetPaths()[1];
            }

            // 共通設定情報取得
            GetCommonConfig();

            // ログ保存期間判定
            DeleteLogFiles();

            // ログファイル作成
            LogOutput.Init(commonConfig.LogOutPath, batchId);

            // D365に接続
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            ServicePointManager.DefaultConnectionLimit = 65000;
            System.Threading.ThreadPool.SetMinThreads(100, 100);
            ServicePointManager.Expect100Continue = false;
            ServicePointManager.UseNagleAlgorithm = false;
            d365Client = GetD365Connect();
            if (commonConfig.MaxConnectionTimeout != null)
            {
                CrmServiceClient.MaxConnectionTimeout = new TimeSpan(0, commonConfig.MaxConnectionTimeout.Value, 0);
            }
        }
        #endregion

        #region メイン処理
        /// <summary>
        /// メイン処理
        /// </summary>
        abstract protected void Main();
        #endregion

        #region 終了処理
        /// <summary>
        /// 終了処理
        /// </summary>
        protected virtual void End()
        {
            // ログ出力
            // メッセージ
            if (!string.IsNullOrEmpty(endMessage))
            {
                LogOutput.WriteErrorLog(endMessage);
            }

            // 失敗件数
            failCount = allCount - successCount;

            // 警告終了以外の場合
            if (failCount > 0 && endCode == SUCCESS)
            {
                // 処理結果コード
                if (endCode < (int)ERROR_CODE.ERROR_100)
                {
                    endCode = (int)ERROR_CODE.ERROR_110;
                }
            }

            var status = "";

            // 正常
            if (endCode == SUCCESS)
            {
                status = "正常終了";

                // ジョブ実行状況更新
                if (jobId != null && d365Client != null && d365Client.IsReady)
                {
                    var updEntity = new Entity("tsb_operation_status");
                    updEntity.Id = jobId.Value;
                    updEntity["tsb_ops_status"] = new OptionSetValue(100000001);
                    updEntity["tsb_int_num_total"] = allCount;

                    if (commonConfig.SystemDate != null)
                    {
                        updEntity["tsb_date_finished"] = commonConfig.SystemDate.Value.ToUniversalTime();
                    }
                    else
                    {
                        updEntity["tsb_date_finished"] = DateTime.Now.ToUniversalTime();
                    }

                    updEntity["tsb_slt_message"] = "本日の処理は完了しました。";
                    updEntity["statecode"] = new OptionSetValue(0);
                    updEntity["statuscode"] = new OptionSetValue(1);
                    d365Client.Update(updEntity);
                }

                // 全量出力の場合
                // 『起動パラメータ.処理タイプ』＝〔ALL〕の場合
                if (fileAllOutFlag)
                {
                    // 前回成功日時更新
                    UpdateSuccessedTime(realNowTime.Value);
                }
            }
            else if (endCode == WARNING)
            {
                status = "警告終了";
            }
            else
            {
                status = "異常終了";
            }

            WriteLog($"{status} 対象件数：{allCount} 成功件数：{successCount} 失敗件数：{failCount}");

            // 終了ログ出力
            WriteLog(batchId + " 処理終了(終了コード:" + endCode + ")");
        }
        #endregion

        #region D365接続処理
        /// <summary>
        /// D365接続処理
        /// </summary>
        protected CrmServiceClient GetD365Connect()
        {
            var connectStr = $"AuthType=ClientSecret;url={commonConfig.D365Url};" +
                $"ClientId={commonConfig.AppId};ClientSecret={commonConfig.Secret};" +
                $"RequireNewInstance=true";

            try
            {
                var client = new CrmServiceClient(connectStr);

                if (client == null || client.IsReady == false)
                {
                    if (reTryCount < commonConfig.MaxRetryCount && reTryAllCount < commonConfig.MaxRetryAllCount)
                    {
                        LogOutput.WriteErrorLog(MESSAGE_ERROR_002 + Environment.NewLine + client.LastCrmError);
                        // リトライ
                        reTryCount++;
                        reTryAllCount++;
                        WriteLog($"{commonConfig.RetryPauseTime}秒後リトライ開始　連続リトライ回数：{reTryCount}　リトライ総回数：{reTryAllCount}");
                        Thread.Sleep(1000 * commonConfig.RetryPauseTime);
                        return GetD365Connect();
                    }
                    else
                    {
                        endCode = (int)ERROR_CODE.ERROR_101;
                        throw new Exception(MESSAGE_ERROR_002 + Environment.NewLine + client.LastCrmError);
                    }
                }

                reTryCount = 0;

                return client;
            }
            catch (Exception e)
            {
                if (reTryCount < commonConfig.MaxRetryCount && reTryAllCount < commonConfig.MaxRetryAllCount)
                {
                    LogOutput.WriteErrorLog(MESSAGE_ERROR_002 + Environment.NewLine + e.ToString());
                    // リトライ
                    reTryCount++;
                    reTryAllCount++;
                    WriteLog($"{commonConfig.RetryPauseTime}秒後リトライ開始　連続リトライ回数：{reTryCount}　リトライ総回数：{reTryAllCount}");
                    Thread.Sleep(1000 * commonConfig.RetryPauseTime);
                    return GetD365Connect();
                }
                else
                {
                    endCode = (int)ERROR_CODE.ERROR_101;
                    throw new Exception(MESSAGE_ERROR_002 + Environment.NewLine + e.ToString());
                }
            }
        }
        #endregion

        #region 共通設定ファイル情報の取得
        /// <summary>
        /// 共通設定ファイル情報の取得
        /// </summary>
        /// <param name="message"></param>
        protected void GetCommonConfig()
        {
            // 共通設定ファイル情報の取得
            var commonConfigPath = Path.Combine(GetConfigPath(), "CommonConfig.xml");
            if (!File.Exists(commonConfigPath))
            {
                // 設定ファイルが存在しない場合
                endCode = (int)ERROR_CODE.ERROR_100;
                throw new Exception(MESSAGE_ERROR_001);
            }

            commonConfig = new CommonConfig();
            var wConfig = XElement.Load(commonConfigPath);

            // D365 URL
            commonConfig.D365Url = ElementValueCheck(wConfig, "D365Url");

            // アプリユーザーID
            if (wConfig.Element("AppId") != null)
            {
                commonConfig.AppId = wConfig.Element("AppId").Value;
            }

            // シークレット
            if (wConfig.Element("Secret") != null)
            {
                commonConfig.Secret = wConfig.Element("Secret").Value;
            }

            // ログ出力パス
            commonConfig.LogOutPath = ElementValueCheck(wConfig, "LogOutPath");

            // ログファイル保存期間
            commonConfig.LogSaveDays = wConfig.Element("LogSaveDays").Value;

            // バックアップファイル保存期間
            commonConfig.BackUpSaveDays = wConfig.Element("BackUpSaveDays").Value;

            // エラー継続要否フラグ
            if (wConfig.Element("ErrorContinueFlag") != null)
            {
                commonConfig.ErrorContinueFlag = "true" == wConfig.Element("ErrorContinueFlag").Value.ToLower() ? true : false;
            }
            else
            {
                commonConfig.ErrorContinueFlag = false;
            }

            // リトライMAX総回数
            if (wConfig.Element("MaxRetryAllCount") != null && !string.IsNullOrEmpty(wConfig.Element("MaxRetryAllCount").Value))
            {
                commonConfig.MaxRetryAllCount = int.Parse(wConfig.Element("MaxRetryAllCount").Value);
            }
            else
            {
                commonConfig.MaxRetryAllCount = 10;
            }

            // リトライカウント
            if (wConfig.Element("MaxRetryCount") != null && !string.IsNullOrEmpty(wConfig.Element("MaxRetryCount").Value))
            {
                commonConfig.MaxRetryCount = int.Parse(wConfig.Element("MaxRetryCount").Value);
            }
            else
            {
                commonConfig.MaxRetryCount = 3;
            }

            // リトライ待ち時間
            if (wConfig.Element("RetryPauseTime") != null && !string.IsNullOrEmpty(wConfig.Element("RetryPauseTime").Value))
            {
                commonConfig.RetryPauseTime = int.Parse(wConfig.Element("RetryPauseTime").Value);
            }
            else
            {
                commonConfig.RetryPauseTime = 60;
            }

            // タイムアウト時間設定
            if (wConfig.Element("MaxConnectionTimeout") != null && !string.IsNullOrEmpty(wConfig.Element("MaxConnectionTimeout").Value))
            {
                commonConfig.MaxConnectionTimeout = int.Parse(wConfig.Element("MaxConnectionTimeout").Value);
            }

            // システム日付設定
            nowTime = DateTime.Now;
            realNowTime = nowTime;

            // システム日付
            if (wConfig.Element("SystemDate") != null && !string.IsNullOrEmpty(wConfig.Element("SystemDate").Value))
            {
                commonConfig.SystemDate = DateTime.Parse(wConfig.Element("SystemDate").Value);
                commonConfig.SystemDate = commonConfig.SystemDate.Value.AddHours(nowTime.Value.Hour)
                    .AddMinutes(nowTime.Value.Minute).AddSeconds(nowTime.Value.Second);
                nowTime = commonConfig.SystemDate;
            }

            // 日付差値
            if (wConfig.Element("DateDiff") != null && !string.IsNullOrEmpty(wConfig.Element("DateDiff").Value))
            {
                var dateDiff = int.Parse(wConfig.Element("DateDiff").Value);
                nowTime = nowTime.Value.AddDays(dateDiff);
                commonConfig.SystemDate = nowTime;
            }

            // 認証情報
            commonConfig.Authentications = new Dictionary<string, (string, string)>();
            var wAuthentications = ElementCheck(wConfig, "Authentications");
            var authentications = wAuthentications.Elements("Authentication");
            foreach (var authentication in authentications)
            {
                // BatchId
                var curBatchId = authentication.Attribute("id").Value;

                // AppId
                var appid = authentication.Element("AppId").Value;

                // Secret
                var secret = authentication.Element("Secret").Value;

                // 認証情報追加
                commonConfig.Authentications.Add(curBatchId, (appid, secret));
            }

            // バッチID
            if (commonConfig.Authentications.ContainsKey(batchId))
            {
                commonConfig.AppId = commonConfig.Authentications[batchId].appid;
                commonConfig.Secret = commonConfig.Authentications[batchId].secret;
            }
        }
        #endregion

        #region ログ保存期間判定
        /// <summary>
        /// ログ保存期間判定
        /// </summary>
        private void DeleteLogFiles()
        {
            // ログ保存期間判定
            if (!string.IsNullOrEmpty(commonConfig.LogSaveDays) && commonConfig.LogSaveDays != "0")
            {
                var days = int.Parse(commonConfig.LogSaveDays) * -1;

                var mintime = nowTime.Value.AddDays(days).ToString("yyyyMMddHHmmss");

                var logFileNames = Directory.GetFiles(commonConfig.LogOutPath);

                foreach (var logFileName in logFileNames)
                {
                    var fileInfo = Path.GetFileNameWithoutExtension(logFileName).Split('_');
                    var fileTitle = fileInfo[0];
                    var fileTime = fileInfo[1];

                    if (fileTitle == batchId && fileTime.CompareTo(mintime) < 0)
                    {
                        File.Delete(logFileName);
                    }
                }
            }
        }
        #endregion

        #region ログ作成処理
        /// <summary>
        /// ログ作成処理
        /// </summary>
        /// <param name="message"></param>
        protected void WriteLog(string message)
        {
            LogOutput.WriteLog(message);
        }
        #endregion

        #region バッチ実行環境のパス取得
        /// <summary>
        /// バッチ実行環境のパス取得する。
        /// </summary>
        /// <returns>バッチ実行環境のパスと名</returns>
        protected string[] GetPaths()
        {
            // バッチ実行環境のパスと名配列
            var returnPaths = new string[2];

            // バッチ実行環境のパスを取得する
            var paths = Process.GetCurrentProcess().MainModule
                .FileName.Split('\\');

            var appPath = string.Empty;
            var appName = string.Empty;
            var sb = new StringBuilder();

            // バッチ実行環境のパスを作成する
            for (int i = 0; i < paths.Length - 1; i++)
            {
                // 当該配列データは配列後ろから2番目と1番目以外の場合
                if (i != paths.Length - 2)
                {
                    // 最後にバッチ実行環境パスデータを追加する
                    sb.Append(paths[i]);
                    sb.Append("\\");
                }

                // 当該配列データは配列後ろから2番目の場合
                else
                {
                    // 最後にバッチ実行環境パスデータを追加する
                    sb.Append(paths[i]);
                }
            }

            // バッチ実行環境パス
            appPath = sb.ToString();

            // バッチ実行環境名
            appName = paths[paths.Length - 1].Split('.')[0];

            // バッチ実行環境のパスと名配列を設定する
            returnPaths[0] = appPath;
            returnPaths[1] = appName;

            // バッチ実行環境のパスと名配列戻る
            return returnPaths;
        }
        #endregion

        #region 設定ファイルパス取得
        /// <summary>
        /// 設定ファイルパス取得
        /// </summary>
        /// <returns></returns>
        protected string GetConfigPath()
        {
            return Path.Combine(GetPaths()[0], "BatchConfig");
        }
        #endregion

        #region Elementの存在チェック
        /// <summary>
        /// Elementの存在チェック
        /// </summary>
        /// <param name="pXml">Element</param>
        /// <param name="pTabName">Element名</param>
        protected XElement ElementCheck(XElement pXml, string pTabName)
        {
            var pXmlTab = pXml.Element(pTabName);
            if (pXmlTab == null)
            {
                throw new Exception(string.Format(MESSAGE_ERROR_003, pTabName));
            }

            return pXmlTab;
        }
        #endregion

        #region ElementのValueチェック
        /// <summary>
        /// ElementのValueチェック
        /// </summary>
        /// <param name="pXml">Element</param>
        /// <param name="pElementName">Element名</param>
        protected string ElementValueCheck(XElement pXml, string pElementName)
        {
            var pElement = pXml.Element(pElementName);
            if (pElement == null || String.IsNullOrWhiteSpace(pElement.Value))
            {
                // 取得できない場合
                throw new Exception(string.Format(MESSAGE_ERROR_004, pElementName));
            }

            return pElement.Value;
        }
        #endregion

        #region データ全量検索処理
        /// <summary>
        /// データ全量検索処理
        /// </summary>
        /// <param name="expression">検索対象</param>
        /// <returns>検索結果</returns>
        protected EntityCollection GetAllData(QueryExpression expression)
        {
            try
            {
                return CDSHelper.GetAllData(d365Client, expression);
            }
            catch (Exception e)
            {
                if (reTryCount < commonConfig.MaxRetryCount && reTryAllCount < commonConfig.MaxRetryAllCount)
                {
                    LogOutput.WriteErrorLog(e.ToString());
                    // リトライ
                    reTryCount++;
                    reTryAllCount++;
                    WriteLog($"{commonConfig.RetryPauseTime}秒後リトライ開始　連続リトライ回数：{reTryCount}　リトライ総回数：{reTryAllCount}");
                    Thread.Sleep(1000 * commonConfig.RetryPauseTime);

                    d365Client = GetD365Connect();

                    var ret = GetAllData(expression);

                    reTryCount = 0;

                    return ret;
                }
                else
                {
                    endCode = (int)ERROR_CODE.ERROR_101;
                    LogOutput.WriteErrorLog(MESSAGE_ERROR_002);
                    throw e;
                }
            }
        }
        #endregion

        #region データ全量検索処理(分割)
        /// <summary>
        /// データ全量検索処理(分割)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="expression"></param>
        /// <param name="next"></param>
        /// <returns></returns>
        protected (QueryExpression expression, EntityCollection data) GetBlockData(IOrganizationService service, QueryExpression expression, bool next)
        {
            try
            {
                return CDSHelper.GetBlockData(d365Client, expression, next);
            }
            catch (Exception e)
            {
                if (reTryCount < commonConfig.MaxRetryCount && reTryAllCount < commonConfig.MaxRetryAllCount)
                {
                    LogOutput.WriteErrorLog(e.ToString());
                    // リトライ
                    reTryCount++;
                    reTryAllCount++;
                    WriteLog($"{commonConfig.RetryPauseTime}秒後リトライ開始　連続リトライ回数：{reTryCount}　リトライ総回数：{reTryAllCount}");
                    Thread.Sleep(1000 * commonConfig.RetryPauseTime);

                    d365Client = GetD365Connect();

                    var ret = GetBlockData(d365Client, expression, next);

                    reTryCount = 0;

                    return ret;
                }
                else
                {
                    endCode = (int)ERROR_CODE.ERROR_101;
                    LogOutput.WriteErrorLog(MESSAGE_ERROR_002);
                    throw e;
                }
            }
        }
        #endregion

        #region エンティティ項目取得
        /// <summary>
        /// エンティティ項目取得
        /// </summary>
        /// <typeparam name="T">項目値を変換する型</typeparam>
        /// <param name="entity">対象エンティティ</param>
        /// <param name="fieldName">対象フィールド</param>
        /// <returns>エンティティ項目</returns>
        protected object GetEntityField(Entity entity, string fieldName)
        {
            return EntityHelper.GetEntityField(entity, fieldName);
        }
        #endregion

        #region エンティティ項目値取得
        /// <summary>
        /// エンティティ項目値取得
        /// </summary>
        /// <param name="entity">対象エンティティ</param>
        /// <param name="fieldName">対象フィールド</param>
        /// <returns>エンティティ項目値</returns>
        protected string GetFieldValue(Entity entity, string fieldName)
        {
            return EntityHelper.GetFieldValue(entity, fieldName);
        }
        #endregion

        #region CSV列の値編集
        /// <summary>
        /// CSV列の値編集
        /// </summary>
        /// <param name="field">対象値</param>
        /// <returns>編集後値</returns>
        protected string MakeCsvField(string field)
        {
            return CSVHelper.MakeCsvField(field);
        }
        #endregion

        #region CSVデータ取得
        /// <summary>
        /// CSVデータ取得
        /// </summary>
        protected List<Dictionary<string, string>> GetCsvData(string csvFileName, Boolean hasTitle, Encoding encoding)
        {
            var csvRecords = new List<Dictionary<string, string>>();

            //読み込む
            var tfp = new TextFieldParser(csvFileName, encoding)
            {
                //フィールドが文字で区切られているとする
                TextFieldType = FieldType.Delimited,

                //区切り文字をタブとする
                Delimiters = new string[] { DELIMITER },

                //フィールドを"で囲み、改行文字、区切り文字を含めることができるか
                HasFieldsEnclosedInQuotes = false,

                //フィールドの前後からスペースを削除する
                TrimWhiteSpace = false
            };

            var i = 0;
            var titleRow = new string[] { };

            while (!tfp.EndOfData)
            {
                //フィールドを読み込む
                var fields = tfp.ReadFields();

                if (i == 0)
                {
                    i++;
                    if (hasTitle)
                    {
                        titleRow = fields;
                    }
                    else
                    {
                        var j = 0;
                        titleRow = new string[fields.Length];
                        foreach (string c in fields)
                        {
                            titleRow[j] = "Column" + (j + 1).ToString();
                            j++;
                        }

                        var dic = new Dictionary<string, string>();
                        for (int h = 0; h < titleRow.Length; h++)
                        {
                            dic.Add(titleRow[h], fields[h].Replace(OVERROW_CHANGE_CODE, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_B, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_S, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_SB, OVERROW_CODE));
                        }

                        dic.Add(ROWNUM, i.ToString());
                        csvRecords.Add(dic);
                    }
                }
                else
                {
                    i++;
                    var dic = new Dictionary<string, string>();
                    for (int h = 0; h < titleRow.Length; h++)
                    {
                        dic.Add(titleRow[h], fields[h].Replace(OVERROW_CHANGE_CODE, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_B, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_S, OVERROW_CODE)
                                .Replace(OVERROW_CHANGE_CODE_SB, OVERROW_CODE));
                    }

                    dic.Add(ROWNUM, i.ToString());
                    csvRecords.Add(dic);
                }
            }

            //後始末
            tfp.Close();

            return csvRecords;
        }
        #endregion

        #region CSVデータ取得(分割処理)
        /// <summary>
        /// CSVデータ取得
        /// </summary>
        protected List<Dictionary<string, string>> GetBlockCsvData(string csvFileName, Boolean hasTitle, Encoding encoding)
        {
            try
            {
                var csvRecords = new List<Dictionary<string, string>>();

                //読み込む
                if (tfp == null)
                {
                    blockAllCount = 0;

                    tfp = new TextFieldParser(csvFileName, encoding)
                    {
                        //フィールドが文字で区切られているとする
                        TextFieldType = FieldType.Delimited,

                        //区切り文字をタブとする
                        Delimiters = new string[] { DELIMITER },

                        //フィールドを"で囲み、改行文字、区切り文字を含めることができるか
                        HasFieldsEnclosedInQuotes = false,

                        //フィールドの前後からスペースを削除する
                        TrimWhiteSpace = false
                    };
                }

                var i = 0;
                var titleRow = new string[] { };

                while (i < fileBlockCount.Value && !tfp.EndOfData)
                {
                    //フィールドを読み込む
                    var fields = tfp.ReadFields();

                    blockAllCount++;

                    if (i == 0)
                    {
                        i++;
                        if (hasTitle)
                        {
                            titleRow = fields;
                        }
                        else
                        {
                            int j = 0;
                            titleRow = new string[fields.Length];
                            foreach (string c in fields)
                            {
                                titleRow[j] = "Column" + (j + 1).ToString();
                                j++;
                            }

                            var dic = new Dictionary<string, string>();
                            for (int h = 0; h < titleRow.Length; h++)
                            {
                                dic.Add(titleRow[h], fields[h].Replace(OVERROW_CHANGE_CODE, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_B, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_S, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_SB, OVERROW_CODE));
                            }

                            dic.Add(ROWNUM, blockAllCount.Value.ToString());
                            csvRecords.Add(dic);
                        }
                    }
                    else
                    {
                        i++;
                        var dic = new Dictionary<string, string>();
                        for (int h = 0; h < titleRow.Length; h++)
                        {
                            dic.Add(titleRow[h], fields[h].Replace(OVERROW_CHANGE_CODE, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_B, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_S, OVERROW_CODE)
                                    .Replace(OVERROW_CHANGE_CODE_SB, OVERROW_CODE));
                        }

                        dic.Add(ROWNUM, blockAllCount.Value.ToString());
                        csvRecords.Add(dic);
                    }
                }

                //後始末
                if (tfp.EndOfData)
                {
                    tfp.Close();
                }

                return csvRecords;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_105;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_007);
                throw e;
            }
        }
        #endregion

        #region CSVファイルタイトル取得
        /// <summary>
        /// CSVファイルタイトル取得
        /// </summary>
        protected List<string> GetCsvTitle(string csvFileName, Encoding encoding)
        {
            //読み込む
            var tfp = new TextFieldParser(csvFileName, encoding)
            {
                //フィールドが文字で区切られているとする
                //デフォルトでDelimitedなので、必要なし
                TextFieldType = FieldType.Delimited,

                //区切り文字をタブとする
                Delimiters = new string[] { DELIMITER },

                //フィールドを"で囲み、改行文字、区切り文字を含めることができるか
                //デフォルトでtrueなので、必要なし
                HasFieldsEnclosedInQuotes = true,

                //フィールドの前後からスペースを削除する
                //デフォルトでtrueなので、必要なし
                TrimWhiteSpace = true
            };

            //フィールドを読み込む
            string[] fields = tfp.ReadFields();

            //後始末
            tfp.Close();

            return fields.ToList();
        }
        #endregion

        #region 一括処理（新規登録）(キー付き)
        /// <summary>
        /// 一括処理（新規登録）(キー付き)
        /// <summary>
        /// </summary>
        /// <param name="insertEntitys">新規登録リスト</param>
        /// <param name="fileData">入力ファイルデータ</param>
        /// <param name="countFlag"></param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleInsertWithKey(Dictionary<string, Entity> insertEntitys, bool countFlag)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (insertEntitys == null || insertEntitys.Count == 0)
                {
                    return failsList;
                }

                // 並行処理判定
                if (maxDegreeOfParallelism != null)
                {
                    var createdEntityResults = CDSHelper.ParallelMultipleInsertWithKey(insertEntitys,
                        d365Client, maxDegreeOfParallelism.Value);

                    // 処理結果判定
                    foreach (var ent in createdEntityResults)
                    {
                        // 処理失敗の場合
                        if (string.IsNullOrEmpty(ent.guid))
                        {
                            if (countFlag)
                            {
                                failCount++;
                            }
                            failsList.Add(ent.key);
                        }
                        else
                        {
                            if (countFlag)
                            {
                                successCount++;
                            }
                            // GUID設定
                            insertEntitys[ent.key].Id = new Guid(ent.guid);
                        }
                    }
                }
                else
                {
                    failsList = CDSHelper.MultipleInsertWithKey(insertEntitys, d365Client);

                    // 成功失敗件数
                    if (countFlag)
                    {
                        successCount += insertEntitys.Count - failsList.Count;
                        failCount += failsList.Count;
                    }
                }

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（更新）(キー付き)
        /// <summary>
        /// 一括処理（更新）(キー付き)
        /// </summary>
        /// <param name="updateEntitys">更新リスト</param>
        /// <param name="countFlag"></param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleUpdateWithKey(Dictionary<string, Entity> updateEntitys, bool countFlag)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (updateEntitys == null || updateEntitys.Count == 0)
                {
                    return failsList;
                }

                // 並行処理判定
                if (maxDegreeOfParallelism != null)
                {
                    var updatedErrorResults = CDSHelper.ParallelMultipleUpdateWithKey(updateEntitys,
                        d365Client, maxDegreeOfParallelism.Value);

                    // 処理結果判定
                    foreach (var errorRow in updatedErrorResults)
                    {
                        failsList.Add(errorRow);
                    }

                    // 成功失敗件数
                    if (countFlag)
                    {
                        successCount += updateEntitys.Count - updatedErrorResults.Count;
                        failCount += updatedErrorResults.Count;
                    }
                }
                else
                {
                    failsList = CDSHelper.MultipleUpdateWithKey(updateEntitys, d365Client);

                    // 成功失敗件数
                    if (countFlag)
                    {
                        successCount += updateEntitys.Count - failsList.Count;
                        failCount += failsList.Count;
                    }
                }

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（新規登録）
        /// <summary>
        /// 一括処理（新規登録）
        /// <summary>
        /// </summary>
        /// <param name="insertEntitys">新規登録リスト</param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleInsert(List<Entity> insertEntitys)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (insertEntitys == null || insertEntitys.Count == 0)
                {
                    return failsList;
                }

                // 処理実行
                var entitiesDic = new Dictionary<string, Entity>();
                var i = 0;
                foreach (var ent in insertEntitys)
                {
                    i++;
                    entitiesDic.Add(i.ToString(), ent);
                }
                failsList = MultipleInsertWithKey(entitiesDic, true);

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（更新）
        /// <summary>
        /// 一括処理（更新）
        /// </summary>
        /// <param name="updateEntitys">更新リスト</param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleUpdate(List<Entity> updateEntitys)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (updateEntitys == null || updateEntitys.Count == 0)
                {
                    return failsList;
                }

                // 処理実行
                var entitiesDic = new Dictionary<string, Entity>();
                var i = 0;
                foreach (var ent in updateEntitys)
                {
                    i++;
                    entitiesDic.Add(i.ToString(), ent);
                }
                failsList = MultipleUpdateWithKey(entitiesDic, true);

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（削除）
        /// <summary>
        /// 一括処理（削除）
        /// <summary>
        /// </summary>
        /// <param name="deleteEntitys">削除リスト</param>
        /// <returns>失敗リスト</returns>
        protected void MultipleDelete(EntityCollection deleteEntitys)
        {
            try
            {
                // NULLチェック
                if (deleteEntitys == null || deleteEntitys.Entities.Count == 0)
                {
                    return;
                }

                // 失敗件数
                var fails = 0;

                // 並行処理判定
                if (maxDegreeOfParallelism != null)
                {
                    fails = CDSHelper.ParallelMultipleDelete(deleteEntitys, d365Client, maxDegreeOfParallelism.Value);
                }
                else
                {
                    fails = CDSHelper.MultipleDelete(deleteEntitys, d365Client);
                }

                // 成功失敗件数
                successCount += deleteEntitys.Entities.Count - fails;
                failCount += fails;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（新規登録）カウント不要
        /// <summary>
        /// 一括処理（新規登録）カウント不要
        /// <summary>
        /// </summary>
        /// <param name="insertEntitys">新規登録リスト</param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleInsertDontCount(List<Entity> insertEntitys)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (insertEntitys == null || insertEntitys.Count == 0)
                {
                    return failsList;
                }

                // 処理実行
                var entitiesDic = new Dictionary<string, Entity>();
                var i = 0;
                foreach (var ent in insertEntitys)
                {
                    i++;
                    entitiesDic.Add(i.ToString(), ent);
                }
                failsList = MultipleInsertWithKey(entitiesDic, false);

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（更新）カウント不要
        /// <summary>
        /// 一括処理（更新）カウント不要
        /// </summary>
        /// <param name="updateEntitys">更新リスト</param>
        /// <returns>失敗リスト</returns>
        protected List<string> MultipleUpdateDontCount(List<Entity> updateEntitys)
        {
            try
            {
                // 失敗リスト
                var failsList = new List<string>();

                // NULLチェック
                if (updateEntitys == null || updateEntitys.Count == 0)
                {
                    return failsList;
                }

                // 処理実行
                var entitiesDic = new Dictionary<string, Entity>();
                var i = 0;
                foreach (var ent in updateEntitys)
                {
                    i++;
                    entitiesDic.Add(i.ToString(), ent);
                }
                failsList = MultipleUpdateWithKey(entitiesDic, false);

                return failsList;
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region 一括処理（削除）カウント不要
        /// <summary>
        /// 一括処理（削除）カウント不要
        /// <summary>
        /// </summary>
        /// <param name="deleteEntitys">削除リスト</param>
        /// <returns>失敗リスト</returns>
        protected void MultipleDeleteDontCount(EntityCollection deleteEntitys)
        {
            try
            {
                // NULLチェック
                if (deleteEntitys == null || deleteEntitys.Entities.Count == 0)
                {
                    return;
                }

                // 並行処理判定
                if (maxDegreeOfParallelism != null)
                {
                    CDSHelper.ParallelMultipleDelete(deleteEntitys, d365Client, maxDegreeOfParallelism.Value);
                }
                else
                {
                    CDSHelper.MultipleDelete(deleteEntitys, d365Client);
                }
            }
            catch (Exception e)
            {
                endCode = (int)ERROR_CODE.ERROR_107;
                LogOutput.WriteErrorLog(MESSAGE_ERROR_006);
                throw e;
            }
        }
        #endregion

        #region ファイル出力設定情報取得
        /// <summary>
        /// ファイル出力設定情報取得
        /// </summary>
        protected void GetFileOutputConfigInfo()
        {
            WriteLog("ファイル出力設定情報取得");

            // 配置ファイル名
            var configFileName = batchId + "_Config.xml";

            // 配置ファイルパス
            var configPath = Path.Combine(GetConfigPath(), configFileName);

            // 配置ファイル存在チェック
            if (!File.Exists(configPath))
            {
                endCode = (int)ERROR_CODE.ERROR_102;
                throw new Exception(string.Format(MESSAGE_ERROR_005, configFileName));
            }

            // 設定情報初期化
            fileOutputConfig = new FileOutputConfig();

            // XML情報読み込み
            var wConfig = XElement.Load(configPath);

            // 出力フォルダ_夜間
            var pElement = wConfig.Element("FileOutPath");
            if (pElement != null && !string.IsNullOrWhiteSpace(pElement.Value))
            {
                fileOutputConfig.FileOutPath = pElement.Value;
            }

            // 出力ファイル名_夜間
            pElement = wConfig.Element("FileOutName");
            if (pElement != null && !string.IsNullOrWhiteSpace(pElement.Value))
            {
                fileOutputConfig.FileOutName = pElement.Value;
            }

            // 出力フォルダ_日中
            pElement = wConfig.Element("FileOutPathDay");
            if (pElement != null && !string.IsNullOrWhiteSpace(pElement.Value))
            {
                fileOutputConfig.FileOutPathDay = pElement.Value;
            }

            // 出力ファイル名_日中
            pElement = wConfig.Element("FileOutNameDay");
            if (pElement != null && !string.IsNullOrWhiteSpace(pElement.Value))
            {
                fileOutputConfig.FileOutNameDay = pElement.Value;
            }

            // 前回成功日時
            pElement = wConfig.Element("SuccessedTime");
            if (pElement != null && !string.IsNullOrWhiteSpace(pElement.Value))
            {
                fileOutputConfig.SuccessedTime = DateTime.Parse(pElement.Value);
            }
        }
        #endregion

        #region 前回成功日時更新
        /// <summary>
        /// 前回成功日時更新
        /// </summary>
        protected void UpdateSuccessedTime(DateTime successedTime)
        {
            WriteLog("前回成功日時更新");

            // 配置ファイル名
            var configFileName = batchId + "_Config.xml";

            // 配置ファイルパス
            var configPath = Path.Combine(GetConfigPath(), configFileName);

            // 設定情報初期化
            fileOutputConfig = new FileOutputConfig();

            // XML情報読み込み
            var wConfig = XElement.Load(configPath);

            // 前回成功日時
            var pElement = wConfig.Element("SuccessedTime");
            pElement.Value = successedTime.ToString("yyyy/MM/dd HH:mm:sss");

            wConfig.Save(configPath);
        }
        #endregion

        #region D365データ出力(CSV)
        /// <summary>
        /// D365データ出力(CSV)
        /// </summary>
        /// <param name="fileName">出力ファイル名</param>
        /// <param name="fields">出力対象フィールド</param>
        /// <param name="results">出力対象データ</param>
        /// <param name="first"></param>
        protected void OutToFile(Dictionary<string, string> fields, EntityCollection results, bool first)
        {
            // ファイルパス
            var fileOutName = "";

            // 全量の場合（夜間）
            if (fileAllOutFlag)
            {
                fileOutName = Path.Combine(fileOutputConfig.FileOutPath, fileOutputConfig.FileOutName);
            }
            else
            {
                fileOutName = Path.Combine(fileOutputConfig.FileOutPathDay, fileOutputConfig.FileOutNameDay);
            }

            // 総件数
            allCount += results.Entities.Count;

            // ユーザー情報取得
            if (users == null)
            {
                // データ検索
                var queryExpression = new QueryExpression("systemuser");
                // 行員ID
                queryExpression.ColumnSet.AddColumn("tsb_slt_bank_clerk_id");

                // 検索
                users = GetAllData(queryExpression);
            }

            // 初回の場合
            if (first)
            {
                if (File.Exists(fileOutName))
                {
                    // 一般的にファイルが存在しないが、万が一ある場合ファイルをバックアップする
                    var backupPath = Path.GetDirectoryName(fileOutName) + "\\BackUp";
                    if (!Directory.Exists(backupPath))
                    {
                        Directory.CreateDirectory(backupPath);
                    }

                    var backupFileName = Path.GetFileNameWithoutExtension(fileOutName)
                        + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".csv";
                    backupFileName = Path.Combine(backupPath, backupFileName);

                    File.Copy(fileOutName, backupFileName);
                    File.Delete(fileOutName);
                }

                if (batchId != "JBS_BT_033")
                {
                    // 出力行作成
                    var row = new StringBuilder();

                    foreach (var key in fields.Keys)
                    {
                        var lable = "";
                        var value = "";

                        row.Append(MakeCsvField(lable));
                        row.Append(DELIMITER);

                        if (fields[key].Contains("option") || fields[key].Contains("user"))
                        {
                            row.Append(MakeCsvField(value));
                            row.Append(DELIMITER);
                        }

                        if (fields[key].Contains("tenban"))
                        {
                            row.Append(MakeCsvField(value));
                            row.Append(DELIMITER);
                        }

                        if (fields[key].Contains("kokyakubango"))
                        {
                            row.Append(MakeCsvField(value));
                            row.Append(DELIMITER);
                        }
                    }

                    // データ抽出日時
                    row.Append(MakeCsvField(nowTime.Value.ToString("yyyy/MM/dd HH:mm")));
                    row.Append(DELIMITER);

                    // 最後のタブを削除
                    var rowStr = row.ToString();
                    rowStr = rowStr.Substring(0, rowStr.Length - 1);

                    // 出力データ
                    var outDataTemp = new List<string>();

                    outDataTemp.Add(rowStr);
                    // 行出力
                    File.AppendAllLines(fileOutName, outDataTemp, Encoding.GetEncoding("Shift_JIS"));
                }
            }

            // 出力データ
            var outData = new List<string>();

            // すべての行出力
            foreach (var retEntity in results.Entities)
            {
                // インサイダー等極秘情報
                var insider = false;
                if (retEntity.Contains("tsb_top_insider"))
                {
                    insider = (bool)retEntity["tsb_top_insider"];
                }

                // 出力行作成
                var row = new StringBuilder();

                foreach (var key in fields.Keys)
                {
                    var lable = "";
                    var value = "";

                    // インサイダー判定
                    if (fields[key].Contains("insider") && insider)
                    {
                        lable = "■■■■■■■■";
                        value = "999999999";
                    }
                    else if (retEntity.Contains(key))
                    {
                        // 該当項目取得
                        var objVal = retEntity[key];

                        // タイプ
                        var objType = objVal.GetType().ToString();

                        if (objType == "Microsoft.Xrm.Sdk.AliasedValue")
                        {
                            objVal = ((AliasedValue)objVal).Value;
                            objType = objVal.GetType().ToString();
                        }

                        // 検索フィールドの場合
                        if (objType == "Microsoft.Xrm.Sdk.EntityReference")
                        {
                            lable = ((EntityReference)objVal).Name;
                        }
                        else if (objType == "Microsoft.Xrm.Sdk.OptionSetValue")
                        {
                            // オプションセットの場合
                            if (retEntity.FormattedValues.Contains(key))
                            {
                                lable = retEntity.FormattedValues[key];
                            }
                            value = ((OptionSetValue)objVal).Value.ToString();
                        }
                        else if (objType == "System.Boolean")
                        {
                            // 二つオプションの場合
                            if (retEntity.FormattedValues.Contains(key))
                            {
                                lable = retEntity.FormattedValues[key];
                            }
                            value = objVal.ToString().ToLower();
                            if (value == "true")
                            {
                                value = "0";
                            }
                            else
                            {
                                value = "1";
                            }
                        }
                        else if (objType == "Microsoft.Xrm.Sdk.Money")
                        {
                            lable = ((Money)objVal).Value.ToString("0.######");
                        }
                        else if (objType == "System.Decimal")
                        {
                            lable = ((Decimal)objVal).ToString("0.######");
                        }
                        else if (objType == "System.DateTime")
                        {
                            if (retEntity.FormattedValues.Contains(key))
                            {
                                var fValue = retEntity.FormattedValues[key];

                                if (fValue.Length > 10)
                                {
                                    lable = ((DateTime)objVal).ToLocalTime().ToString("yyyy/MM/dd HH:mm");
                                }
                                else
                                {
                                    lable = ((DateTime)objVal).ToLocalTime().ToString("yyyy/MM/dd");
                                }
                            }
                            else
                            {
                                lable = ((DateTime)objVal).ToLocalTime().ToString("yyyy/MM/dd HH:mm");
                            }
                        }
                        else
                        {
                            if (retEntity.FormattedValues.Contains(key))
                            {
                                lable = retEntity.FormattedValues[key];
                            }
                            else if (retEntity.Contains(key))
                            {
                                lable = objVal.ToString();
                            }
                        }
                    }

                    row.Append(MakeCsvField(lable));
                    row.Append(DELIMITER);

                    // オプション対応
                    if (fields[key].Contains("option"))
                    {
                        row.Append(MakeCsvField(value));
                        row.Append(DELIMITER);
                    }
                    else if (fields[key].Contains("user"))
                    {
                        if (fields[key].Contains("insider") && insider)
                        {
                            value = "■■■■■■■■";
                        }
                        else if (retEntity.Contains(key))
                        {
                            var userEnt = (EntityReference)retEntity[key];

                            var relUser = users.Entities.Where(p => p.Id.Equals(userEnt.Id)).FirstOrDefault();

                            if (relUser.Contains("tsb_slt_bank_clerk_id"))
                            {
                                value = relUser["tsb_slt_bank_clerk_id"].ToString();
                            }
                        }

                        row.Append(MakeCsvField(value));
                        row.Append(DELIMITER);
                    }

                    if (fields[key].Contains("tenban"))
                    {
                        if (retEntity.Contains("account.tsb_slt_num_branch"))
                        {
                            value = ((AliasedValue)retEntity["account.tsb_slt_num_branch"]).Value.ToString();
                        }
                        else
                        {
                            value = "";
                        }

                        row.Append(MakeCsvField(value));
                        row.Append(DELIMITER);
                    }

                    if (fields[key].Contains("kokyakubango"))
                    {
                        if (retEntity.Contains("account.tsb_slt_num_customer"))
                        {
                            value = ((AliasedValue)retEntity["account.tsb_slt_num_customer"]).Value.ToString();
                        }
                        else
                        {
                            value = "";
                        }

                        row.Append(MakeCsvField(value));
                        row.Append(DELIMITER);
                    }
                }

                if (batchId != "JBS_BT_033")
                {
                    // データ抽出日時
                    row.Append(MakeCsvField(nowTime.Value.ToString("yyyy/MM/dd HH:mm")));
                    row.Append(DELIMITER);
                }

                // 最後のタブを削除
                var rowStr = row.ToString();
                rowStr = rowStr.Substring(0, rowStr.Length - 1);

                outData.Add(rowStr);

                // 成功件数
                successCount++;
            }

            // 行出力
            File.AppendAllLines(fileOutName, outData, Encoding.GetEncoding("Shift_JIS"));
        }
        #endregion
    }
}
