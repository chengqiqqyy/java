﻿SELECT 
 *
FROM 
[dbo].[mid_businessunit]
WHERE
[mid_newkey] IS NULL