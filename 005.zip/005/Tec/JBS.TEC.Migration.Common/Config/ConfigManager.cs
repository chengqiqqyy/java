﻿using NLog;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;

namespace JBS.TEC.Migration.Common.Config
{
    public class ConfigManager
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        public static NameValueCollection AppSettings { get; } = new NameValueCollection();
        public static NameValueCollection ConnectionStrings { get; } = new NameValueCollection();

        public static void Load(string[] args)
        {
            LoadLocalConfig();
            LoadArgumentsConfig(args);
        }
        public static void LoadLocalConfig()
        {
            _logger.Debug("バッチ構成ファイルをロードする");
            foreach (string key in ConfigurationManager.AppSettings)
            {
                AppSettings[key] = ConfigurationManager.AppSettings[key];
            }
            foreach (ConnectionStringSettings val in ConfigurationManager.ConnectionStrings)
            {
                ConnectionStrings[val.Name] = val.ConnectionString;
            }
        }
        public static void LoadArgumentsConfig(string[] args)
        {
            if (args?.Length == 0)
                return;

            _logger.Debug("バッチ引数をロードする");
            var dictionary = args.Select(a => a.Split(new[] { '=' }, 2))
                     .GroupBy(a => a[0], a => a.Length == 2 ? a[1] : null)
                     .ToDictionary(g => g.Key, g => g.FirstOrDefault());

            foreach(var val in dictionary)
            {
                AppSettings[val.Key] = val.Value;
            }
        }
    }
}
