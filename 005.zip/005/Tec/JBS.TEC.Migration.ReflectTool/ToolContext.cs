﻿using JBS.TEC.Migration.Common.Config;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool
{
    public class ToolContext
    {
        public string SqlServerConnectionString { get; set; }
        public string CDSConnectionString { get; set; }

        [ConfigMapping("schemafile")]
        [ConfigMapping("s")]
        public string SchemaFile { get; set; }

        [ConfigMapping("csvfile")]
        [ConfigMapping("f")]
        public string CsvFile { get; set; }

        [ConfigMapping("midtable")]
        [ConfigMapping("m")]
        public string MidTable { get; set; }

        [ConfigMapping("entityname")]
        [ConfigMapping("e")]
        public string EntityName{ get; set; }

        [ConfigMapping("batchsize")]
        [ConfigMapping("bs")]
        public int BatchSize { get; set; } = 100;

        [ConfigMapping("loadsql")]
        [ConfigMapping("ls")]
        public string LoadSql { get; set; }

        [ConfigMapping("loadcount")]
        [ConfigMapping("lc")]
        public int LoadCount { get; set; } = 10000;

        [ConfigMapping("covertSql")]
        [ConfigMapping("cs")]
        public string CovertSql { get; set; }

        /// <summary>
        /// ヘッダーあり：TRUE　ヘッダーなし：FALSE
        /// </summary>
        public bool IncludeHeaderRow { get; set; } = true;

        /// <summary>
        /// カンマ区切り：','
        /// </summary>
        public string Delimiter { get; set; } = ",";

        /// <summary>
        /// Quote付きあり：TRUE　Quote付きなし：FALSE
        /// </summary>
        public bool ShouldQuote { get; set; } = true;

        [ConfigMapping("encoding")]
        public string Encoding { get; set; } = "utf-8";

        [ConfigMapping("extractbasefolder")]
        public string ExtractBaseFolder { get; set; }

        [ConfigMapping("guidmappingfile")]
        [ConfigMapping("g")]
        public string GuidMappingFile { get; set; }

        /// <summary>
        /// 0:登録、1:更新、2:削除、3:関連付け、4:関連付け解除
        /// </summary>
        [ConfigMapping("mode")]
        public int Mode { get; set; } = 0;

        [ConfigMapping("includefields")]
        [ConfigMapping("in")]
        public string IncludeFields { get; set; }

        [ConfigMapping("excludefields")]
        [ConfigMapping("ex")]
        public string ExcludeFields { get; set; }

        [ConfigMapping("statuscodeadjust")]
        [ConfigMapping("sc")]
        public bool StatusCodeAdjust { get; set; } = true;

        [ConfigMapping("timeout")]
        public int CommandTimeOut { get; set; } = 1200;

        [ConfigMapping("istargetdata")]
        [ConfigMapping("td")]
        public bool IsTargetData { get; set; } = true;

        public int TotalCount { get; set; }
        public int ErrorCount { get; set; }
        public int SuccessCount { get; set; }
        public int WarningCount { get; set; }
        public int OtherCount { get; set; }
    }
}
