﻿update x
set x.dev_kind_main = 
case 
when y.dev_kind_main = 277670000 then 277670001
when y.dev_kind_main = 277670001 then 277670002
when y.dev_kind_main = 277670002 then 277670003
when y.dev_kind_main = 277670003 then 277670005
when y.dev_kind_main = 277670004 then 277670006
when y.dev_kind_main = 277670005 then 277670008
else null
end
from
mid_dev_repair x
inner join
(
    select
    a.mid_oldkey,
    b.dev_kind_main
    from
    mid_dev_repair a
    left join
    mid_dev_service_history b
    on a.dev_service_history_dev_repair = b.mid_oldkey
) y
on x.mid_oldkey = y.mid_oldkey