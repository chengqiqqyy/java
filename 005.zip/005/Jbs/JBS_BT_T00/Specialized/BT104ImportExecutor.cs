﻿using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Specialized
{
    public class BT104ImportExecutor : CSVImportExecutor
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public BT104ImportExecutor(CSVImportContext context) : base(context)
        {

        }

        // [所有者] 特殊処理
        protected override void SetOwner(CSVFieldData csvFieldData)
        {
            // 所有者設定要否の判断
            if (!_context.JBS_BT_T00_Config.SetOwner || csvFieldData.ColumnMapping.CrmColumn != "tsb_top_insider")
            {
                return;
            }

            // 処理エンティティ
            var opObj = csvFieldData.CSVRow.EntityData;
            // インサイダー等極秘情報
            var insiderFlag = false;

            if (opObj.GetAttributeValue<object>("tsb_top_insider") == null)
            {
                if (_context.JBS_BT_T00_Config.OwnerSkip)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    _logger.Debug($"所有者設定不可、インサイダー等極秘情報は設定していません。{csvFieldData.CSVRow.RowNum}行目");
                    return;
                }
                throw new Exception($"所有者設定不可、インサイダー等極秘情報は設定していません。{csvFieldData.CSVRow.RowNum}行目");
            }
            else
            {
                insiderFlag = opObj.GetAttributeValue<bool>("tsb_top_insider");
            }

            // インサイダーの場合
            if (insiderFlag)
            {
                // ユーザーキーファイル取得
                var keyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                var checkValue = csvFieldData.CSVRow.RowData["m_ownerid"];
                keyValues.Add("tsb_slt_bank_clerk_id", checkValue);
                // 検索
                var rows = keyFile.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    return;
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "systemuser", "ownerid", checkValue));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "systemuser", "ownerid", checkValue));
                }
                // 所有者設定
                opObj["ownerid"] = new EntityReference("systemuser", new Guid(rows[0]["guid"].ToString()));
            }
            // インサイダーでない場合
            else
            {
                // ユーザーキーファイル取得
                var keyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                // 該当組織階層検索
                var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_organization_structure");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                // 組織階層区分
                keyValues.Add("tsb_ops_type_organization", "100000004");
                // 組織コード
                keyValues.Add("tsb_slt_name_or_code", csvFieldData.CSVRow.RowData["m_ownerid"]);
                // 検索
                var rows = keyFileService.Query(keyValues);
                // 検索レコードは存在しない場合
                if (rows.Length < 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
                // 複数件がある場合
                if (rows.Length > 1)
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, "tsb_organization_structure", "ownerid", csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
                // ライン
                var lineid = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line"].ToString();

                if (!string.IsNullOrEmpty(lineid))
                {
                    // ラインの組織階層検索条件
                    keyValues.Clear();
                    keyValues.Add("guid", lineid);
                    // 検索
                    rows = keyFileService.Query(keyValues);
                    // ライン(所有者チーム)
                    var teamid = rows.FirstOrDefault() == null ? null : rows[0]["tsb_lup_line_team"].ToString();

                    if (!string.IsNullOrEmpty(teamid))
                    {
                        // 所有者設定
                        opObj["ownerid"] = new EntityReference("team", new Guid(teamid));
                    }
                    else
                    {
                        if (_context.JBS_BT_T00_Config.OwnerSkip)
                        {
                            // 特定システムユーザーセット
                            opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                            _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                            return;
                        }
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン(所有者チーム)", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                    }
                }
                else
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_022, "ライン", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_ownerid"]));
                }
            }
        }

        // [協働先] 特殊処理 (複数レコードの場合、第一件のレコードをセットする)
        // [DA番号] 特殊処理
        protected override EntityReference ParseLookupAttribute(CSVFieldData csvFieldData)
        {
            if(csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_partner" && csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_num_da")
            {
                return base.ParseLookupAttribute(csvFieldData);
            }

            var lMetadata = (LookupAttributeMetadata)csvFieldData.Metadata;

            CSVKeyFileService keyfile = null;
            var factory = CSVImportFactory.GetInstance();
            string lookupEntity = null;
            foreach (var entity in lMetadata.Targets)
            {
                keyfile = factory.GetCSVKeyFile(entity);
                if (keyfile != null)
                {
                    lookupEntity = entity;
                    if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
                    {
                        if (string.IsNullOrEmpty(csvFieldData.FieldValue))
                        {
                            return null;
                        }
                        else
                        {
                            return new EntityReference(lMetadata.Targets[0], new Guid(csvFieldData.FieldValue));
                        }
                    }
                    break;
                }
            }
            if (keyfile == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, string.Join(",", lMetadata.Targets)));
            }

            // CSVフィールド形式チェック
            var fieldInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            // キーリスト
            var keys = fieldInfo[0].Split(',');

            // フィールドリスト
            var fields = fieldInfo[1].Split(',');

            var outFields = "";
            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            // 検索条件設定
            for (var i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    return null;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    var temp = fields[i].StartsWith(CSVImportConsts.FIXEDVALUE) ? keys[i] : csvFieldData.CSVRow.DataName[fields[i]];
                    outFields = outFields + $"{temp}（{fields[i]}）";
                    outValue = outValue + checkValue;
                }
                else
                {
                    outFields = outFields + $",{csvFieldData.CSVRow.DataName[fields[i]]}（{fields[i]}）";
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyfile.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                if (csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_partner")
                {
                    return new EntityReference(lookupEntity, new Guid(rows[0][CSVImportConsts.GUID].ToString()));
                }
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                return new EntityReference(lookupEntity, new Guid(rows[0][CSVImportConsts.GUID].ToString()));
            }
            else
            {
                // [DA番号] 特殊処理 ダミーDA番号をセットする
                if (csvFieldData.ColumnMapping.CrmColumn == "tsb_lup_num_da")
                {
                    // 特定DA番号設定
                    return new EntityReference(lMetadata.Targets[0], new Guid(_context.JBS_BT_T00_Config.DamiDaNumId));
                }

                // コラムスキップ[True]の場合
                if (csvFieldData.ColumnMapping.CrmColumnSkip == "true")
                {
                    _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
                    return null;
                }
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
            }
        }

        // 国籍デフォルト値設定
        protected override void AdjustFieldValue(CSVFieldData csvFieldData)
        {
            if (csvFieldData.ColumnMapping.CrmColumn != "tsb_ops_nationality")
            {
                base.AdjustFieldValue(csvFieldData);
                return;
            }

            // フィールド値
            string fieldValue = null;

            // 検索項目取得
            var linkInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile(linkInfo[1]);
            if (keyFileService == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, linkInfo[1]));
            }

            // キーリスト
            var keys = linkInfo[3].Split(',');

            // フィールドリスト
            var fields = linkInfo[4].Split(',');

            var outFields = "";
            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();

            // 検索条件設定
            for (int i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    // デフォルト値　日本を設定
                    csvFieldData.FieldValue = "日本";
                    return;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    var temp = fields[i].StartsWith(CSVImportConsts.FIXEDVALUE) ? keys[i] : csvFieldData.CSVRow.DataName[fields[i]];
                    outFields = outFields + $"{temp}（{fields[i]}）";
                    outValue = outValue + checkValue;
                }
                else
                {
                    outFields = outFields + $",{csvFieldData.CSVRow.DataName[fields[i]]}（{fields[i]}）";
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyFileService.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013,
                    csvFieldData.CSVRow.RowNum, linkInfo[1], outFields, outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                fieldValue = rows[0][linkInfo[2]].ToString();

                // 入力値がない場合
                if (string.IsNullOrEmpty(fieldValue))
                {
                    // デフォルト値　日本を設定
                    csvFieldData.FieldValue = "日本";
                }
                else
                {
                    csvFieldData.FieldValue = fieldValue;
                }
            }
            else
            {
                // デフォルト値　日本を設定
                csvFieldData.FieldValue = "日本";
            }
        }

        // 自己参照
        protected override void UpsertEntity(List<(CSVRowData CSVData, Entity EntityData)> batchEntities)
        {
            if (!_context.JBS_BT_T00_Config.SelfLookup)
            {
                base.UpsertEntity(batchEntities);
                return;
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            var updList = new List<(CSVRowData CSVData, Entity EntityData)>();

            foreach (var itemData in batchEntities)
            {
                if (itemData.EntityData.Id != Guid.Empty)
                {
                    // 「関連案件番号」はブランクの場合
                    if (string.IsNullOrEmpty(itemData.CSVData.RowData["m_tsb_lup_num_relation_project"]))
                    {
                        itemData.CSVData.IsSuccess = true;
                        continue;
                    }

                    updList.Add((itemData.CSVData, itemData.EntityData));

                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
                else
                {
                    itemData.CSVData.IsSuccess = true;
                }
            }

            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = updList[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                }
            }
        }
    }
}
