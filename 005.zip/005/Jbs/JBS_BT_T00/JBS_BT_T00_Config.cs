﻿using Microsoft.Xrm.Sdk.Metadata;
using System.Collections.Generic;
using System.Text;

namespace JBS_BT_T00
{
    /// <summary>
    /// 設定情報
    /// </summary>
    public class JBS_BT_T00_Config
    {
        // 入力ファイルのパス
        public string InputFilePath { get; set; }

        // オプションセットマッピングファイル名
        public string MappingFile { get; set; }

        // バックアップフォルダ
        public string BackupPath { get; set; }

        // エラーファイルフォルダ
        public string ErrorPath { get; set; }

        // ファイルの文字コード
        public Encoding FileEncode { get; set; }

        // タイトルあり
        public bool HaveTitle { get; set; }

        // キーファイルのパス
        public string KeyFilePath { get; set; }

        // キーファイル対象リスト
        public List<string> KeyFiles { get; set; }

        // ヘッダー
        public List<CsvHeader> Headers { get; set; }

        // キーファイル情報
        public Dictionary<string, List<Dictionary<string, string>>> KeyFileInfos { get; set; }

        // キーファイルタイトル情報
        public Dictionary<string, List<string>> KeyFileTitleInfos { get; set; }

        // 対象エンティティ名
        public string LogicName { get; set; }

        // 一括削除要否
        public string NeedDelete { get; set; }

        // 不足データ非アクティブ要否
        public bool NeedInactive { get; set; }

        // 所有者設定要否
        public bool SetOwner { get; set; }

        // キー情報リスト
        public List<Mapping> Keys { get; set; }

        // フィールド情報リスト
        public List<Mapping> Fields { get; set; }

        // 全フィールド情報リスト
        public List<Mapping> AllFields { get; set; }

        // メタデータ
        public List<AttributeMetadata> AttributeMetadatas { get; set; }

        // 特定DA番号
        public string SpecificDaNum { get; set; }

        // ダミーDA番号ID
        public string DamiDaNumId { get; set; }

        // 特定システムユーザー
        public string SpecificUser { get; set; }

        // 特定システムユーザーID
        public string StubUserId { get; set; }

        // 見つからないユーザー変わりフラグ
        public bool MissUserChange { get; set; }

        // サービス通信フラグ
        public bool DoService { get; set; }

        // 自己参照フラグ
        public bool SelfLookup { get; set; }

        // 所有者スキップフラグ
        public bool OwnerSkip { get; set; }
    }

    #region Mappingクラス
    /// <summary>
    /// Mappingクラス
    /// </summary>
    public class Mapping
    {
        // CRMフィールド
        public string CrmColumn { get; set; }

        // CRMフィールド チェック用
        public string CrmColumnForCheck { get; set; }

        // CRMフィールドメータデータ
        public AttributeMetadata CrmColumnMetadata { get; set; }

        // CSVフィールド
        public string CsvColumn { get; set; }
        
        //オプションセットマッピング定義用
        public string CrmOptionSetMapping { get; set; }

        // コラムスキップフラグ
        public string CrmColumnSkip { get; set; }
    }
    #endregion

    public class CsvHeader
    {
        public string LogicName { get; set; }
        public string DisplayName { get; set; }
    }

    public enum EntityActionType
    {
        Create,
        Update,
        Delete
    }
}
