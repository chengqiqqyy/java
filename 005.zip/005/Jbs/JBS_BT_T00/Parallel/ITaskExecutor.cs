﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Parallel
{
    public interface ITaskExecutor<TData> where TData : class
    {
        IList<TaskResult<TData>> Execute(IList<TData> datas);
    }
}
