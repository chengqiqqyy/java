﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVRowData
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public EntityActionType ActionType { set; get; }
        public IDictionary<string,string> DataName { set; get; }
        public int RowNum { get; set; }
        public string RawRowData { get; set; }
        public IDictionary<string, string> RowData { get; set; }
        public IDictionary<string, string> OriginRowData { get; set; }
        public Entity EntityData { get; set; }
        public CSVImportContext Context { get; set; }
    }
}
