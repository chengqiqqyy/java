﻿SELECT 
 *
FROM 
[dbo].[mid_dev_sevice_history_detail]