SELECT 
 *
FROM 
[dbo].[mid_dev_campaign_master]