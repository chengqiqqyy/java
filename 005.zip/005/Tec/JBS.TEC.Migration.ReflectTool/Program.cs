﻿using NLog;
using System;

namespace JBS.TEC.Migration.ReflectTool
{
    class Program
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            try
            {
                _logger.Info("反映ツールが開始しました");

                var tool = new ReflectTool();
                tool.Execute(args);

                Environment.Exit(1);
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                Environment.Exit(-1);
            }
        }
        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                _logger.Error(e);
            }
            finally
            {

            }
            Console.WriteLine(e.ToString());
            Environment.Exit(-2);
        }
    }
}
