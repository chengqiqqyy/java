﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool
{
    public class ToolHelper
    {
        public static bool IsPathFullyQualified(string path)
        {
            var root = Path.GetPathRoot(path);
            return root.StartsWith(@"\\") || root.EndsWith(@"\");
        }

        /// <summary>
        /// 実行フォルダ取得
        /// </summary>
        /// <returns></returns>
        public static string GetExecutingFolder()
        {
            return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }

        /// <summary>
        /// パースチェック、存在しない場合作成する
        /// </summary>
        /// <param name="filePath"></param>
        public static void CheckAndCreateFolder(string filePath)
        {
            var parentFolder = Path.GetDirectoryName(filePath);
            if (!Directory.Exists(parentFolder))
            {
                Directory.CreateDirectory(parentFolder);
            }
        }
    }
}
