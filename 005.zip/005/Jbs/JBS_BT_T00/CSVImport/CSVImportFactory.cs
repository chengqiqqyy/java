﻿using JBS_BT_T00.EntityService;
using JBS_BT_T00.Specialized;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVImportFactory
    {
        private static CSVImportFactory _singletonInstance = null;

        protected CSVImportContext _context;
        public CSVImportContext Context { get { return _context; } set { _context = value; } }

        protected List<CSVKeyFileService> _lstCSVKeyFile = new List<CSVKeyFileService>();
        protected CSVOptionSetService _optionSetService;

        private CSVImportFactory()
        {

        }
        public void Initilize()
        {
            InitKeyFile();
            InitOptionSetMapping();
        }
        public static CSVImportFactory GetInstance()
        {
            if (_singletonInstance == null)
            {
                _singletonInstance = new CSVImportFactory();
            }
            return _singletonInstance;
        }
        public void InitKeyFile()
        {
            foreach (var keyFile in _context.JBS_BT_T00_Config.KeyFiles)
            {
                var keyFileService = new CSVKeyFileService(_context, keyFile);
                _lstCSVKeyFile.Add(keyFileService);
            }
            // キーファイル対象リストに存在チェック
            if (!_context.JBS_BT_T00_Config.KeyFiles.Contains(_context.JBS_BT_T00_Config.LogicName) && _context.JBS_BT_T00_Config.Keys.Count > 0)
            {
                // キーがある場合、キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, _context.JBS_BT_T00_Config.LogicName));
            }
        }
        public void InitOptionSetMapping()
        {
            _optionSetService = new CSVOptionSetService(_context);
        }

        public CSVKeyFileService GetCSVKeyFile(string keyFileName)
        {
            return _lstCSVKeyFile.Where(r => r.KeyFileName == keyFileName).FirstOrDefault();
        }
        public CSVOptionSetService GetOptionSetMapping()
        {
            return _optionSetService;
        }
        public CSVImportService GetCSVImportService()
        {
            return new CSVImportService(_context);
        }
        public CSVImportExecutor GetCSVImportExecutor()
        {
            switch (_context.BatchId)
            {
                case "JBS-BT-101":
                    return new BT101ImportExecutor(_context);
                case "JBS-BT-102":
                    return new BT102ImportExecutor(_context);
                case "JBS-BT-103":
                    return new BT103ImportExecutor(_context);
                case "JBS-BT-104":
                    return new BT104ImportExecutor(_context);
                case "JBS-BT-104up":
                    return new BT104ImportExecutor(_context);
                case "JBS-BT-105":
                    return new BT105ImportExecutor(_context);
                case "JBS-BT-105up":
                    return new BT105ImportExecutor(_context);
                case "JBS-BT-106":
                    return new BT106ImportExecutor(_context);
                case "JBS-BT-106up":
                case "JBS-BT-106up2":
                    return new BT106ImportExecutor(_context);
                case "JBS-BT-107":
                case "JBS-BT-107up2":
                    return new BT107ImportExecutor(_context);
                case "JBS-BT-108":
                    return new BT108ImportExecutor(_context);
                case "JBS-BT-108up":
                case "JBS-BT-108up2":
                    return new BT108ImportExecutor(_context);
                case "JBS-BT-109":
                case "JBS-BT-109up2":
                    return new BT109ImportExecutor(_context);
                default:
                    return new CSVImportExecutor(_context);
            }
        }
        public EntityDataService GetEntityDataService()
        {
            return new EntityDataService();
        }
    }
}
