SELECT 
 *
FROM 
[dbo].[mid_dev_hasub_service_master]