﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.TEC.Migration.ReflectTool.BarcodeTransform
{
    class Code128Content
    {
        private List<int> mCodeList;
        public List<int> Codes { get { return mCodeList; } }

        public Code128Content(string asciiData)
        {
            mCodeList = StringToCode128(asciiData);
        }

        public List<int> StringToCode128(string asciiData)
        {
            CodeSetAllowed csa1;
            CodeSetAllowed csa2;
            var code128Code = new Code128Code();

            // パラメータの文字列をASCIIコードの配列に変換
            var asciiBytes = Encoding.ASCII.GetBytes(asciiData);

            // コードセットを判定
            if (asciiBytes.Length == 1)
            {
                csa1 = code128Code.CodesetAllowedForChar(asciiBytes[0]);
                csa2 = CodeSetAllowed.CodeAorB;
            }
            else if (asciiBytes.Length > 1)
            {
                csa1 = code128Code.CodesetAllowedForChar(asciiBytes[0]);
                csa2 = code128Code.CodesetAllowedForChar(asciiBytes[1]);
            }
            else
            {
                csa1 = CodeSetAllowed.CodeAorB;
                csa2 = CodeSetAllowed.CodeAorB;
            }

            var currentCodeSet = GetBestStartSet(csa1, csa2);

            // コードデータ格納用List
            var codes = new List<int>();

            // コードデータにスタートコードをADD
            codes.Add(code128Code.StartCodeForCodeSet(currentCodeSet));

            // ASCIIコードの配列でループし、コードデータをADD
            for (int i = 0; i < asciiBytes.Length; i++)
            {
                var thischar = asciiBytes[i];
                var nextchar = -1;

                if (asciiBytes.Length > i + 1)
                {
                    nextchar = asciiBytes[i + 1];
                }

                codes.AddRange(code128Code.CodesForChar(thischar, nextchar, currentCodeSet));
            }

            // チェックディジット（モジュラス103）を算出しコードデータにADD
            var checksum = codes[0];
            for (int i = 1; i < codes.Count; i++)
            {
                checksum += i * (int)codes[i];
            }
            codes.Add(checksum % 103);

            // コードデータにストップコードをADD
            codes.Add(code128Code.StopCode());

            return codes;
        }

        private CodeSet GetBestStartSet(CodeSetAllowed csa1, CodeSetAllowed csa2)
        {
            var vote = 0;

            if (csa1 == CodeSetAllowed.CodeA)
            {
                vote += 1;
            }
            else if (csa1 == CodeSetAllowed.CodeB)
            {
                vote += -1;
            }

            if (csa2 == CodeSetAllowed.CodeA)
            {
                vote += 1;
            }
            else if (csa2 == CodeSetAllowed.CodeB)
            {
                vote += -1;
            }

            if (vote > 0)
            {
                return CodeSet.CodeA;
            }
            else
            {
                return CodeSet.CodeB;
            }
        }
    }
}
