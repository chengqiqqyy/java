﻿using BatchCommon.Helper;
using BatchCommon;
using JBS_BT_T00.Parallel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Activities.Expressions;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using BatchCommon.Log;

namespace JBS_BT_T00.CSVImport
{
    public class CSVImportExecutor : ITaskExecutor<CSVRowData>
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        protected IOrganizationService _crmService;
        public IOrganizationService CrmService { get { return _crmService; } set { _crmService = value; } }

        protected CSVImportContext _context;
        protected CSVOptionSetService _optionsetMapping;

        public CSVImportExecutor(CSVImportContext context)
        {
            _context = context;
            _optionsetMapping = CSVImportFactory.GetInstance().GetOptionSetMapping();
        }

        public IList<TaskResult<CSVRowData>> Execute(IList<CSVRowData> csvRows)
        {
            try
            {
                return OnExecute(csvRows);
            }
            catch(Exception ex)
            {
                _logger.Error(ex);
                //処理を続行する

                var taskResults = new List<TaskResult<CSVRowData>>();
                foreach (var csvRow in csvRows)
                {
                    var taskResult = new TaskResult<CSVRowData>() { TaskData = csvRow };
                    if (csvRow.IsSuccess)
                    {
                        taskResult.ResultType = TaskResultType.SUCCESS;
                    }
                    else
                    {
                        taskResult.ResultType = TaskResultType.ERROR;
                        if (csvRow.ErrorMessage == null)
                            csvRow.ErrorMessage = ex.ToString();
                    }
                    taskResults.Add(taskResult);
                }
                return taskResults;
            }
        }
        protected virtual IList<TaskResult<CSVRowData>> OnExecute(IList<CSVRowData> csvRows)
        {
            var batchEntities = new List<(CSVRowData CSVData, Entity EntityData)>();
            foreach (var csvRow in csvRows)
            {
                try
                {
                    if (PreProcessCSVItem(csvRow))
                    {
                        var entity = ProcessCSVItem(csvRow);
                        if (entity != null)
                        {
                            SetExistedGuid(csvRow);
                            batchEntities.Add((csvRow, entity));
                        }
                        PostProcessCSVItem(csvRow);
                    }
                }
                catch (Exception ex)
                {
                    csvRow.IsSuccess = false;
                    csvRow.ErrorMessage = ex.Message;
                }
            }

            //反映
            if (_context.JBS_BT_T00_Config.DoService)
            {
                UpsertEntity(batchEntities);
            }

            var taskResults = new List<TaskResult<CSVRowData>>();
            foreach (var csvRow in csvRows)
            {
                var taskResult = new TaskResult<CSVRowData>() { TaskData = csvRow };

                if (!_context.JBS_BT_T00_Config.DoService)
                {
                    if(csvRow.ErrorMessage == null)
                        taskResult.ResultType = TaskResultType.SUCCESS;
                    else
                        taskResult.ResultType = TaskResultType.ERROR;
                }
                else
                {
                    if (csvRow.IsSuccess && csvRow.ErrorMessage == null)
                        taskResult.ResultType = TaskResultType.SUCCESS;
                    else
                        taskResult.ResultType = TaskResultType.ERROR;
                }

                taskResults.Add(taskResult);
            }

            return taskResults;
        }


        #region 行データ解析
        protected virtual Entity ProcessCSVItem(CSVRowData csvRow)
        {
            // 処理対象
            var opObj = new Entity(_context.JBS_BT_T00_Config.LogicName);
            csvRow.EntityData = opObj;

            foreach (var mapping in _context.JBS_BT_T00_Config.AllFields)
            {
                if (opObj.Contains(mapping.CrmColumn) && opObj[mapping.CrmColumn] != null 
                    && !string.IsNullOrEmpty(opObj[mapping.CrmColumn].ToString()))
                {
                    continue;
                }

                var fieldData = new CSVFieldData()
                {
                    CSVRow = csvRow,
                    ColumnMapping = mapping,
                    Metadata = mapping.CrmColumnMetadata
                };

                if (PreParseCSVFieldData(fieldData))
                {
                    var parsedValue = ParseCSVFieldData(fieldData);
                    opObj[mapping.CrmColumn] = parsedValue;

                    // 必須チェック
                    if (mapping.CrmColumnForCheck.StartsWith(CSVImportConsts.REQUIRED)
                        && (opObj[mapping.CrmColumn] == null
                        || string.IsNullOrEmpty(opObj[mapping.CrmColumn].ToString())))
                    {
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_004, csvRow.RowNum, mapping.CsvColumn));
                    }

                    PostParseCSVFieldData(fieldData);
                }
            }
            return opObj;
        }
        /// <summary>
        /// 行データ解析前処理
        /// </summary>
        /// <param name="csvRow"></param>
        /// <returns>true:続行可能、false:続行不可</returns>
        protected virtual bool PreProcessCSVItem(CSVRowData csvRow)
        {
            ProcessOptionSetMapping(csvRow);
            return true;
        }
        /// <summary>
        /// 行データ解析後処理
        /// </summary>
        /// <param name="csvRow"></param>
        /// <returns></returns>
        protected virtual void PostProcessCSVItem(CSVRowData csvRow)
        {

        }
        /// <summary>
        /// 登録更新区分を
        /// </summary>
        protected virtual void SetExistedGuid(CSVRowData csvRow)
        {
            //キー列が定義されていない場合、全部新規登録とする
            if (csvRow.Context.JBS_BT_T00_Config.Keys.Count == 0)
                return;

            // キー情報
            var factory = CSVImportFactory.GetInstance();
            var keyfile = factory.GetCSVKeyFile(csvRow.Context.JBS_BT_T00_Config.LogicName);
            if (keyfile == null)
                return;//キーファイル存在しない場合、全部新規登録とする

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            var outKey = "";
            var outValues = "";

            // 検索条件設定
            for (var j = 0; j < csvRow.Context.JBS_BT_T00_Config.Keys.Count; j++)
            {
                var checkKey = csvRow.Context.JBS_BT_T00_Config.Keys[j].CrmColumn;
                var checkVal = EntityHelper.GetFieldValue(csvRow.EntityData, csvRow.Context.JBS_BT_T00_Config.Keys[j].CrmColumn);

                if(j == 0)
                {
                    outKey = checkKey;
                    outValues = checkVal;
                }
                else
                {
                    outKey += $",{checkKey}";
                    outValues += $",{checkVal}";
                }

                keyValues.Add(checkKey, checkVal);
            }
            // 検索
            var rows = keyfile.Query(keyValues);

            //複数件
            if (rows?.Length > 1)
            {
                throw new Exception($"キーファイル中に複数のレコードが存在する。{csvRow.RowNum}行目、キーフィールド「{outKey}」、検索値「{outValues}」");
            }

            if(rows?.Length == 1)
            {
                csvRow.EntityData.Id = new Guid(rows[0][CSVImportConsts.GUID].ToString());
                csvRow.ActionType = EntityActionType.Update;
            }
        }
        #endregion

        #region 項目解析
        /// <summary>
        /// 項目解析処理
        /// </summary>
        /// <param name="csvFieldData"></param>
        /// <returns></returns>
        protected virtual object ParseCSVFieldData(CSVFieldData csvFieldData)
        {

            AdjustFieldValue(csvFieldData);

            // 検索フィールド以外値がない場合
            if (csvFieldData.FieldValue == "") return null;

            switch (csvFieldData.Metadata.AttributeType)
            {
                case AttributeTypeCode.String:
                    return ParseStringAttribute(csvFieldData);
                case AttributeTypeCode.Memo:
                    return ParseMemoAttribute(csvFieldData);
                case AttributeTypeCode.Integer:
                    return ParseIntegerAttribute(csvFieldData);
                case AttributeTypeCode.BigInt:
                    return ParseBigIntAttribute(csvFieldData);
                case AttributeTypeCode.Double:
                    return ParseDoubleAttribute(csvFieldData);
                case AttributeTypeCode.Decimal:
                    return ParseDecimalAttribute(csvFieldData);
                case AttributeTypeCode.Money:
                    return ParseMoneyAttribute(csvFieldData);
                case AttributeTypeCode.Boolean:
                    return ParseBooleanAttribute(csvFieldData);
                case AttributeTypeCode.State:
                    return ParseStateCodeAttribute(csvFieldData);
                case AttributeTypeCode.Status:
                    return ParseStatusCodeAttribute(csvFieldData);
                case AttributeTypeCode.Picklist:
                    return ParseOptionSetAttribute(csvFieldData);
                case AttributeTypeCode.Owner:
                    return ParseOwnerAttribute(csvFieldData);
                case AttributeTypeCode.Lookup:
                case AttributeTypeCode.Customer:
                    return ParseLookupAttribute(csvFieldData);
                case AttributeTypeCode.DateTime:
                    return ParseDateTimeAttribute(csvFieldData);
                default:
                    throw new NotSupportedException("not support attribute type:" + csvFieldData.Metadata.AttributeTypeName);
            }
        }
        /// <summary>
        /// 項目解析前処理
        /// </summary>
        /// <param name="csvFieldData"></param>
        /// <returns>true:続行可能、false:続行不可</returns>
        protected virtual bool PreParseCSVFieldData(CSVFieldData csvFieldData)
        {
            return !SetStatecode(csvFieldData);
        }
        /// <summary>
        /// 項目解析後処理
        /// </summary>
        /// <param name="csvFieldData"></param>
        protected virtual void PostParseCSVFieldData(CSVFieldData csvFieldData)
        {
            SetOwner(csvFieldData);
        }
        #endregion

        #region 特別変換処理
        protected virtual void AdjustFieldValue(CSVFieldData csvFieldData)
        {
            // フィールド値
            string fieldValue = null;
            // 検索フィールド、リンク項目以外場合
            if (!csvFieldData.ColumnMapping.CsvColumn.Contains(";"))
            {
                // 固定値対応
                if (csvFieldData.ColumnMapping.CsvColumn.StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    csvFieldData.FieldValue = csvFieldData.ColumnMapping.CsvColumn.Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    csvFieldData.FieldValue = csvFieldData.CSVRow.RowData[csvFieldData.ColumnMapping.CsvColumn];
                }
            }
            else if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
            {
                // 検索項目にある項目取得
                var linkInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

                var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile(linkInfo[1]);
                if (keyFileService == null)
                {
                    // キーファイルは必須とする
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, linkInfo[1]));
                }

                // キーリスト
                var keys = linkInfo[3].Split(',');

                // フィールドリスト
                var fields = linkInfo[4].Split(',');

                var outFields = "";
                var outValue = "";

                // 検索条件
                var keyValues = new Dictionary<string, string>();

                // 検索条件設定
                for (int i = 0; i < keys.Length; i++)
                {
                    var checkKey = keys[i];

                    var checkValue = "";

                    // 固定値対応
                    if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                    {
                        checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                    }
                    else
                    {
                        checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                    }

                    // 入力値がない場合
                    if (string.IsNullOrEmpty(checkValue))
                    {
                        csvFieldData.FieldValue = "";
                        return;
                    }

                    keyValues.Add(checkKey, checkValue);

                    // ログ出力用情報
                    if (i == 0)
                    {
                        var temp = fields[i].StartsWith(CSVImportConsts.FIXEDVALUE) ? keys[i] : csvFieldData.CSVRow.DataName[fields[i]];
                        outFields = outFields + $"{temp}（{fields[i]}）";
                        outValue = outValue + checkValue;
                    }
                    else
                    {
                        outFields = outFields + $",{csvFieldData.CSVRow.DataName[fields[i]]}（{fields[i]}）";
                        outValue = outValue + "," + checkValue;
                    }
                }

                // 検索
                var rows = keyFileService.Query(keyValues);

                // 複数件がある場合
                if (rows.Length > 1)
                {
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013, csvFieldData.CSVRow.RowNum, linkInfo[1], outFields, outValue));
                }

                // 一件のみの場合
                if (rows.Length == 1)
                {
                    // 項目リンク判定
                    string[] fieldInfo = null;
                    if (linkInfo[2].StartsWith("[LINK]"))
                    {
                        fieldInfo = linkInfo[2].Split('@');

                        fieldValue = rows[0][fieldInfo[1]].ToString();

                        // 入力値がない場合
                        if (string.IsNullOrEmpty(fieldValue))
                        {
                            csvFieldData.FieldValue = "";
                            return;
                        }

                        var keyFileService2 = CSVImportFactory.GetInstance().GetCSVKeyFile(fieldInfo[2]);
                        if (keyFileService2 == null)
                        {
                            // キーファイルは必須とする
                            throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, fieldInfo[2]));
                        }

                        // 検索条件
                        keyValues = new Dictionary<string, string>();
                        keyValues.Add(CSVImportConsts.GUID, fieldValue);

                        // 検索
                        rows = keyFileService2.Query(keyValues);

                        if (rows.Length == 0)
                        {
                            csvFieldData.FieldValue = "";
                            return;
                        }

                        fieldValue = rows[0][fieldInfo[3]].ToString();
                    }
                    else
                    {
                        fieldValue = rows[0][linkInfo[2]].ToString();
                    }

                    if (string.IsNullOrEmpty(fieldValue))
                    {
                        if(csvFieldData.Metadata.AttributeType != AttributeTypeCode.Lookup)
                        {
                            csvFieldData.FieldValue = "";
                        }
                        return;
                    }

                    csvFieldData.FieldValue = fieldValue;
                }
                else
                {
                    // コラムスキップ[True]の場合
                    if(csvFieldData.ColumnMapping.CrmColumnSkip == "true")
                    {
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019,csvFieldData.CSVRow.RowNum, linkInfo[1], outFields, outValue));
                        csvFieldData.FieldValue = "";
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019,csvFieldData.CSVRow.RowNum, linkInfo[1], outFields, outValue));
                }
            }
        }
        /// <summary>
        /// オプションセットマッピング
        /// </summary>
        /// <param name="csvRow"></param>
        protected virtual void ProcessOptionSetMapping(CSVRowData csvRow)
        {
            foreach (var mapping in _context.JBS_BT_T00_Config.AllFields)
            {
                if (!string.IsNullOrWhiteSpace(mapping.CrmOptionSetMapping))
                {
                    if (csvRow.RowData[mapping.CsvColumn] == "") continue;
                    var optionSetMapping = _optionsetMapping.GetOptionSetMapping(mapping.CrmOptionSetMapping);
                    if (optionSetMapping == null)
                    {
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_017, mapping.CrmOptionSetMapping));
                    }
                    if (!optionSetMapping.ContainsKey(csvRow.RowData[mapping.CsvColumn]))
                    {
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_018, mapping.CrmOptionSetMapping, csvRow.DataName[mapping.CsvColumn], mapping.CsvColumn, csvRow.RowData[mapping.CsvColumn]));
                    }
                    csvRow.RowData[mapping.CsvColumn] = optionSetMapping[csvRow.RowData[mapping.CsvColumn]] == "null" ? "" : optionSetMapping[csvRow.RowData[mapping.CsvColumn]];
                }
            }
        }
        protected virtual bool SetStatecode(CSVFieldData csvFieldData)
        {
            // 状態変更の場合(ステータス対応)
            if ("statecode" == csvFieldData.ColumnMapping.CrmColumn && csvFieldData.ColumnMapping.CsvColumn.Contains("@"))
            {
                // 変更情報
                var updInfo = csvFieldData.ColumnMapping.CsvColumn.Split('@');

                // 状態情報
                var stateInfo = updInfo[1].Split(';');

                // NULLチェック
                var stateCode = csvFieldData.FieldValue;
                if (!string.IsNullOrEmpty(stateCode))
                {
                    foreach (string info in stateInfo)
                    {
                        var stateMap = info.Split('=');

                        if (stateCode == stateMap[0])
                        {
                            string state = stateMap[1].Split(',')[0];
                            string status = stateMap[1].Split(',')[1];

                            csvFieldData.CSVRow.EntityData["statecode"] = new OptionSetValue(int.Parse(state));
                            csvFieldData.CSVRow.EntityData["statuscode"] = new OptionSetValue(int.Parse(status));
                        }
                    }
                }
                return true;
            }
            return false;
        }
        protected virtual void SetOwner(CSVFieldData csvFieldData)
        {
            var opObj = csvFieldData.CSVRow.EntityData;
            // 所有者設定要の場合
            if (_context.JBS_BT_T00_Config.SetOwner)
            {
                // 担当者コード
                if (csvFieldData.ColumnMapping.CrmColumn == "tsb_lup_code_responsible"
                    && opObj.GetAttributeValue<object>(csvFieldData.ColumnMapping.CrmColumn) != null)
                {
                    // 担当者コードのGUID
                    var responsibleid = ((EntityReference)opObj[csvFieldData.ColumnMapping.CrmColumn]).Id.ToString();

                    // 該当組織階層検索
                    var keyFileService = CSVImportFactory.GetInstance().GetCSVKeyFile("tsb_organization_structure");

                    // 検索条件
                    var keyValues = new Dictionary<string, string>();
                    keyValues.Add("guid", responsibleid);

                    // 検索
                    var rows = keyFileService.Query(keyValues);

                    // ライン
                    var lineid = rows[0]["tsb_lup_line"].ToString();

                    if (!string.IsNullOrEmpty(lineid))
                    {
                        // ラインの組織階層検索
                        keyValues = new Dictionary<string, string>();
                        keyValues.Add("guid", lineid);

                        // 検索
                        rows = keyFileService.Query(keyValues);

                        // ライン(所有者チーム)
                        var teamid = rows[0]["tsb_lup_line_team"].ToString();

                        if (!string.IsNullOrEmpty(teamid))
                        {
                            // 所有者設定
                            opObj["ownerid"] = new EntityReference("team", new Guid(teamid));
                        }
                    }
                }
            }
        }
        #endregion

        #region 項目タイプ変換処理
        protected virtual string ParseStringAttribute(CSVFieldData csvFieldData)
        {
            var sMetadata = (StringAttributeMetadata)csvFieldData.Metadata;

            // 最大長チェック
            if (csvFieldData.FieldValue.Length > sMetadata.MaxLength)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_005, 
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, sMetadata.MaxLength, csvFieldData.FieldValue.Length, csvFieldData.FieldValue));
            }

            return csvFieldData.FieldValue;
        }
        protected virtual string ParseMemoAttribute(CSVFieldData csvFieldData)
        {
            var memoMetadata = (MemoAttributeMetadata)csvFieldData.Metadata;

            // 最大長チェック
            if (csvFieldData.FieldValue.Length > memoMetadata.MaxLength)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_005,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, memoMetadata.MaxLength, csvFieldData.FieldValue.Length, csvFieldData.FieldValue));
            }

            return csvFieldData.FieldValue;
        }
        protected virtual int ParseIntegerAttribute(CSVFieldData csvFieldData)
        {
            var intParseValue = 0;

            // 整数チェック
            if (!int.TryParse(csvFieldData.FieldValue, out intParseValue))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_006,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
            }

            var iMetadata = (IntegerAttributeMetadata)csvFieldData.Metadata;

            // 最小値チェック
            if (intParseValue < iMetadata.MinValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_007,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, iMetadata.MinValue, intParseValue));
            }

            // 最大値チェック
            if (intParseValue > iMetadata.MaxValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_008,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, iMetadata.MaxValue, intParseValue));
            }

            return intParseValue;
        }
        protected virtual BigInteger ParseBigIntAttribute(CSVFieldData csvFieldData)
        {
            BigInteger bigIntParseValue = 0;

            // 整数チェック
            if (!BigInteger.TryParse(csvFieldData.FieldValue, out bigIntParseValue))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_006,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
            }

            var biMetadata = (BigIntAttributeMetadata)csvFieldData.Metadata;

            // 最小値チェック
            if (bigIntParseValue < biMetadata.MinValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_007,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, biMetadata.MinValue, bigIntParseValue));
            }

            // 最大値チェック
            if (bigIntParseValue > biMetadata.MaxValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_008,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, biMetadata.MaxValue, bigIntParseValue));
            }

            return bigIntParseValue;
        }
        protected virtual double ParseDoubleAttribute(CSVFieldData csvFieldData)
        {
            double doubleParseValue = 0;

            // Doubleチェック
            if (!double.TryParse(csvFieldData.FieldValue, out doubleParseValue))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_009,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
            }

            var dMetadata = (DoubleAttributeMetadata)csvFieldData.Metadata;

            // 最小値チェック
            if (doubleParseValue < dMetadata.MinValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_007,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, dMetadata.MinValue, doubleParseValue));
            }

            // 最大値チェック
            if (doubleParseValue > dMetadata.MaxValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_008,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, dMetadata.MaxValue, doubleParseValue));
            }

            return doubleParseValue;
        }
        protected virtual decimal ParseDecimalAttribute(CSVFieldData csvFieldData)
        {
            decimal decimalParseValue = 0;

            // Decimalチェック
            if (!decimal.TryParse(csvFieldData.FieldValue, out decimalParseValue))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_009,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
            }

            var deMetadata = (DecimalAttributeMetadata)csvFieldData.Metadata;

            // 最小値チェック
            if (decimalParseValue < deMetadata.MinValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_007,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, deMetadata.MinValue, decimalParseValue));
            }

            // 最大値チェック
            if (decimalParseValue > deMetadata.MaxValue)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_008,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, deMetadata.MaxValue, decimalParseValue));
            }

            return decimalParseValue;
        }
        protected virtual Money ParseMoneyAttribute(CSVFieldData csvFieldData)
        {
            double moneyParseValue = 0;

            // 金額チェック
            if (!double.TryParse(csvFieldData.FieldValue, out moneyParseValue))
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_009,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
            }

            var mMetadata = (MoneyAttributeMetadata)csvFieldData.Metadata;

            // 最小値チェック
            if (moneyParseValue < mMetadata.MinValue.Value)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_007,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, mMetadata.MinValue.Value, moneyParseValue));
            }

            // 最大値チェック
            if (moneyParseValue > mMetadata.MaxValue.Value)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_008,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, mMetadata.MaxValue.Value, moneyParseValue));
            }

            return new Money(new decimal(moneyParseValue));
        }
        protected virtual bool ParseBooleanAttribute(CSVFieldData csvFieldData)
        {
            // 選択肢チェック
            var bMetadata = (BooleanAttributeMetadata)csvFieldData.Metadata;

            if (csvFieldData.FieldValue == bMetadata.OptionSet.TrueOption.Label.UserLocalizedLabel.Label
                || csvFieldData.FieldValue == bMetadata.OptionSet.TrueOption.Value.ToString())
            {
                return true;
            }
            else if (csvFieldData.FieldValue == bMetadata.OptionSet.FalseOption.Label.UserLocalizedLabel.Label
                || csvFieldData.FieldValue == bMetadata.OptionSet.FalseOption.Value.ToString())
            {
                return false;
            }
            else
            {
                string boolOptions = bMetadata.OptionSet.TrueOption.Value.ToString()
                    + "," + bMetadata.OptionSet.FalseOption.Value.ToString();

                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_010,
                     csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, boolOptions, csvFieldData.FieldValue));
            }
        }
        protected virtual OptionSetValue ParseStateCodeAttribute(CSVFieldData csvFieldData)
        {
            if (csvFieldData.ColumnMapping.CsvColumn.Contains("@"))
            {
                return null;
            }

            // 選択肢チェック
            var stateMetadata = (StateAttributeMetadata)csvFieldData.Metadata;

            string stateOptions = "";

            OptionSetValue stateOpValue = null;

            // 値判定
            foreach (var option in stateMetadata.OptionSet.Options)
            {
                if (string.IsNullOrEmpty(stateOptions))
                {
                    stateOptions = option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }
                else
                {
                    stateOptions = stateOptions + "," + option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }

                if (csvFieldData.FieldValue == option.Label.UserLocalizedLabel.Label || csvFieldData.FieldValue == option.Value.ToString())
                {
                    stateOpValue = new OptionSetValue(option.Value.Value);
                }
            }

            if (stateOpValue == null)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_010,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, stateOptions, csvFieldData.FieldValue));
            }
            else
            {
                return stateOpValue;
            }
        }
        protected virtual OptionSetValue ParseStatusCodeAttribute(CSVFieldData csvFieldData)
        {
            // 選択肢チェック
            var statusMetadata = (StatusAttributeMetadata)csvFieldData.Metadata;

            string statusOptions = "";

            OptionSetValue statusOpValue = null;

            // 値判定
            foreach (var option in statusMetadata.OptionSet.Options)
            {
                if (string.IsNullOrEmpty(statusOptions))
                {
                    statusOptions = option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }
                else
                {
                    statusOptions = statusOptions + "," + option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }

                if (csvFieldData.FieldValue == option.Label.UserLocalizedLabel.Label || csvFieldData.FieldValue == option.Value.ToString())
                {
                    statusOpValue = new OptionSetValue(option.Value.Value);
                }
            }

            if (statusOpValue == null)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_010,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, statusOptions, csvFieldData.FieldValue));
            }
            else
            {
                return statusOpValue;
            }
        }
        protected virtual OptionSetValue ParseOptionSetAttribute(CSVFieldData csvFieldData)
        {
            // 選択肢チェック
            var pMetadata = (PicklistAttributeMetadata)csvFieldData.Metadata;

            string options = "";

            OptionSetValue opValue = null;

            var fieldValue = csvFieldData.FieldValue;

            // 複数カラムで判定する場合
            if (csvFieldData.ColumnMapping.CsvColumn.Contains(";") && !csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
            {
                fieldValue = "";

                // CSVフィールド形式チェック
                var opColumns = csvFieldData.ColumnMapping.CsvColumn.Split(';');

                // 判定用値取得
                for (var i = 0; i < opColumns.Length; i++)
                {
                    var checkField = opColumns[i];

                    // カラム名と桁数
                    var checkFieldInfo = checkField.Split(',');

                    var val = "";

                    if (checkFieldInfo.Length > 1)
                    {
                        // カラム値
                        val = csvFieldData.CSVRow.RowData[checkFieldInfo[0]];

                        // 桁数
                        val = val.PadLeft(int.Parse(checkFieldInfo[1]), '0');
                    }

                    fieldValue += val;
                }
            }

            // 値判定
            foreach (var option in pMetadata.OptionSet.Options)
            {
                if (string.IsNullOrEmpty(options))
                {
                    options = option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }
                else
                {
                    options = options + "," + option.Label.UserLocalizedLabel.Label + "(" + option.Value.ToString() + ")";
                }

                if (fieldValue == option.Label.UserLocalizedLabel.Label || fieldValue == option.Value.ToString())
                {
                    opValue = new OptionSetValue(option.Value.Value);
                }
                else if (!string.IsNullOrEmpty(fieldValue))
                {
                    var maeStr = "1";
                    var newStr = fieldValue;

                    while (newStr.Length < 9)
                    {
                        newStr = maeStr + fieldValue;
                        maeStr = maeStr + "0";
                    }

                    if (newStr == option.Value.ToString())
                    {
                        opValue = new OptionSetValue(option.Value.Value);
                    }
                }
            }

            if (opValue == null)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_010,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, options, fieldValue));
            }
            else
            {
                return opValue;
            }
        }
        protected virtual EntityReference ParseOwnerAttribute(CSVFieldData csvFieldData)
        {
            if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
            {
                var owner = csvFieldData.FieldValue.Split('/');

                return new EntityReference(owner[0], new Guid(owner[1]));
            }
            else
            {
                //TODO
                throw new NotImplementedException();
            }
        }
        protected virtual EntityReference ParseLookupAttribute(CSVFieldData csvFieldData)
        {
            var lMetadata = (LookupAttributeMetadata)csvFieldData.Metadata;

            CSVKeyFileService keyfile = null;
            var factory = CSVImportFactory.GetInstance();
            string lookupEntity = null;
            foreach(var entity in lMetadata.Targets)
            {
                keyfile = factory.GetCSVKeyFile(entity);
                if(keyfile != null)
                {
                    lookupEntity = entity;
                    if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
                    {
                        if (string.IsNullOrEmpty(csvFieldData.FieldValue))
                        {
                            return null;
                        }
                        else
                        {
                            return new EntityReference(lMetadata.Targets[0], new Guid(csvFieldData.FieldValue));
                        }
                    }
                    break;
                }
            }
            if (keyfile == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, string.Join(",", lMetadata.Targets)));
            }

            // CSVフィールド形式チェック
            var fieldInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            // キーリスト
            var keys = fieldInfo[0].Split(',');

            // フィールドリスト
            var fields = fieldInfo[1].Split(',');

            var outFields = "";
            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            // 検索条件設定
            for (var i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    return null;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    var temp = fields[i].StartsWith(CSVImportConsts.FIXEDVALUE) ? keys[i] : csvFieldData.CSVRow.DataName[fields[i]];
                    outFields = outFields + $"{temp}（{fields[i]}）";
                    outValue = outValue + checkValue;
                }
                else
                {
                    outFields = outFields + $",{csvFieldData.CSVRow.DataName[fields[i]]}（{fields[i]}）";
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyfile.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013,
                    csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                return new EntityReference(lookupEntity, new Guid(rows[0][CSVImportConsts.GUID].ToString()));
            }
            else
            {
                // ユーザーフィールド特定ユーザー設定
                if (lMetadata.Targets[0] == "systemuser")
                {
                    // 特定システムユーザーセット
                    return new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                }

                // コラムスキップ[True]の場合
                if (csvFieldData.ColumnMapping.CrmColumnSkip == "true")
                {
                    _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019, csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
                    return null;
                }

                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_019,csvFieldData.CSVRow.RowNum, lookupEntity, outFields, outValue));
            }
        }
        protected virtual DateTime? ParseDateTimeAttribute(CSVFieldData csvFieldData)
        {
            // 日付型変換
            var date = "";
            var time = "";
            string[] dates = { };
            string[] times = { };

            // 時刻判定
            if (csvFieldData.FieldValue.Contains(" "))
            {
                var dt = csvFieldData.FieldValue.Split(' ');
                date = dt[0];
                time = dt[1];
            }
            else
            {
                date = csvFieldData.FieldValue;
            }

            // 区切判定
            if (date.Contains("/"))
            {
                dates = date.Split('/');
            }
            else if (date.Contains("-"))
            {
                dates = date.Split('-');
            }

            // 年月日
            if (dates.Length == 3)
            {
                dates[0] = dates[0].PadLeft(2, '0');
                dates[1] = dates[1].PadLeft(2, '0');
                dates[2] = dates[2].PadLeft(2, '0');

                // YYYYMMDDの場合
                if (dates[0].Length == 4)
                {
                    date = dates[0] + dates[1] + dates[2];
                }
                else
                {
                    // DDMMYYYYの場合
                    date = dates[2] + dates[0] + dates[1];
                }
            }

            // 区切判定
            if (time.Contains(":"))
            {
                times = time.Split(':');
            }

            // 時分の場合
            if (times.Length == 2)
            {
                times[0] = times[0].PadLeft(2, '0');
                times[1] = times[1].PadLeft(2, '0');

                time = times[0] + times[1];
            }
            else if (times.Length == 3)
            {
                // 時分秒の場合
                times[0] = times[0].PadLeft(2, '0');
                times[1] = times[1].PadLeft(2, '0');
                times[2] = times[2].PadLeft(2, '0');

                time = times[0] + times[1] + times[2];
            }

            // 時分の場合
            if (time.Length == 4)
            {
                time = time + "00";
            }

            // 日付構成
            var retDate = DateTime.Now;

            var dateTime = date + time;

            if (dateTime.Length == 8)
            {
                if (!DateTime.TryParseExact(dateTime, "yyyyMMdd", null,
                    System.Globalization.DateTimeStyles.None, out retDate))
                {
                    // 帝国データ判定
                    if (!"JBS-BT-005".Equals(csvFieldData.CSVRow.Context.BatchId))
                    {
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_014,
                            csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            else
            {
                if (!DateTime.TryParseExact(dateTime, "yyyyMMddHHmmss", null,
                    System.Globalization.DateTimeStyles.None, out retDate))
                {
                    // 帝国データ判定
                    if (!"JBS-BT-005".Equals(csvFieldData.CSVRow.Context.BatchId))
                    {
                        throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_014,
                        csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
                    }
                    else
                    {
                        return null;
                    }
                }
            }

            var minTime = new DateTime(1900, 1, 1, 0, 0, 0);

            if (retDate.CompareTo(minTime) < 0)
            {
                // 帝国データ判定
                if (!"JBS-BT-005".Equals(csvFieldData.CSVRow.Context.BatchId))
                {
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_015,
                    csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.DataName[csvFieldData.ColumnMapping.CsvColumn], csvFieldData.ColumnMapping.CsvColumn, csvFieldData.FieldValue));
                }
                else
                {
                    return null;
                }
            }

            return retDate.ToUniversalTime();
        }
        #endregion

        #region データ反映処理
        protected virtual void UpsertEntity(List<(CSVRowData CSVData, Entity EntityData)> batchEntities)
        {
            var needDisactiveDataList = new List<(CSVRowData CSVData, Entity EntityData, OptionSetValue StateCode, OptionSetValue StatusCode)>();
            foreach (var itemData in batchEntities)
            {
                //新規登録時、statecodeがアクティブ以外の場合
                if (itemData.EntityData.Id == Guid.Empty && itemData.EntityData.GetAttributeValue<OptionSetValue>("statecode")?.Value > 0)
                {
                    needDisactiveDataList.Add((itemData.CSVData, itemData.EntityData,
                        itemData.EntityData.GetAttributeValue<OptionSetValue>("statecode"),
                        itemData.EntityData.GetAttributeValue<OptionSetValue>("statuscode")));

                    //TODO:statecode,statuscodeが同時に入ってくることを確認
                    itemData.EntityData.Attributes.Remove("statecode");
                    itemData.EntityData.Attributes.Remove("statuscode");
                }
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var itemData in batchEntities)
            {
                if (itemData.EntityData.Id == Guid.Empty)
                {
                    CreateRequest createRequest = new CreateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(createRequest);
                }
                else
                {
                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
            }
            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = batchEntities[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                    //新規作成時
                    if (batchEntities[responseItem.RequestIndex].EntityData.Id == Guid.Empty)
                    {
                        //生成したGUIDを格納する
                        var newGuid = (Guid)responseItem.Response.Results["id"];
                        batchEntities[responseItem.RequestIndex].EntityData.Id = newGuid;
                    }
                }
            }
            if (needDisactiveDataList.Count > 0)
            {
                DisactiveEntity(needDisactiveDataList);
            }
        }
        protected virtual void DisactiveEntity(List<(CSVRowData CSVData, Entity EntityData, OptionSetValue StateCode, OptionSetValue StatusCode)> batchEntities)
        {
            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };
            //登録失敗のデータを除く
            batchEntities = batchEntities.Where(r => r.EntityData.Id != Guid.Empty).ToList();

            foreach (var itemData in batchEntities)
            {
                var disActiveEntity = new Entity(itemData.EntityData.LogicalName, itemData.EntityData.Id);
                disActiveEntity["statecode"] = itemData.StateCode;
                disActiveEntity["statuscode"] = itemData.StatusCode;

                UpdateRequest updateRequest = new UpdateRequest
                {
                    Target = disActiveEntity
                };
                multipleRequest.Requests.Add(updateRequest);
            }
            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = batchEntities[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                }
            }
        }
        #endregion
    }
}
