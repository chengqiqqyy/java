﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS.Common.CDS
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class EntityResultAttribute : Attribute
    {
        public string Key { set; get; }
        public bool IsDisplayName { set; get; }
        public EntityResultAttribute(string key)
        {
            Key = key;
        }
        public EntityResultAttribute(string key, bool isDisplayName)
        {
            Key = key;
            IsDisplayName = isDisplayName;
        }
    }
}
