﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVImportConsts
    {
        public const string MESSAGE_ERROR_003 = "{0}タグが存在しません。";
        public const string MESSAGE_ERROR_004 = "{0}が設定されません。";
        public const string MESSAGE_ERROR_005 = "設定ファイル{0}が存在しません。";

        // メッセージ
        public const string MESSAGE_BT_002_ERROR_001 = "システムに対象フィールドが存在しません。{0}";
        public const string MESSAGE_BT_002_ERROR_002 = "キー情報ファイルが存在しません。{0}";
        public const string MESSAGE_BT_002_ERROR_003 = "入力ファイルに対象フィールドが存在しません。{0}";
        public const string MESSAGE_BT_002_ERROR_004 = "必須項目が設定されません。{0}行目、項目名「{1}」";
        public const string MESSAGE_BT_002_ERROR_005 = "文字列の最大長を超えました。{0}行目、項目名「{1}（{2}）」、最大長「{3}」、文字数「{4}」、現在値「{5}」";
        public const string MESSAGE_BT_002_ERROR_006 = "項目の値が数値ではありません。{0}行目、項目名「{1}（{2}）」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_007 = "最小値より小さい。{0}行目、項目名「{1}（{2}）」、最小値「{3}」、現在値「{4}」";
        public const string MESSAGE_BT_002_ERROR_008 = "最大値より大きい。{0}行目、項目名「{1}（{2}）」、最大値「{3}」、現在値「{4}」";
        public const string MESSAGE_BT_002_ERROR_009 = "項目の値が数値ではありません。{0}行目、項目名「{1}（{2}）」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_010 = "選択肢が存在しません。{0}行目、項目名「{1}（{2}）」、選択肢「{3}」、現在値「{4}」";
        public const string MESSAGE_BT_002_ERROR_013 = "対象レコードが複数件存在します。{0}行目、エンティティ「{1}」、項目名「{2}」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_014 = "日付型の形式が不正です。{0}行目、項目名「{1}（{2}）」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_015 = "範囲外の日付です。{0}行目、項目名「{1}（{2}）」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_016 = "D365へのデータマージ処理にエラーが発生しました。";
        public const string MESSAGE_BT_002_ERROR_017 = "オプションセットマッピング設定が存在しません。{0}";
        public const string MESSAGE_BT_002_ERROR_018 = "オプションセットマッピングの値が存在しません。オプションセットマッピング「{0}」、項目名「{1}（{2}）」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_019 = "対象レコードが見つかりません。{0}行目、エンティティ「{1}」、項目名「{2}」、現在値「{3}」";
        public const string MESSAGE_BT_002_ERROR_020 = "CSVファイルのヘッダとデータの列数が一致しません。{0}行目、ヘッダ列数「{1}」、データ列数「{2}」";
        // 所有者特殊処理メッセージ
        public const string MESSAGE_BT_002_ERROR_021 = "特定システムユーザーが見つかりません。{0}行目、エンティティ「systemuser」、項目名「所有者（ownerid）」、特定システムユーザー「{1}」、入力値「{2}」";
        public const string MESSAGE_BT_002_ERROR_027 = "特定システムユーザーが複数存在します。{0}行目、エンティティ「systemuser」、項目名「所有者（ownerid）」、特定システムユーザー「{1}」、入力値「{2}」";
        public const string MESSAGE_BT_002_ERROR_022 = "担当者コード関連データ「{0}」がない、所有者設定できません。{1}行目、エンティティ「tsb_organization_structure」、項目名「所有者（ownerid）」、現在値「{2}」";
        public const string MESSAGE_BT_002_ERROR_028 = "担当者コードは見つからない、所有者設定できません。{1}行目、エンティティ「tsb_organization_structure」、項目名「所有者（ownerid）」、現在値「{2}」";
        public const string MESSAGE_BT_002_ERROR_023 = "顧客情報がない、所有者設定できません。{0}行目、エンティティ「account」、項目名「所有者（ownerid）」、検索フィールド「店番、顧客番号」、現在値「{1}、{2}」";
        public const string MESSAGE_BT_002_ERROR_024 = "顧客情報関連データ「{0}」がない、所有者設定できません。{1}行目、エンティティ「account」、項目名「所有者（ownerid）」、検索フィールド「店番、顧客番号」、現在値「{2}、{3}」";
        // DA番号特殊処理メッセージ
        public const string MESSAGE_BT_002_ERROR_025 = "特定DA番号レコードが見つかりません。{0}行目、エンティティ「tsb_info_da」、項目名「DA番号（tsb_lup_num_da）」、特定DA番号「{1}」、入力値「{2}」";
        public const string MESSAGE_BT_002_ERROR_026 = "特定DA番号レコードが複数存在します。{0}行目、エンティティ「tsb_info_da」、項目名「DA番号（tsb_lup_num_da）」、特定DA番号「{1}」、入力値「{2}」";

        public const string MESSAGE_BT_002_ERROR_099 = "現時点で処理できないフィールドタイプです。項目名「{0}」、タイプ「{1}」";

        // GUID
        public const string GUID = "guid";
        // REQ
        public const string REQUIRED = "[REQ]";
        // 固定値
        public const string FIXEDVALUE = "[固定値]";
        // 改行変換コード
        public const string OVERROW_CHANGE_CODE = "<<br>>";
        public const string OVERROW_CHANGE_CODE_S = "<br>";
        public const string OVERROW_CHANGE_CODE_B = "<<BR>>";
        // 改行コード
        public const string OVERROW_CODE = "\n";

        public const string FOLDER_CONFIG = "BatchConfig";
    }
}
