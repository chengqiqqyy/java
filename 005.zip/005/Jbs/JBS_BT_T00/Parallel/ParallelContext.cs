﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Parallel
{
    public class ParallelContext
    {
        public object SyncObject { get; set; } = new object();
        public bool IsAllDataFetched { get; set; }
        public bool HasAbortRequest { get; set; }
        public int BlockCount { get; set; } = 100;
        public int ThreadCount { get; set; } = 1;

        public int TotalCount { get; set; }
        public int ErrorCount { get; set; }
        public int SuccessCount { get; set; }
        public int WarningCount { get; set; }

        public int AutoPartitionCount { get; set;}
    }
}
