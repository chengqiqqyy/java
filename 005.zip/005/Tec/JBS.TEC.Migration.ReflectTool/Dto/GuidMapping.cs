﻿namespace JBS.TEC.Migration.ReflectTool.Dto
{
    public class GuidMapping
    {
        public string Attribute { get; set; }
        public string MidTable { get; set; }
        public string Sql { get; set; }
    }
}
