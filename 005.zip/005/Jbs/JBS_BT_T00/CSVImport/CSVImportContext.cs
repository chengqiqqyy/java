﻿using JBS_BT_T00.Parallel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.CSVImport
{
    public class CSVImportContext : ParallelContext
    {
        public string BatchId { get; set; }
        public JBS_BT_T00_Config JBS_BT_T00_Config { get; set; }
        public bool ErrorContinueFlag { get; set; } = true;
        public string Delimiter { get; set; } = "\t";
        // 環境変数
        public Dictionary<string, string> environmentArgs { get; set; }
        // エラーデータ
        public List<string> ErrorDataList { get; set; }
        // エラーデータ再インポート用
        public List<string> ErrorDataList2 { get; set; }
    }
}
