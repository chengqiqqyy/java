﻿using BatchCommon.Log;
using JBS_BT_T00.CSVImport;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Specialized
{
    public class BT108ImportExecutor : CSVImportExecutor
    {
        private static Logger _logger = LogManager.GetCurrentClassLogger();

        public BT108ImportExecutor(CSVImportContext context) : base(context)
        {

        }

        // [所有者] 特殊処理
        protected override void SetOwner(CSVFieldData csvFieldData)
        {
            // 所有者設定要否の判断
            if (!_context.JBS_BT_T00_Config.SetOwner || csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_name_customer")
            {
                return;
            }

            var opObj = csvFieldData.CSVRow.EntityData;

            // 顧客情報
            var customerData = opObj.GetAttributeValue<EntityReference>("tsb_lup_name_customer");

            // 顧客がNULLではない場合
            if (customerData != null)
            {
                // 顧客キーファイル
                var customerKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("account");
                // 検索条件
                var keyValues = new Dictionary<string, string>();
                keyValues.Add("guid", customerData.Id.ToString());

                // 検索
                var rows = customerKeyFile.Query(keyValues);

                // 所有者
                var ownerid = rows.FirstOrDefault() == null ? "" : rows.FirstOrDefault()["ownerid"].ToString();

                if (!string.IsNullOrEmpty(ownerid))
                {
                    // 所有者タイプ
                    var systemuserKeyFile = CSVImportFactory.GetInstance().GetCSVKeyFile("systemuser");
                    keyValues.Clear();
                    keyValues.Add("guid", ownerid);
                    rows = systemuserKeyFile.Query(keyValues);

                    // チームの場合
                    if (rows.Length < 1)
                    {
                        opObj["ownerid"] = new EntityReference("team", new Guid(ownerid));
                    }
                    // ユーザーの場合
                    else
                    {
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(ownerid));
                    }
                }
                else
                {
                    if (_context.JBS_BT_T00_Config.OwnerSkip)
                    {
                        // 特定システムユーザーセット
                        opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                        _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_024, "所有者", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                        return;
                    }
                    throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_024, "所有者", csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                }
            }
            else
            {
                if (_context.JBS_BT_T00_Config.OwnerSkip)
                {
                    // 特定システムユーザーセット
                    opObj["ownerid"] = new EntityReference("systemuser", new Guid(_context.JBS_BT_T00_Config.StubUserId));
                    _logger.Debug(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_023, csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
                    return;
                }
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_023, csvFieldData.CSVRow.RowNum, csvFieldData.CSVRow.RowData["m_tsb_slt_num_branch"], csvFieldData.CSVRow.RowData["m_tsb_slt_num_customer"]));
            }
        }

        // [DA番号] 特殊処理
        protected override EntityReference ParseLookupAttribute(CSVFieldData csvFieldData)
        {
            if (csvFieldData.ColumnMapping.CrmColumn != "tsb_lup_num_da")
            {
                return base.ParseLookupAttribute(csvFieldData);
            }

            var lMetadata = (LookupAttributeMetadata)csvFieldData.Metadata;

            CSVKeyFileService keyfile = null;
            var factory = CSVImportFactory.GetInstance();
            string lookupEntity = null;
            foreach (var entity in lMetadata.Targets)
            {
                keyfile = factory.GetCSVKeyFile(entity);
                if (keyfile != null)
                {
                    lookupEntity = entity;
                    if (csvFieldData.ColumnMapping.CsvColumn.StartsWith("[LINK]"))
                    {
                        if (string.IsNullOrEmpty(csvFieldData.FieldValue))
                        {
                            return null;
                        }
                        else
                        {
                            return new EntityReference(lMetadata.Targets[0], new Guid(csvFieldData.FieldValue));
                        }
                    }
                    break;
                }
            }
            if (keyfile == null)
            {
                // キーファイルは必須とする
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_002, string.Join(",", lMetadata.Targets)));
            }

            // CSVフィールド形式チェック
            var fieldInfo = csvFieldData.ColumnMapping.CsvColumn.Split(';');

            // キーリスト
            var keys = fieldInfo[0].Split(',');

            // フィールドリスト
            var fields = fieldInfo[1].Split(',');

            var outValue = "";

            // 検索条件
            var keyValues = new Dictionary<string, string>();
            // 検索条件設定
            for (var i = 0; i < keys.Length; i++)
            {
                var checkKey = keys[i];

                var checkValue = "";

                // 固定値対応
                if (fields[i].StartsWith(CSVImportConsts.FIXEDVALUE))
                {
                    checkValue = fields[i].Replace(CSVImportConsts.FIXEDVALUE, "");
                }
                else
                {
                    checkValue = csvFieldData.CSVRow.RowData[fields[i]];
                }

                // 入力値がない場合
                if (string.IsNullOrEmpty(checkValue))
                {
                    return null;
                }

                keyValues.Add(checkKey, checkValue);

                // ログ出力用情報
                if (i == 0)
                {
                    outValue = outValue + checkValue;
                }
                else
                {
                    outValue = outValue + "," + checkValue;
                }
            }

            // 検索
            var rows = keyfile.Query(keyValues);

            // 複数件がある場合
            if (rows.Length > 1)
            {
                throw new Exception(string.Format(CSVImportConsts.MESSAGE_BT_002_ERROR_013,
                    csvFieldData.CSVRow.RowNum, lookupEntity, fieldInfo[1], outValue));
            }

            // 一件のみの場合
            if (rows.Length == 1)
            {
                return new EntityReference(lookupEntity, new Guid(rows[0][CSVImportConsts.GUID].ToString()));
            }
            else
            {
                // 特定DA番号設定
                return new EntityReference(lMetadata.Targets[0], new Guid(_context.JBS_BT_T00_Config.DamiDaNumId));
            }
        }

        // 自己参照
        protected override void UpsertEntity(List<(CSVRowData CSVData, Entity EntityData)> batchEntities)
        {
            if (!_context.JBS_BT_T00_Config.SelfLookup)
            {
                base.UpsertEntity(batchEntities);
                return;
            }

            var multipleRequest = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            var updList = new List<(CSVRowData CSVData, Entity EntityData)>();

            foreach (var itemData in batchEntities)
            {
                if (itemData.EntityData.Id != Guid.Empty)
                {
                    if (string.IsNullOrEmpty(itemData.CSVData.RowData["m_tsb_lup_num_copy_info"]) 
                        && string.IsNullOrEmpty(itemData.CSVData.RowData["m_tsb_lup_num_loan"]))
                    {
                        itemData.CSVData.IsSuccess = true;
                        continue;
                    }

                    updList.Add((itemData.CSVData, itemData.EntityData));

                    UpdateRequest updateRequest = new UpdateRequest
                    {
                        Target = itemData.EntityData
                    };
                    multipleRequest.Requests.Add(updateRequest);
                }
                else
                {
                    itemData.CSVData.IsSuccess = true;
                }
            }
            var responseWithResults = (ExecuteMultipleResponse)_crmService.Execute(multipleRequest);
            foreach (var responseItem in responseWithResults.Responses)
            {
                var csvData = updList[responseItem.RequestIndex].CSVData;
                if (responseItem.Fault != null)
                {
                    csvData.IsSuccess = false;
                    csvData.ErrorMessage = responseItem.Fault.ToString();
                }
                else
                {
                    csvData.IsSuccess = true;
                }
            }
        }
    }
}
