﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchCommon.Helper
{
    public class CSVHelper
    {
        #region CSV列の値編集
        /// <summary>
        /// CSV列の値編集
        /// </summary>
        /// <param name="field">対象値</param>
        /// <returns>編集後値</returns>
        public static string MakeCsvField(string field)
        {
            if (field == null)
            {
                return "";
            }

            return field.Replace("\t", " ").Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
        }
        #endregion
    }
}
