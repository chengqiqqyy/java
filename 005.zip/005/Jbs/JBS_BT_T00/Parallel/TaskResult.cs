﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.Parallel
{
    public enum TaskResultType
    {
        SUCCESS,
        WARNING,
        ERROR,
        ABORT
    }
    public class TaskResult<T> where T : class
    {
        public TaskResultType ResultType { get; set; }
        public T TaskData { get; set; }
    }
}
