﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JBS_BT_T00.EntityService
{
    public class EntityData
    {
        public Entity TargetEntity { get; set; }
        public EntityActionType ActionType { get; set; }
    }
}
