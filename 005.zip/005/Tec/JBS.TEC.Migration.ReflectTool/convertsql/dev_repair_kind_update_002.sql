﻿update x
set x.dev_kind_main = 
case 
when y.dev_commodity_classification = 277670000 then 277670001
when y.dev_commodity_classification = 277670001 then 277670002
when y.dev_commodity_classification = 277670002 then 277670004
when y.dev_commodity_classification = 277670003 then 277670006
else null
end
from
mid_dev_repair x
inner join
(
    select
    a.mid_oldkey,
    b.dev_commodity_classification
    from
    mid_dev_repair a
    left join
    mid_dev_purchase_detail b
    on a.dev_search_purchase_detail = b.mid_oldkey
) y
on x.mid_oldkey = y.mid_oldkey
where
x.dev_kind_main is null