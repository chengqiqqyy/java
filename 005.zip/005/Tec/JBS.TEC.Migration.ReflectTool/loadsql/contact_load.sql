﻿SELECT 
 *
FROM 
[dbo].[mid_contact]